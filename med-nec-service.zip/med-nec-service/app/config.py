"""Settings, read from the environment.

App Service supplies these through Application Settings. Nothing here is a
secret and nothing here needs a key vault yet; when the model is wired in it
authenticates with the App Service managed identity.
"""

import os

SERVICE_NAME = "med-nec-guidance"
SERVICE_VERSION = "0.1.0"

# Set by the pipeline so a running instance can be traced to a commit.
BUILD_COMMIT = os.environ.get("BUILD_SOURCEVERSION") or os.environ.get("GIT_COMMIT")
ENVIRONMENT = os.environ.get("ENVIRONMENT", "dev")

# Flipped to true when the Foundry model is wired in. Until then every response
# carries meta.stub = true and meetsMedicalNecessity = null.
ENGINE = os.environ.get("ENGINE", "stub")

KNOWLEDGE_VERSION = os.environ.get("KNOWLEDGE_VERSION")


def is_stub() -> bool:
    return ENGINE == "stub"
