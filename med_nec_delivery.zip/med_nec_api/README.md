# Medical necessity guidance service

The endpoint Transport.net calls on trip submission. Takes a trip request payload
and returns the three fields agreed in the MVP workflow meeting: a clinical
summary, a medical necessity flag, and a clarifying question when one is needed.

**Every determination comes from the model.** There are no stored answers. A
payload the model cannot be asked about returns a 503 with `meetsMedicalNecessity:
null` and the reason, because a default would be indistinguishable from a real
determination and this endpoint decides whether a transport is billable.

## Launching it

### First time only

```powershell
cd med_nec_api

py -m venv C:\venvs\mednec
C:\venvs\mednec\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Two Windows notes. Use `py`, not `python`, to create the venv — Windows ships a
stub `python.exe` that only advertises the Microsoft Store and will shadow a real
install. And keep the venv outside OneDrive: it is tens of thousands of small
files, and syncing them both floods OneDrive and intermittently locks files
mid-install. The project folder itself is fine in OneDrive.

### Every time

**1. Activate the venv and sign in to Azure.**

```powershell
cd med_nec_api
C:\venvs\mednec\Scripts\Activate.ps1
az login
```

The `az login` token expires, so this is a daily thing rather than a one-off. The
service has no key: it borrows your signed-in identity locally, and uses the App
Service managed identity once deployed.

**2. Prove the model is reachable.** Optional after the first time, but it takes
two seconds and it separates a configuration problem from a problem with the
evaluation.

```powershell
python smoke_test.py
```

You want `Connection works`. Anything else names the thing to check.

**3. Start the service.**

```powershell
python -m uvicorn app:app --reload --port 8000
```

**This blocks and keeps running.** Leave the terminal open. Stop it with Ctrl+C.
If you want to run the notebook or `run_batch.py`, open a **second** terminal and
activate the venv again there.

**4. Open the review screen.**

```
http://127.0.0.1:8000/ui
```

Drop a trip request JSON on it and submit.

### If something is wrong

| What you see | What it means |
|---|---|
| `Model unreachable` in the top right | the service is up but the model is not. Expand the error; it names what to check |
| `uvicorn: command not found` | the venv is not activated, or `uvicorn` went to a different one. `python -m uvicorn` works either way |
| `Address already in use` | a service is already running on 8000. Use it, or `--port 8001` |
| `No such file or directory: prompts/...` | you are not in the `med_nec_api` folder |
| nothing happens at `/ui` | check the terminal running uvicorn; the error is there |

### Where settings live

`.env`, already filled in with the DEV resource provisioned under RITM0669421:

```
CLAUDE_BASE_URL=https://aif-app-tmp-cus-dev.cognitiveservices.azure.com/anthropic
CLAUDE_DEPLOYMENT_NAME=claude-sonnet-5-5
```

### Why that hostname and not the one in the portal

The Foundry portal shows `aif-app-tmp-cus-dev.services.ai.azure.com`. From a GMR
workstation that hostname is unusable: TCP 443 connects and the TLS handshake is
then reset (WinError 10054). It is reset by hostname, not by address — other
names pointed at the same IP, including `centralus.api.cognitive.microsoft.com`,
handshake normally. Azure cannot make that distinction, because the hostname
travels inside the handshake being rejected, so the decision is being made by
GMR's egress filter. `*.services.ai.azure.com` is almost certainly caught by a
generative-AI URL category rule.

`aif-app-tmp-cus-dev.cognitiveservices.azure.com` is an alias for the same
resource, serving the same deployments, and is not in that category.

Treat it as a workaround. The App Service subnet will meet the same policy at
deploy time, and a pilot should not rest on an alias that happens not to be
categorised yet. The egress rule to ask for:

> Allow outbound 443 to `*.services.ai.azure.com`, for the developer workstation
> now and the App Service subnet at deploy. `aif-app-tmp-cus-dev` is an Azure AI
> Foundry resource inside GMR's own tenant, provisioned under RITM0669421, not a
> third-party AI service.

`diagnose_tls.py`, `diagnose_sni.py` and `try_alt_endpoints.py` reproduce the
evidence if it is challenged.

### All settings

| Variable | Default | What it does |
|---|---|---|
| `CLAUDE_BASE_URL` | — | must end in `/anthropic` |
| `CLAUDE_DEPLOYMENT_NAME` | — | the deployment name, not the model id |
| `AZURE_CLIENT_ID` | — | **App Service only.** Leave unset locally |
| `CLAUDE_MAX_TOKENS` | `4000` | |
| `CLAUDE_TEMPERATURE` | `0` | see the note below |
| `SIMULATED_LATENCY_MS` | `0` | artificial delay, for timeout testing |
| `COST_PER_MTOK_INPUT` | unset | your contracted rate, per million input tokens |
| `COST_PER_MTOK_OUTPUT` | unset | per million output tokens |

The two cost rates have no default on purpose. Foundry pricing is contract
specific, and a guessed number would end up in a sizing conversation as if it
were real. Leave them unset and no cost is reported; set them and every response
carries `meta.estimatedCostUsd`.

`AZURE_CLIENT_ID` is commented out in `.env` on purpose. Locally the token comes
from your `az login` session; naming a managed identity client id gives
`DefaultAzureCredential` an identity to go looking for that does not exist on a
laptop. It belongs in App Service configuration. There are no keys in `.env`,
which is why it is safe in the repo — keys are disabled on the Foundry resource
deliberately.

> **On temperature.** `anthropic` 1.15 removed `temperature` from the typed
> signature of `messages.create()`. Determinism matters for a coverage
> determination, so where the SDK no longer accepts it the value is sent in the
> request body instead. If the endpoint rejects that too, the call is retried
> once without it and the setting is disabled for the life of the process.
> `GET /v1/engine` reports which mode is in force as `temperatureMode`.

### Deployments available

Both live on `aif-app-tmp-cus-dev`, deployed as Data Zone Standard (US).

| Deployment name | Quota |
|---|---|
| `claude-sonnet-5-5` | 80K TPM |
| `claude-opus-5-5` | 40K TPM |

Sonnet is the default. This is classification against a fixed rubric, running
synchronously inside a trip submission where latency is the constraint, not an
open-ended reasoning task. Reach for Opus when Sonnet's determinations look wrong
on trips whose criteria are clear — swapping is one line in `.env`.

On sizing: the compiled instruction is about 14,000 characters, so roughly 3,500
input tokens before the trip's answers are added. Call it 4,500 in and 800 out.
Against 80K TPM that is **roughly 15 trips a minute**, and a trip that gets a
clarifying question costs two calls. If peak volume exceeds that, the quota needs
raising before pilot.

## The review screen

```
http://127.0.0.1:8000/ui
```

Served by this service, so it talks to the API on the same origin and needs no
separate server and no CORS allowance.

The page is in two numbered sections, each with its own upload and its own
button. **1. The order** takes `payload.json`. **2. The patient care record**
takes `epcr.csv`. They are separate because they are two assessments of one
transport, made at different times by different people, and each is worth
reading on its own before they are compared. Neither depends on the other: the
record can be assessed without an order loaded, and an order needs no record.

### 1. The order

1. Drop a trip request JSON on the first drop zone, or browse for one.
2. **What this trip carries** opens immediately, before anything is submitted.
   On the left, the context that bears on the determination without being an
   answer: level of service requested against the full scale, trip reason,
   diagnosis, and the origin and destination modifiers decoded into words. From
   those two codes it names which decision tree governs, higher or lower level of
   care, and why. When the payload carries neither code it says so, because that
   silently defaults every order to the lower level of care tree.
   On the right, the question and answer pairs the service will actually read,
   extracted the same way the service extracts them: from `losQuestions`, or by
   parsing `clinicalData` when that array is null, which is how the real payloads
   arrive.
3. Submit. The determination appears below and scrolls into view. The determination comes back as one of four states, each with its own
   wording and icon as well as its own colour, so the state never rests on colour
   alone: meets, needs one more detail, does not meet, no determination.
4. When a clarifying question comes back, answer it in place and send. The new
   determination replaces the old one and says what changed:
   `does not meet → meets`.
5. A strip under the determination shows what that call cost: round trip split
   into model time and service overhead, tokens in and out, how many model calls
   it took, and the cost when rates are configured. A round trip over five
   seconds is coloured, because that is the top of the working figure for the
   submission timeout.
6. **Across this service** aggregates every call the event log has seen: p50,
   p95 and slowest round trip, mean tokens, model calls per trip, and total cost.
   When p95 crosses five seconds it says so in words.
7. Expand for the per-question findings, and the criteria and exclusions with
   their citations and quoted evidence.

### 2. The patient care record

Below all of that, with its own drop zone and its own **Assess record** button.
Drop the `epcr.csv` from the same trip folder and press it. The record is scored
on its own: its own summary, its own verdict, the field by field findings, and
the documentation gaps a biller would hit.

When an order has already been determined, a banner at the top of the record
result says whether the two agree. That banner is the reason for running both,
and it redraws if the order determination changes — answering a clarifying
question above updates the comparison below without re-running the record.

A record with no verdict, because it is unmatched or carries no clinical
content, shows no banner and no negative. Nothing to agree with is not
disagreement.

The two sections do not police each other, but each rejects the wrong file type
and says which section it belongs in.

The badge top right reports what answered the last call. When the model cannot be
reached it turns red, no verdict is shown at all, and the error names the thing
to go and check. Nothing is ever rendered as a determination that was not one.

Everything is one file, `static/index.html`. No build step, no package manager.

## The notebook

```
med_nec_live_test.ipynb
```

**The service has to be running first**, in its own terminal, and this needs a
second one. Walks one trip through the service and shows what comes back at each point, then
runs the whole folder and reports the sizing numbers. The review screen does the
same for one trip; this is the version you can take apart, and the only place the
raw response and the aggregate numbers sit together.

Section 7 is where accuracy work happens: change the clarifying answer and re-run
to see where the line sits between an answer that rescues a trip and one that
does not. Cheaper than changing the criteria and re-running everything.

Section 9 is the sizing: p50, p95, tokens per trip, and the trips-per-minute
ceiling against the 80K TPM quota. That is the run to do before a review.

It ships with outputs cleared. The numbers in it have to come from your own run
against a real model, not from a saved example.

## Running a folder of payloads

The review screen is for looking at one trip closely. For volume — the fifty
payloads the Databricks builder writes, say — use the batch runner:

The service has to be running in another terminal.

```powershell
C:\venvs\mednec\Scripts\Activate.ps1
python run_batch.py --dir .\inbox
python run_batch.py --dir .\inbox --answer-questions --workers 3
```

It posts every `*.json` in the folder, prints a line per trip, and writes one
workbook: a `trips` sheet with the determination, summary, basis, criteria,
exclusions, timing and tokens, and a `question findings` sheet with one row per
question and answer pair across every trip. That second sheet is the one for
analysis at scale.

`--answer-questions` also sends a standing clarifying answer wherever a question
came back, which doubles the calls. The standing answer says plainly that no
further clinical detail is available, so it exercises the second call without
inventing clinical fact.

Nothing is cached. Fifty files is fifty model calls. Mind the TPM quota when
raising `--workers`.

## Endpoints

### `POST /v1/medical-necessity/evaluate`

Called on trip submission, before the trip is written. Body is the trip request
payload exactly as Transport.net already builds it.

```bash
curl -X POST http://127.0.0.1:8000/v1/medical-necessity/evaluate \
  -H "Content-Type: application/json" -d @inbox/trip_10097360.json
```

The three fields the UI acts on are at the top level. `clarifyingQuestion` is
`null` when no question is needed, which is the signal to show nothing and carry
on with submission.

`detail` carries the per-question findings: category, criterion, citation,
evidence quote and confidence for every question and answer pair. That is the
part worth logging and analysing at scale, not displaying.

### `POST /v1/medical-necessity/reevaluate`

Called after the requester answers the clarifying question.

```jsonc
{
  "tripRequest": { "...the original payload, unchanged..." },
  "clarification": { "question": "...", "answer": "..." }
}
```

**Both integration patterns are supported**, because the meeting did not settle
which one to build. The separate endpoint above is one. The other is to add two
fields to the existing payload, null on the first call:

```jsonc
{ "...trip request...", "clarifyingQuestion": "...", "clarifyingAnswer": "..." }
```

Posted to `/evaluate`, a populated pair routes to a re-evaluation and `callType`
comes back as `reevaluation`. A re-evaluation never asks again: the requester is
asked once. Pick whichever Transport.net prefers and the other can be dropped.

### `GET /healthz`

Up, version, knowledge version, and whether `llm.py` imported.

### `GET /v1/engine`

Live connectivity probe. One trivial model call, reporting the settings in force,
the latency, and on failure the specific thing to go and check. Run it before a
demo.

### `GET /v1/criteria/reference`

The lookups the review screen needs to label a payload: the level of service
scale, the origin and destination modifier scale with meanings, and the tree
selection rule. Served from the criteria file so there is one place those are
defined, rather than a copy in the page.

### `GET /v1/stats`

Everything the event log knows, aggregated. This is the sizing data for the
timeout decision and the quota request:

```jsonc
{
  "evaluated": 50, "errors": 0,
  "determinations": { "meets": 18, "does_not_meet": 9, "needs_review": 23 },
  "latencyMs": { "p50": 4120, "p95": 7880, "max": 9240,
                 "modelP50": 3960, "modelP95": 7610 },
  "tokens": { "inputMean": 4471, "outputMean": 761 },
  "cost": { "totalUsd": 1.2484, "meanPerCallUsd": 0.024968 },
  "sizing": { "trips": 41, "reevaluations": 9, "recordAssessments": 41,
              "requestsPerTrip": 1.22, "modelCallsPerTrip": 1.34,
              "meanTokensPerTrip": 5232,
              "modelCallsPerRecord": 1.0, "meanTokensPerRecord": 5684 }
}
```

Takes `?limit=N` for just the most recent N calls.

`modelCallsPerTrip` is the number to size the quota on, not the trip count. It
accounts for both ways a trip costs more than one call: a clarifying question
means a second request, and a response that fails validation means a second model
call inside one request.

Record assessments are counted apart from it, under `recordAssessments` and
`meanTokensPerRecord`. They are a retrospective pass, run later and often in a
batch of their own, so folding them into the per-trip figure would report an
order entry cost that no order actually incurs. Size the order entry quota on
`modelCallsPerTrip` and the retrospective pass on its own numbers.

### `POST /v1/medical-necessity/evaluate-epcr`

The second assessment. Takes the completed patient care record for a trip and
decides whether what the crew documented supports a claim.

```jsonc
// either
{ "row": { "TNET_TripRequestId": "9865030", "EPCR_Initial_SBP": "92", ... } }
// or
{ "csv": "<raw text of epcr.csv>", "tripRequestId": "9865030" }
```

With `csv` and no `tripRequestId` the first row is used. With both, the row whose
`TNET_TripRequestId` matches is used, and a 422 comes back if the file does not
contain that trip.

```jsonc
{
  "clinicalSummary": "...",
  "meetsMedicalNecessity": true,
  "documentationGaps": [],
  "detail": {
    "determination": "meets",
    "strongestEvidence": "EPCR_Procedures_Performed: IV access; cardiac monitoring",
    "fieldFindings": [ { "field": "...", "value": "...", "bearing": "supports_necessity", ... } ],
    "selection": { "populated": 19, "offered": 50, "withheld": 50,
                   "epcrMatched": true, "fieldsVersion": "2026-10-22" }
  }
}
```

`documentationGaps` is the retrospective form of the clarifying question: what
the record would have to say and does not. There is no second call for it,
because a record cannot be amended by answering a prompt.

When `MDM_GoldenRecord` is not `T` the row is reported as unmatched and no
verdict is produced. A trip with no record is not a trip that fails.

### `GET /v1/criteria/epcr-fields`

Which ePCR columns are sent to the model, which are withheld, and why for each
withheld group. The review screen shows this under the record assessment rather
than leaving it to the reader to infer.

## What the service reads

From the order: only `tripLegs[0].losQuestions`, or `tripLegs[0].clinicalData`
when that array is null. Patient name, date of birth, SSN, MRN and insurance are
**not read and should not be sent.**

From the record: 50 of the 101 columns, named in `prompts/epcr_fields.json`. The
other 50 are withheld at the point of the call, in five groups, each with a
reason in the file. Two of those reasons matter more than the rest:

- **Payer.** `EPCR_Primary_Payment_Method` and `EPCR_Insurance_Companies` never
  reach the model. Coverage is decided on clinical facts, and a determination
  that can see who pays is a compliance problem rather than a feature.
- **The order's own answers.** `TNET_LosQuestions` and `TNET_ClinicalData` are in
  the record table too. Sending them would let the second opinion read the first
  one, which defeats the point of having two.

The csv on disk carries all 101 columns regardless. Selection happens in the
service, so changing it does not mean re-pulling the data.

Real payloads do not always populate `losQuestions` — the UAT sample has it null
and puts everything in the flat `clinicalData` string — so that parse is a normal
path, not a rare fallback. It recovers question and answer pairs from the four
formats Transport.net writes, and anything matching none of them becomes its own
pair rather than being dropped.

## Errors

| Status | Meaning | What the caller does |
|---|---|---|
| 200 | evaluated | act on the three fields |
| 422 | payload could not be parsed | log it, submit the trip unchanged |
| 503 | the model could not be reached | log it, submit the trip unchanged |

A 503 returns the three fields as `null` alongside the reason, a hint naming what
to check, and an explicit `action`. Transport.net holds the submission while this
call is in flight, so a failure has to be something it can act on rather than
something it has to parse.

```json
{
  "error": "guidance_unavailable",
  "message": "The guidance service could not evaluate this trip.",
  "detail": "APIConnectionError: Connection error.",
  "hint": "CLAUDE_BASE_URL is wrong, or egress is blocked. Run diagnose_tls.py.",
  "action": "Submit the trip unchanged.",
  "meetsMedicalNecessity": null
}
```

## How the model call works

`llm.py` renders `prompts/system_prompt.md` against `prompts/med_nec_knowledge.json`
into one instruction at startup, not per request. The wording and the criteria are
both editable without touching Python; `prompts/README.md` covers that. Everything in the criteria file goes in: the 27 concepts across the
mobility and monitoring axes, the three bed confinement elements and the rule
that all three are required together, the exclusions, the four-part denial test,
the 17 policy rules, and the non-specific phrases that never establish anything
on their own. Roughly 14,000 characters.

There is no retrieval step and no vector index. The criteria set fits in one
instruction, so there is nothing to retrieve and no recall failure mode to design
around. That is why Azure AI Search is not on the architecture diagram.

Each request sends the whole trip's question and answer pairs in one call, so
criteria whose elements are spread across several answers are seen together. Bed
confinement is the clearest case: the three elements rarely come from one answer.

Two behaviours worth knowing:

- A response that fails validation is retried once, with the rejected output
  handed back to the model as an assistant turn and the reason given.
- A payload with no clinical answers short-circuits with no model call at all,
  rather than spending tokens to be told nothing is there.

Every criterion the model records as documented must quote the answer text it
rests on, verbatim. A criterion it cannot quote is not documented. The `evidence`
field in `detail.questionFindings` is how you check that held.

## Layout

```
app.py                    the service
static/index.html         the review screen at /ui
llm.py                    the model call and the prompt rendering
prompts/
  system_prompt.md        the order entry instruction and output schema
  epcr_prompt.md          the patient care record instruction and output schema
  med_nec_knowledge.json  the criteria, shared by both
  epcr_fields.json        which record columns are sent, which withheld, why
  README.md               what to edit and how to check it
med_nec_live_test.ipynb   walk one trip, then the folder, then the sizing
run_batch.py              posts a folder of payloads, writes a workbook
build_live_notebook.py    regenerates the notebook
inbox/                    drop payloads here, see inbox/README.md
smoke_test.py             standalone connectivity check
diagnose_tls.py           DNS, TCP, TLS, HTTPS layer by layer
diagnose_sni.py           whether a block is by hostname
try_alt_endpoints.py      finds a hostname that gets through
requirements.txt
.env                      resource and deployment settings, no keys
```

The `diagnose_*` and `try_*` scripts are kept deliberately. They are the evidence
behind the hostname choice above, and they will be needed again when the App
Service meets the same egress policy.

## Where payloads come from

`med_nec_payload_builder.ipynb`, in Databricks. It reads trips from
`` `prod-sandbox`.vivekkumar_patel.gold_tnet_tripmaster ``, parses `ClinicalData`
into the structured `losQuestions` array, strips every patient identifier, then
pulls the matching patient care record from
`` `prod-sandbox`.vivekkumar_patel.temp_THR_MUSC_data `` and writes one folder
per trip:

```
json_payloads3/
  9865030/
    payload.json     the order, identifiers stripped
    epcr.csv         the record, all 101 columns, nothing stripped
```

Upload a folder's two files in the two sections of the review screen, or point
the batch runner at the tree for the orders alone.

**A folder is only written when both halves carry data.** The trip query is
restricted to trips the ePCR table has a populated record for, so `ROW_LIMIT`
counts usable pairs rather than candidates, and the check runs again at write
time against the row that came back.

That rule exists because a record can exist and say nothing: an unmatched record
carries the trip id and nulls for all 48 `EPCR_*` fields, with
`MDM_GoldenRecord = F`. Writing one out produces a folder whose csv is a header
and nothing else.

Set `REQUIRE_EPCR = False` in the notebook to build from orders alone. Trips
skipped for want of a record are listed in the output either way, so the misses
are counted rather than silently dropped.

`epcr.csv` is not de-identified. It carries destination addresses, agency names
and a crew narrative written at the bedside. The builder flags dates and record
numbers in that narrative but cannot catch names, so these folders stay inside
Databricks until someone has read a sample.
