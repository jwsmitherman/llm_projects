"""Regenerates med_nec_payload_builder.ipynb."""

import json
import nbformat as nbf

ENVELOPE = json.load(open("/home/claude/med_nec_api/uat_source/UAT_SampleTripRequest_1.json"))
ENVELOPE_JSON = json.dumps(ENVELOPE, indent=1)

nb = nbf.v4.new_notebook()
C = []


def md(text):
    C.append(nbf.v4.new_markdown_cell(text.strip()))


def code(text):
    C.append(nbf.v4.new_code_cell(text.strip()))


md("""
# Medical necessity payload builder

Builds trip request payloads for testing the medical necessity guidance service.

Two sources, in order of preference:

1. **Real trips from a Databricks table.** Sections 8 onward. This is the one to
   use once production read access lands.
2. **Hand written scenarios.** Sections 3 to 7. Clinical content written against
   the criteria, for cases the real data has not produced yet.

Both produce the same thing: JSON files in the Transport.net trip request shape,
with every patient identifier removed.

### Output layout

One folder per trip, named by trip request id:

```
json_payloads3/
  9865030/
    payload.json     the order as Transport.net would send it
    epcr.csv         the completed patient care record for that same trip
  9865031/
    ...
```

Two files because there are two assessments. The payload is what the requester
said before the transport; the ePCR is what the crew wrote after it. The service
scores each on its own and the pair is where the signal is: a trip the order read
as not meeting and the record reads as meeting is a documentation problem, and
the reverse is a guidance problem. Neither file alone tells you which.

`epcr.csv` carries **every** ePCR column, not the subset the model sees. Column
selection is the service's business and lives in
`med_nec_api/prompts/epcr_fields.json`, so it can change without re-pulling the
data. Payment method and insurance are in the file and are withheld at the point
of the model call.

A folder is only written when **both halves carry data** (`REQUIRE_EPCR`, on by
default). The trip query is restricted to trips the ePCR table has a populated
record for, so `ROW_LIMIT` counts usable pairs rather than candidates, and the
check is repeated at write time against the row that actually came back.

That matters because a record can exist and say nothing. An unmatched record
carries the trip id and nulls for all 48 `EPCR_*` fields, with
`MDM_GoldenRecord = F`. That is a row to the database and no evidence to anyone
reading it, and writing it out produces a folder whose csv is a header and
nothing else.

Set `REQUIRE_EPCR = False` to build from orders alone, which is what to do when
the record extract has not caught up with the trips you want to test.

### The shape this builds against

Taken from `UAT_SampleTripRequest_1.json`, the sample Transport.net supplied.
Two things about it drive the design:

- `losQuestions` is **null**. Every clinical answer is in the flat `clinicalData`
  string. The structured array is not guaranteed to be populated, so payloads
  built here carry the flat form.
- The envelope has about 90 fields the service never reads, plus a 29 entry
  `additionalFields` array. They are kept so the payload is realistic in size and
  structure rather than a convenient subset.

### What the service actually reads

`tripLegs[0].clinicalData`, or `tripLegs[0].losQuestions` when populated. Nothing
else. Patient name, date of birth, SSN, MRN and insurance are not read and are
blanked here.

### What reaches a payload

| Part of the payload | Comes from |
|---|---|
| `clinicalData` | **the table.** The one column that matters |
| `olosRequestId`, `levelOfService`, `tripReason` | the table if mapped, otherwise a fallback. Echoed, never reasoned about |
| `patientInfo` | blanked. Never read from the table |
| everything else, about 90 fields | the UAT envelope, fixed |

The query is `SELECT *` so you can see what is in every column, but only the
clinical column is written into a payload. Read wide, write narrow.

### Dependencies

Standard library and what Databricks already provides. Nothing to install.

```
json, copy, shutil, os, uuid, hashlib, datetime, re   standard library
spark                                     Databricks
pandas                                    via .toPandas(), in every runtime
```

Sections 1 to 9 need no cluster at all and will run on a plain Python kernel.
Only the real-data sections use `spark`.
""")

md("""
## 1. Configuration

Table and output path match `create_transportnet_payloads`. `os.getcwd()` resolves
to this notebook's own folder, so `json_payloads3` sits beside it in the
workspace browser.

`EPCR_TABLE` is the second source. It joins to the trip table on
`EPCR_JOIN_COLUMN`, which holds the same value as `TRIP_REQUEST_ID_COLUMN` under
a different name. Set `EPCR_TABLE` to `None` to build payloads without records.

The catalog needs backticks because of the hyphen in `prod-sandbox`; the schema
and table do not.

`ROW_LIMIT` is how many rows are pulled; `MAX_PAYLOADS` is how many files get
written. Two numbers because not every row survives: rows without clinical data
are excluded by the query, and rows that fail the identifier check are held back.
Pull wide, write what you need.
""")

code("""
import json
import copy
import shutil
import os
import uuid
import hashlib
import pandas as pd
from datetime import datetime

RUN_TS = datetime.now().strftime("%Y%m%d_%H%M%S")

CATALOG = "prod-sandbox"
SCHEMA = "vivekkumar_patel"
TRIP_TABLE = "gold_tnet_tripmaster"

EPCR_TABLE = "temp_THR_MUSC_data"

SOURCE_TABLE = f"`{CATALOG}`.{SCHEMA}.{TRIP_TABLE}"
EPCR_SOURCE_TABLE = f"`{CATALOG}`.{SCHEMA}.{EPCR_TABLE}" if EPCR_TABLE else None

EPCR_JOIN_COLUMN = "TNET_TripRequestId"
EPCR_MATCH_FLAG_COLUMN = "MDM_GoldenRecord"
EPCR_MATCH_FLAG_MEANS_MATCHED = "T"

CLINICAL_DATA_COLUMN = "ClinicalData"
TRIP_REQUEST_ID_COLUMN = "TripRequestId"
REQUEST_DATE_COLUMN = "RequestDate"

OPTIONAL_COLUMNS = {
    "level_of_service": "LevelOfService",
    "trip_reason": "TripReason",
}

TMP_DIR = "/tmp/med_nec_payloads"
JSON_OUTPUT_DIR = os.path.join(os.getcwd(), "json_payloads3")

SCRUB_IDENTIFIERS = True

# Only build a trip when BOTH halves carry data. With this on, the trip query
# itself is restricted to trips the ePCR table has a populated record for, so
# ROW_LIMIT rows means ROW_LIMIT usable pairs rather than however many happen to
# have matched. Set it False to go back to building from orders alone.
REQUIRE_EPCR = True

# What counts as a populated record. A row can exist and say nothing: an
# unmatched record carries the key and nulls for every clinical field, which is
# a row to the database and no evidence to anyone reading it.
EPCR_CONTENT_COLUMNS = [
    "EPCR_Chief_Complaint", "EPCR_Primary_Impression", "EPCR_Narrative",
    "EPCR_Procedures_Performed", "EPCR_Medications_Given",
    "EPCR_Patient_Evaluation_Care", "EPCR_Transport_Method",
    "EPCR_Initial_SBP", "EPCR_Initial_Heart_Rate", "EPCR_Level_Of_Care_Provided",
]

ROW_LIMIT = 500
MAX_PAYLOADS = 50

LEAK_TOKENS = ["Kendra", "Smitham", "01/12/2002", "gmrqaplaywright",
               "Edna", "Quigley", "tester123"]
ALLOWED_PATIENT_KEYS = ["heightUnit", "weightUnit", "_note"]

os.makedirs(TMP_DIR, exist_ok=True)

if REQUIRE_EPCR and not EPCR_SOURCE_TABLE:
    REQUIRE_EPCR = False
    print("NOTE   EPCR_TABLE is None, so REQUIRE_EPCR has been turned off.")
    print()

print("RUN_TS      :", RUN_TS)
print("trip table  :", SOURCE_TABLE)
print("epcr table  :", EPCR_SOURCE_TABLE or "(none, payload only)")
print("pairs only  :", REQUIRE_EPCR)
print("tmp dir     :", TMP_DIR)
print("output dir  :", JSON_OUTPUT_DIR)
print("scrubbing   :", SCRUB_IDENTIFIERS)
print(f"rows pulled : {ROW_LIMIT}   trip folders written: {MAX_PAYLOADS}")
print()

if os.path.isdir(JSON_OUTPUT_DIR):
    existing = [d for d in os.listdir(JSON_OUTPUT_DIR)
                if os.path.isdir(os.path.join(JSON_OUTPUT_DIR, d))]
    print(f"output dir exists, {len(existing)} trip folder(s) already there")
else:
    print("output dir does not exist yet, it will be created on write")
""")

md("""
## 2. The envelope

The real UAT payload, used as the template. Clinical content is replaced per
scenario; everything else stays as Transport.net sends it.
""")

code(f"""
ENVELOPE_JSON = r'''
{ENVELOPE_JSON}
'''

ENVELOPE = json.loads(ENVELOPE_JSON)

print("top level fields :", len(ENVELOPE))
print("leg fields       :", len(ENVELOPE["tripLegs"][0]))
print("additionalFields :", len(ENVELOPE["tripLegs"][0]["additionalFields"]))
print("losQuestions     :", ENVELOPE["tripLegs"][0]["losQuestions"])
print("levelOfService   :", ENVELOPE["tripLegs"][0]["levelOfService"])
""")

md("""
## 3. The blank patient block

Every field emptied. Kept in the payload rather than deleted so the structure
still matches what Transport.net sends, and so the absence is visible rather
than silent.
""")

code("""
PATIENT_TEMPLATE = ENVELOPE["tripLegs"][0]["patientInfo"]

BLANK_PATIENT = {}
for key in PATIENT_TEMPLATE:
    value = PATIENT_TEMPLATE[key]
    if isinstance(value, bool):
        BLANK_PATIENT[key] = False
    elif value is None:
        BLANK_PATIENT[key] = None
    else:
        BLANK_PATIENT[key] = ""

BLANK_PATIENT["heightUnit"] = "0003"
BLANK_PATIENT["weightUnit"] = "0005"
BLANK_PATIENT["_note"] = "Deliberately empty. The service reads only clinical answers."

print(f"{len(BLANK_PATIENT)} fields blanked")
for key in list(BLANK_PATIENT)[:8]:
    print(f"  {key:22} {BLANK_PATIENT[key]!r}")
print("  ...")
""")

md("""
## 4. Scenario definitions

Each entry is one trip. `items` is a list of question and answer pairs; they get
flattened into `clinicalData` in the next cell, in the format Transport.net uses.

Edit this list to add cases. Nothing below needs changing.
""")

code('''
SCENARIOS = [
    {
        "stem": "uat_2_vent_bed_confined",
        "olosRequestId": "e1a00001-0000-4000-8000-000000000002",
        "tripReason": "Discharge to Skilled Nursing Facility",
        "tripReasonId": "118",
        "los": "ALS",
        "dropoffLocTypeCode": "H",
        "medicareQuestionTen": "DX: Respiratory failure, ventilator dependent",
        "expected": "meets",
        "items": [
            ("Is this patient being transferred to a higher level of care due to their clinical condition?",
             "No (Discharge, Behavioral Transfer or Other Reason): dc to SNF"),
            ("Is any special handling required during transport?",
             "The patient is bed confined before and after transport. All three criteria must be met in order to use bed confined. Please specify reason in comments field.: The patient is unable to get up from bed without assistance, The patient is unable to ambulate, The patient is unable to sit in a chair or wheelchair: vent dependent, trach in place"),
            ("Does the patient require airway support during transport?",
             "Patient is on a ventilator operated by the transport provider, Requires regular oropharyngeal suctioning"),
            ("Is this a Time Sensitive transport request?", "No"),
        ],
    },
    {
        "stem": "uat_3_general_weakness",
        "olosRequestId": "e1a00001-0000-4000-8000-000000000003",
        "tripReason": "Discharge to Residence",
        "tripReasonId": "121",
        "los": "BLS",
        "dropoffLocTypeCode": "R",
        "medicareQuestionTen": "DX: Deconditioning",
        "expected": "does_not_meet, asks, flips to meets",
        "items": [
            ("Is this patient being transferred to a higher level of care due to their clinical condition?",
             "No (Discharge, Behavioral Transfer or Other Reason): discharge home"),
            ("Is any special handling required during transport?",
             "The patient is unable to sit safely in a wheelchair while the vehicle is in motion"),
            ("Please specify the reason the patient cannot sit safely in a wheelchair",
             "general weakness"),
            ("Does the patient require airway support during transport?", "None - Does not apply"),
            ("Is this a Time Sensitive transport request?", "No"),
        ],
    },
    {
        "stem": "uat_4_wheelchair_candidate",
        "olosRequestId": "e1a00001-0000-4000-8000-000000000004",
        "tripReason": "Transport to Scheduled Appointment",
        "tripReasonId": "140",
        "los": "BLS",
        "dropoffLocTypeCode": "H",
        "medicareQuestionTen": "DX: End stage renal disease",
        "expected": "does_not_meet, asks, stays does_not_meet",
        "items": [
            ("Is this patient being transferred to a higher level of care due to their clinical condition?",
             "No (Discharge, Behavioral Transfer or Other Reason): to dialysis"),
            ("Is any special handling required during transport?",
             "The patient can sit safely in a wheelchair while the vehicle is in motion"),
            ("Does the patient require airway support during transport?",
             "The patient requires continuous oxygen provided by the patient's own equipment at their baseline rate"),
            ("Is this a Time Sensitive transport request?",
             "Yes - Due to other reasons such as destination closing soon: dialysis chair time at 1400"),
        ],
    },
]

print(f"{len(SCENARIOS)} scenarios")
for s in SCENARIOS:
    print(f"  {s['stem']:30} {s['los']:6} {len(s['items'])} items   expect: {s['expected']}")
''')

md("""
## 5. Flatten to clinicalData

Transport.net writes each item as the question twice, then the answer:

```
Is this a Time Sensitive transport request?
Is this a Time Sensitive transport request?
No
```

or, where the label and the question are the same thing, as `label` then
`label: answer`. This reproduces the first form, which is what the ground
examples in the UAT sample use.
""")

code("""
FLATTENED = {}

for s in SCENARIOS:
    lines = []
    for question, answer in s["items"]:
        lines.append(question)
        lines.append(question)
        lines.append(answer)
    FLATTENED[s["stem"]] = "\\n".join(lines)

for stem in FLATTENED:
    blob = FLATTENED[stem]
    print("=" * 78)
    print(stem, f"({len(blob.splitlines())} lines, {len(blob)} chars)")
    print("=" * 78)
    for line in blob.splitlines()[:6]:
        print("  ", line[:110])
    print("   ...")
    print()
""")

md("""
## 6. Assemble the payloads

Deep copy of the envelope per scenario, clinical content swapped in,
`losQuestions` left null to match the real payload, requester details blanked.
""")

code("""
PAYLOADS = {}

for s in SCENARIOS:
    trip = copy.deepcopy(ENVELOPE)
    leg = trip["tripLegs"][0]

    trip["olosRequestId"] = s["olosRequestId"]
    trip["tripReason"] = s["tripReason"]
    trip["tripReasonId"] = s["tripReasonId"]
    trip["requesterName"] = "UAT Automation"
    trip["requesterFirstName"] = "UAT"
    trip["requesterLastName"] = "Automation"
    trip["createdBy"] = "UAT Automation"
    trip["createdByEmail"] = ""
    trip["notifyName"] = ""
    trip["notifyEmail"] = ""
    trip["notifyPhone"] = ""

    leg["patientInfo"] = copy.deepcopy(BLANK_PATIENT)
    leg["systemLos"] = s["los"]
    leg["levelOfService"] = s["los"]
    leg["losCategory"] = s["los"]
    leg["losCategoryLabel"] = s["los"]
    leg["losQuestions"] = None
    leg["clinicalData"] = FLATTENED[s["stem"]]
    leg["medicareQuestionTen"] = s["medicareQuestionTen"]
    leg["dropoffLocTypeCode"] = s["dropoffLocTypeCode"]

    PAYLOADS[s["stem"]] = trip

for stem in PAYLOADS:
    leg = PAYLOADS[stem]["tripLegs"][0]
    print(f"{stem:30} {leg['levelOfService']:6} losQuestions={leg['losQuestions']}  "
          f"clinicalData={len(leg['clinicalData'])} chars")
""")

md("""
## 7. Verify before writing

Nothing leaves this notebook until it passes. The check looks for any value left
in `patientInfo`, and for the specific identifiers that were in the UAT sample.
""")

code("""
failures = []

for stem in PAYLOADS:
    trip = PAYLOADS[stem]
    blob = json.dumps(trip)

    patient = trip["tripLegs"][0]["patientInfo"]
    populated = []
    for key in patient:
        if key in ALLOWED_PATIENT_KEYS:
            continue
        if patient[key] not in ("", None, False):
            populated.append(key)

    hits = []
    for token in LEAK_TOKENS:
        if token.lower() in blob.lower():
            hits.append(token)

    if populated or hits:
        failures.append((stem, populated, hits))
        print(f"FAIL  {stem}")
        if populated:
            print(f"        patientInfo still populated: {populated}")
        if hits:
            print(f"        identifier tokens found: {hits}")
    else:
        print(f"PASS  {stem}")

print()
if failures:
    raise ValueError(f"{len(failures)} payload(s) failed the identifier check. Nothing written.")
print(f"All {len(PAYLOADS)} payloads clean.")
""")

md("""
## 8. Write them out

`/tmp` first, then copied with `shutil.copyfile`, which is the pattern that works
on serverless. If the copy fails the files stay in `/tmp` and the paths are
printed rather than the run failing silently.
""")

code("""
written = []

for stem in PAYLOADS:
    tmp_path = f"{TMP_DIR}/{stem}_{RUN_TS}.json"
    with open(tmp_path, "w") as handle:
        json.dump(PAYLOADS[stem], handle, indent=4)
    written.append((stem, tmp_path))

print(f"wrote {len(written)} files to {TMP_DIR}")
for stem, path in written:
    print(f"  {os.path.getsize(path):>8,} bytes  {path}")
""")

code("""
copied = []
failed_copy = []

for stem, tmp_path in written:
    folder = os.path.join(JSON_OUTPUT_DIR, stem)
    try:
        os.makedirs(folder, exist_ok=True)
        target = os.path.join(folder, "payload.json")
        shutil.copyfile(tmp_path, target)
        copied.append(target)
    except Exception as exc:
        failed_copy.append((stem, f"{type(exc).__name__}: {exc}"))

if copied:
    print(f"copied {len(copied)} payloads into {JSON_OUTPUT_DIR}")
    for path in copied:
        print("  ", os.path.join(os.path.basename(os.path.dirname(path)),
                                 os.path.basename(path)))
    print()
    print("No epcr.csv in these folders. The scenarios are written against the")
    print("criteria, not drawn from a transport, so there is no record to pair.")

if failed_copy:
    print()
    print(f"{len(failed_copy)} could not be copied. They are still in {TMP_DIR}.")
    for stem, err in failed_copy:
        print(f"  {stem}: {err[:120]}")
""")

md("""
## 9. Print one payload

To check the shape, or to copy a single payload out by hand.
""")

code("""
STEM_TO_SHOW = "uat_3_general_weakness"

trip = PAYLOADS[STEM_TO_SHOW]
leg = trip["tripLegs"][0]

print("olosRequestId  :", trip["olosRequestId"])
print("tripReason     :", trip["tripReason"])
print("levelOfService :", leg["levelOfService"])
print("losQuestions   :", leg["losQuestions"])
print()
print("clinicalData:")
print("-" * 78)
print(leg["clinicalData"])
print("-" * 78)
""")

code("""
print(json.dumps(PAYLOADS[STEM_TO_SHOW], indent=2)[:3000])
print("...")
""")

md("""
## 10. Building from real trip data

Everything above is hand written clinical content. This section builds the same
payloads from actual trips.

The source table in cell 1 is the one `create_transportnet_payloads` reads:
`` `prod-sandbox`.vivekkumar_patel.gold_tnet_tripmaster ``.

Section 10a is only needed if that moves or you want a different table. Skip
straight to 10b otherwise.
""")

md("""
### 10a. Finding a different table

Only needed if the source table moves, or to point at something else. Work down
these four cells, then set `CATALOG`, `SCHEMA` and `TRIP_TABLE` in cell 1.
""")

code("""
display(spark.sql("SHOW CATALOGS"))
""")

code("""
display(spark.sql(f"SHOW SCHEMAS IN `{CATALOG}`"))
""")

code("""
display(spark.sql(f"SHOW TABLES IN `{CATALOG}`.`{SCHEMA}`"))
""")

md("""
If the three cells above did not turn it up, this searches every catalog you can
read for a table whose name contains `SEARCH_TERM`. One query per catalog against
`information_schema`, so it is quick, and catalogs you cannot read are skipped
rather than failing the cell.
""")

code("""
SEARCH_TERM = "trip"

catalogs = [r[0] for r in spark.sql("SHOW CATALOGS").collect()]
print(f"searching {len(catalogs)} catalog(s) for table names containing '{SEARCH_TERM}'")
print()

hits = []
skipped = []

for catalog in catalogs:
    query = f\"\"\"
        SELECT table_catalog, table_schema, table_name
        FROM `{catalog}`.information_schema.tables
        WHERE lower(table_name) LIKE '%{SEARCH_TERM.lower()}%'
    \"\"\"
    try:
        for row in spark.sql(query).collect():
            hits.append((row[0], row[1], row[2]))
    except Exception as exc:
        skipped.append((catalog, type(exc).__name__))

if hits:
    print(f"{len(hits)} match(es):")
    for catalog, schema, table in sorted(hits):
        print(f"  CATALOG    = \\"{catalog}\\"")
        print(f"  SCHEMA     = \\"{schema}\\"")
        print(f"  TRIP_TABLE = \\"{table}\\"")
        print()
else:
    print("No matches. Try a different SEARCH_TERM, for example:")
    print("  tnet, olos, request, clinical, payload, master")

if skipped:
    print(f"{len(skipped)} catalog(s) could not be searched:")
    for catalog, err in skipped:
        print(f"  {catalog}  ({err})")
""")

md("""
### 10b. Inspect the table you chose
""")

code("""
try:
    display(spark.sql(f"DESCRIBE {SOURCE_TABLE}"))
except Exception as exc:
    print(f"FAIL   {SOURCE_TABLE} cannot be read.")
    print(f"       {type(exc).__name__}: {str(exc)[:200]}")
    print()
    print("Set CATALOG, SCHEMA and TRIP_TABLE in cell 1 from the search above,")
    print("then run this cell again.")
""")

md("""
All columns, every one of them, so nothing is hidden. Narrowing the column list at
query time is how the `TransferReason` problem went unnoticed for a full scoring
run.

Rows are a different matter. Most rows in this table have no `ClinicalData` at
all, so without the predicate a `LIMIT 500` returns mostly nulls and yields a
fraction of that in payloads. The filter is on rows, not columns.
""")

code("""
# "Has a populated record" as a SQL predicate, so the filter runs in a subquery
# rather than in pandas after the fact. A trip with no usable record is never
# pulled, so ROW_LIMIT counts usable trips rather than candidates.
EPCR_HAS_CONTENT = " OR ".join(
    f"(`{c}` IS NOT NULL AND trim(string(`{c}`)) <> '')" for c in EPCR_CONTENT_COLUMNS)

pair_filter = ""
if REQUIRE_EPCR:
    pair_filter = f\"\"\"
      AND CAST(`{TRIP_REQUEST_ID_COLUMN}` AS STRING) IN (
            SELECT DISTINCT CAST(`{EPCR_JOIN_COLUMN}` AS STRING)
            FROM {EPCR_SOURCE_TABLE}
            WHERE {EPCR_HAS_CONTENT}
          )\"\"\"

raw = spark.sql(f\"\"\"
    SELECT *
    FROM {SOURCE_TABLE}
    WHERE {CLINICAL_DATA_COLUMN} IS NOT NULL{pair_filter}
    ORDER BY {REQUEST_DATE_COLUMN} DESC
    LIMIT {ROW_LIMIT}
\"\"\").toPandas()

print("rows     :", len(raw))
print("columns  :", len(raw.columns))
print("filter   :", "clinical data AND a populated record"
                    if REQUIRE_EPCR else "clinical data only")
print()

if REQUIRE_EPCR and len(raw) == 0:
    print("CHECK  No trip has both halves. Either the join column is wrong or")
    print("       these two tables do not overlap. Count each side before")
    print("       assuming the join is at fault:")
    print()
    print(f"         SELECT count(DISTINCT `{TRIP_REQUEST_ID_COLUMN}`) FROM {SOURCE_TABLE}")
    print(f"         SELECT count(DISTINCT `{EPCR_JOIN_COLUMN}`) FROM {EPCR_SOURCE_TABLE}")
    print()
    print("       Set REQUIRE_EPCR = False in cell 1 to build from orders alone.")
    print()
elif REQUIRE_EPCR and len(raw) < MAX_PAYLOADS:
    print(f"CHECK  {len(raw)} trips have both halves, fewer than MAX_PAYLOADS "
          f"({MAX_PAYLOADS}).")
    print("       Raise ROW_LIMIT if more pairs sit further back in the table.")
    print()
for col in sorted(raw.columns):
    non_null = raw[col].notna().sum()
    distinct = raw[col].nunique(dropna=True)
    print(f"  {col:38} non-null {non_null:>4}   distinct {distinct:>4}")
""")

md("""
### Which columns go where

Two are required, and both are set in cell 1.

| Column | Goes into | Why |
|---|---|---|
| `ClinicalData` | `tripLegs[0].clinicalData` | the only thing evaluated |
| `TripRequestId` | `sourceSystemTripId` | traces a determination back to its trip |

The table has no OLOS request id, so `olosRequestId` is derived from
`TripRequestId` as a UUID5. That is deterministic: the same trip produces the same
id on every run, which matters because the service keys its stored responses on
it. A random id per run would orphan every result from the previous one.

`LevelOfService` and `TripReason` are optional metadata that the service echoes
and never reasons about. `LevelOfService` is worth mapping if the table carries
air transports, since those are out of scope.

Everything else in the table stays in the DataFrame and never reaches a payload.
""")

code("""
if CLINICAL_DATA_COLUMN not in raw.columns:
    print(f"FAIL   '{CLINICAL_DATA_COLUMN}' is not in the table.")
    raise ValueError(f"required column not found: {CLINICAL_DATA_COLUMN}")

if TRIP_REQUEST_ID_COLUMN not in raw.columns:
    print(f"FAIL   '{TRIP_REQUEST_ID_COLUMN}' is not in the table.")
    print("       Without it, payloads cannot be traced back to a trip.")
    raise ValueError(f"required column not found: {TRIP_REQUEST_ID_COLUMN}")

print(f"PASS   clinical data   -> {CLINICAL_DATA_COLUMN}")
print(f"PASS   trip request id -> {TRIP_REQUEST_ID_COLUMN}")
print()

RESOLVED = {}
for role in OPTIONAL_COLUMNS:
    column = OPTIONAL_COLUMNS[role]
    if column in raw.columns:
        RESOLVED[role] = column
        print(f"       {role:20} -> {column}")
    else:
        RESOLVED[role] = None
        print(f"       {role:20} -> not mapped, fallback will be used")

duplicate_ids = raw[TRIP_REQUEST_ID_COLUMN].duplicated().sum()
print()
if duplicate_ids:
    print(f"CHECK  {duplicate_ids} duplicate {TRIP_REQUEST_ID_COLUMN} value(s) in this pull.")
    print("       Later rows will overwrite earlier ones, since the id names the file.")
else:
    print(f"PASS   all {len(raw)} {TRIP_REQUEST_ID_COLUMN} values are distinct")
""")

md("""
A trip is only usable if `clinicalData` actually holds clinical text. Rows where
it is empty, or where it is a short status value rather than question and answer
content, are dropped here rather than sent to the model.

That guard exists because of a real failure: `TransferReason` turned out to be a
workflow status field with a handful of distinct values, and 500 model calls were
spent on it before anyone noticed.
""")

code("""
clinical_col = CLINICAL_DATA_COLUMN

usable = raw[raw[clinical_col].notna()].copy()
usable["clinical_len"] = usable[clinical_col].astype(str).str.len()
usable["line_count"] = usable[clinical_col].astype(str).str.count("\\n") + 1

distinct_values = usable[clinical_col].nunique(dropna=True)
median_lines = int(usable["line_count"].median()) if len(usable) else 0

print(f"rows with clinical data : {len(usable)} of {len(raw)}")
print(f"distinct values         : {distinct_values}")
print(f"median length           : {int(usable['clinical_len'].median()) if len(usable) else 0}")
print(f"median line count       : {median_lines}")
print()

if len(usable) == 0:
    print("FAIL   No rows have clinical data. Wrong column, or ROW_LIMIT is too small.")

elif median_lines < 3:
    print("CHECK  Values are mostly single lines. Expected question and answer blocks")
    print("       across several lines. This may be a status or category field.")
    print()
    for value in usable[clinical_col].astype(str).head(5):
        print("  ", value[:140])

elif len(usable) >= 30 and distinct_values <= 60:
    print("CHECK  Many rows but few distinct values. This looks like a status field")
    print("       rather than per-trip clinical text. Confirm before building.")
    print()
    print(usable[clinical_col].value_counts().head(15).to_string())

elif len(usable) < 30:
    print("PASS   Content looks like question and answer blocks.")
    print(f"       Note: {len(usable)} rows is too small to judge whether the column")
    print("       repeats across trips. Raise ROW_LIMIT before trusting that signal.")

else:
    print("PASS   Looks like per-trip question and answer content.")
""")

code("""
REAL_PAYLOADS = {}
QUESTION_CATALOG = {}
PARSE_COUNTS = []
los_from_text = 0

KNOWN_LOS = {"BLS", "ALS", "ALS2", "SCT", "CCT", "MICU", "ROTOR", "FW",
             "WHEELCHAIR", "WAV", "AMB", "CCTP"}

for position in range(len(usable)):
    row = usable.iloc[position]

    trip = copy.deepcopy(ENVELOPE)
    leg = trip["tripLegs"][0]

    trip_request_id = str(row[TRIP_REQUEST_ID_COLUMN])
    request_id = str(uuid.uuid5(uuid.NAMESPACE_URL,
                                f"gmr:tnet:triprequest:{trip_request_id}"))

    if RESOLVED["level_of_service"]:
        los = str(row[RESOLVED["level_of_service"]])
    else:
        los = "BLS"

    if RESOLVED["trip_reason"]:
        trip_reason = str(row[RESOLVED["trip_reason"]])
    else:
        trip_reason = ""

    trip["olosRequestId"] = request_id
    trip["sourceSystemTripId"] = trip_request_id
    trip["tripReason"] = trip_reason
    trip["requesterName"] = ""
    trip["requesterFirstName"] = ""
    trip["requesterLastName"] = ""
    trip["createdBy"] = ""
    trip["createdByEmail"] = ""
    trip["notifyName"] = ""
    trip["notifyEmail"] = ""
    trip["notifyPhone"] = ""

    blob = str(row[clinical_col])
    lines = [ln.strip() for ln in blob.split("\\n")]
    lines = [ln for ln in lines if ln]

    parsed = []
    i = 0
    while i < len(lines):
        line = lines[i]
        nxt = lines[i + 1] if i + 1 < len(lines) else None

        if nxt is not None and nxt == line and i + 2 < len(lines):
            question, answer = line, lines[i + 2]
            i += 3
        elif nxt is not None and nxt.startswith(line + ": "):
            question, answer = line, nxt[len(line) + 2:]
            i += 2
        elif nxt is not None and nxt == line:
            i += 2
            continue
        else:
            question, answer = None, line
            if ": " in line:
                head, _, tail = line.partition(": ")
                half = len(head) // 2
                if (len(head) % 2 == 1 and head[half] == " "
                        and head[:half] == head[half + 1:]):
                    question, answer = head[:half], tail
            i += 1

        if not answer.strip():
            continue

        if question:
            digest = hashlib.sha1(question.lower().encode("utf-8")).hexdigest()
            question_id = 9000000 + int(digest[:6], 16) % 1000000
            QUESTION_CATALOG[question] = question_id
        else:
            question_id = None

        parsed.append({
            "sectionId": None,
            "sectionName": None,
            "questionId": question_id,
            "parentQuestionId": None,
            "questionText": question,
            "elementType": None,
            "isRequired": None,
            "singleResponse": None,
            "answer": answer,
            "answerValue": None,
            "slaTypeId": 1,
        })

    if not RESOLVED["level_of_service"]:
        for entry in parsed:
            label = (entry["questionText"] or "").strip().lower()
            if label in ("level of service", "level of care requested", "service line requested"):
                first_token = entry["answer"].strip().split()[0].upper().strip(",:")
                if first_token in KNOWN_LOS:
                    los = first_token
                    los_from_text += 1
                break

    leg["patientInfo"] = copy.deepcopy(BLANK_PATIENT)
    leg["systemLos"] = los
    leg["levelOfService"] = los
    leg["losCategory"] = los
    leg["losCategoryLabel"] = los
    leg["losQuestions"] = parsed
    leg["clinicalData"] = blob
    leg["medicareQuestionTen"] = ""

    if REQUEST_DATE_COLUMN in raw.columns:
        trip["requestDateTime"] = str(row[REQUEST_DATE_COLUMN])
        leg["msgReceived"] = str(row[REQUEST_DATE_COLUMN])

    PARSE_COUNTS.append((trip_request_id, len(parsed),
                         sum(1 for p in parsed if p["questionText"] is None)))
    REAL_PAYLOADS[f"trip_{trip_request_id}"] = trip

print(f"built {len(REAL_PAYLOADS)} payloads from real trips")
print(f"distinct questions seen: {len(QUESTION_CATALOG)}")
if los_from_text:
    print(f"level of service read from clinical text: {los_from_text}")
print()

total_pairs = sum(c[1] for c in PARSE_COUNTS)
orphans = sum(c[2] for c in PARSE_COUNTS)
empty = sum(1 for c in PARSE_COUNTS if c[1] == 0)

print(f"question/answer pairs parsed : {total_pairs}")
print(f"median pairs per trip        : "
      f"{sorted(c[1] for c in PARSE_COUNTS)[len(PARSE_COUNTS)//2] if PARSE_COUNTS else 0}")
print(f"answers with no question     : {orphans}")
print(f"trips that parsed to nothing : {empty}")
print()

if empty:
    print("CHECK  Some trips produced no pairs. Their clinicalData does not follow")
    print("       the repeated-question format. Inspect one before trusting the rest.")
    print()

print(f"{'file stem':20} {'sourceSystemTripId':20} {'LOS':8} {'pairs':>6}  chars")
print("-" * 70)
for stem in list(REAL_PAYLOADS)[:10]:
    trip = REAL_PAYLOADS[stem]
    leg = trip["tripLegs"][0]
    print(f"{stem:20} {trip['sourceSystemTripId']:20} "
          f"{leg['levelOfService']:8} {len(leg['losQuestions']):>6}  "
          f"{len(leg['clinicalData'])}")
if len(REAL_PAYLOADS) > 10:
    print(f"... and {len(REAL_PAYLOADS) - 10} more")
""")

md("""
### What came out of the parse

The distinct questions found across the pull, with the id assigned to each. Ids
are a hash of the question text, so the same question carries the same id in
every payload and findings can be grouped by question across trips.

They start at 9000000 to make clear they are derived here rather than the form's
own ids, which are not in this table.
""")

code("""
catalog = pd.DataFrame(
    [{"questionId": QUESTION_CATALOG[q], "questionText": q} for q in QUESTION_CATALOG]
).sort_values("questionText")

print(f"{len(catalog)} distinct questions")
display(catalog)
""")

md("""
One payload, rendered. This is the check that matters: the answers should sit in
`losQuestions` with their questions, not as one blob.
""")

code("""
STEM = list(REAL_PAYLOADS)[0]
leg = REAL_PAYLOADS[STEM]["tripLegs"][0]

print("file stem          :", STEM)
print("sourceSystemTripId :", REAL_PAYLOADS[STEM]["sourceSystemTripId"])
print("olosRequestId      :", REAL_PAYLOADS[STEM]["olosRequestId"])
print("levelOfService     :", leg["levelOfService"])
print(f"losQuestions       : {len(leg['losQuestions'])} entries")
print()

for entry in leg["losQuestions"]:
    print(f"  [{entry['questionId']}]")
    print(f"    Q: {(entry['questionText'] or '(no question text)')[:100]}")
    print(f"    A: {entry['answer'][:100]}")
    print()
""")

md("""
### 10c. The patient care record for each trip

The second pull. One row per trip from the ePCR table, joined on
`EPCR_JOIN_COLUMN`, which carries the same value as `TRIP_REQUEST_ID_COLUMN`
under a different name.

The `IN` list is built from the trip ids already in hand rather than pulling the
whole table and filtering in pandas. The ePCR table is wide and a full scan of it
is not free.

With `REQUIRE_EPCR` on, the trips in hand already passed the content filter in
the query above, so most rows here carry something. The check is repeated anyway
on the row that actually came back: the subquery decided which trips to pull,
and this decides whether what arrived says anything. A row that does not is
dropped here and the trip gets no folder.

`MDM_GoldenRecord` is how the source says a record never matched. It is reported
rather than used as the test, because a matched record can still be empty and an
unmatched one is not evidence against the trip.
""")

code("""
EPCR_BY_TRIP = {}
EPCR_COLUMNS = []
epcr_raw = None

if not EPCR_SOURCE_TABLE:
    print("EPCR_TABLE is None. Building payloads without records.")

else:
    wanted = [str(row[TRIP_REQUEST_ID_COLUMN]) for _, row in usable.iterrows()]
    quoted = ", ".join("'" + v.replace("'", "''") + "'" for v in wanted)

    try:
        epcr_raw = spark.sql(f\"\"\"
            SELECT *
            FROM {EPCR_SOURCE_TABLE}
            WHERE CAST(`{EPCR_JOIN_COLUMN}` AS STRING) IN ({quoted})
        \"\"\").toPandas()
    except Exception as exc:
        print(f"FAIL   could not read {EPCR_SOURCE_TABLE}")
        print(f"       {type(exc).__name__}: {str(exc)[:300]}")
        print()
        print("       Check the table name in cell 1, or set EPCR_TABLE = None to")
        print("       build payloads without records.")
        raise

    EPCR_COLUMNS = list(epcr_raw.columns)

    print(f"trips in this pull : {len(wanted)}")
    print(f"epcr rows returned : {len(epcr_raw)}")
    print(f"epcr columns       : {len(EPCR_COLUMNS)}")
    print()

    if EPCR_JOIN_COLUMN not in EPCR_COLUMNS:
        raise ValueError(f"join column not in the epcr table: {EPCR_JOIN_COLUMN}")

    def _populated(row):
        hits = 0
        for column in EPCR_CONTENT_COLUMNS:
            if column not in EPCR_COLUMNS:
                continue
            value = row.get(column)
            if value is not None and str(value).strip() not in ("", "nan", "None"):
                hits += 1
        return hits

    # Second guard, independent of the SQL one. The subquery decided which trips
    # to pull; this decides whether the row that came back actually says
    # anything, which is what gets checked again at write time.
    EPCR_EMPTY_ROWS = 0
    for _, row in epcr_raw.iterrows():
        key = str(row[EPCR_JOIN_COLUMN])
        if _populated(row) == 0:
            EPCR_EMPTY_ROWS += 1
            continue
        EPCR_BY_TRIP.setdefault(key, []).append(row)

    if EPCR_EMPTY_ROWS:
        print(f"       {EPCR_EMPTY_ROWS} returned row(s) carried no clinical content")
        print("       and were dropped. A row can exist and say nothing.")
        print()

    multi = {k: len(v) for k, v in EPCR_BY_TRIP.items() if len(v) > 1}
    matched = 0
    for key in EPCR_BY_TRIP:
        flag = EPCR_BY_TRIP[key][0].get(EPCR_MATCH_FLAG_COLUMN)
        if str(flag).strip().upper() == EPCR_MATCH_FLAG_MEANS_MATCHED:
            matched += 1

    print(f"trips with a row       : {len(EPCR_BY_TRIP)} of {len(wanted)}")
    print(f"  {EPCR_MATCH_FLAG_COLUMN} = {EPCR_MATCH_FLAG_MEANS_MATCHED}"
          f"        : {matched}")
    print(f"  not matched          : {len(EPCR_BY_TRIP) - matched}")
    print(f"trips with no row      : {len(wanted) - len(EPCR_BY_TRIP)}")
    print()

    if multi:
        print(f"CHECK  {len(multi)} trip(s) returned more than one epcr row.")
        print("       Every row is written. A trip with two records is a data")
        print("       question, not something to resolve by picking one here.")
        for key in list(multi)[:5]:
            print(f"         {key}: {multi[key]} rows")
        print()

    if len(EPCR_BY_TRIP) == 0:
        print("CHECK  No trip in this pull has a record. Either the join column is")
        print("       wrong, or this pull predates the records. Inspect one id in")
        print("       both tables before going further.")
""")

md("""
### Which columns the service sends

The folder gets every column. The model does not: payment method, insurance,
patient gender, facility names and addresses are withheld at the point of the
call, and so are the two columns that carry the order-entry answers, since
re-reading those would make the second opinion a copy of the first.

That selection lives in `med_nec_api/prompts/epcr_fields.json` and is applied by
the service, not here. The list below is a **drift check only**: it is the set of
columns that spec accounts for. A column in the table and not in the list is one
the service has never seen and will ignore, which is worth knowing at pull time
rather than at assessment time.
""")

code("""
# Mirrors prompts/epcr_fields.json version 2026-10-22. Drift check, not a filter.
EPCR_SPEC_COLUMNS = [
    "TNET_TripRequestId", "EPCR_Patient_Age", "EPCR_Patient_Age_Units",
    "EPCR_Patient_Weight_Range_Lbs", "EPCR_Chief_Complaint",
    "EPCR_Primary_Symptom", "EPCR_Primary_Impression",
    "EPCR_Secondary_Impressions", "EPCR_Working_Diagnosis",
    "EPCR_Working_Diagnosis_Code", "EPCR_Initial_Acuity", "EPCR_Possible_Injury",
    "EPCR_Complaint_Anatomic_Location", "EPCR_Complaint_Organ_System",
    "EPCR_Initial_SBP", "EPCR_Initial_DBP", "EPCR_Initial_Heart_Rate",
    "EPCR_Initial_Resp_Rate", "EPCR_Initial_SpO2", "EPCR_Initial_GCS",
    "EPCR_Initial_Pain_Score", "EPCR_Initial_Blood_Glucose",
    "EPCR_Medications_Given", "EPCR_Procedures_Performed",
    "EPCR_Patient_Evaluation_Care", "EPCR_Level_Of_Care_Provided",
    "EPCR_Medical_Surgical_History", "EPCR_Current_Medications",
    "EPCR_Advance_Directives", "EPCR_Transfer_Reason_Category",
    "EPCR_Service_Requested", "EPCR_Transport_Method",
    "EPCR_Transport_Modification_Scene", "EPCR_Condition_At_Destination",
    "EPCR_Transport_Disposition", "EPCR_Unit_Disposition",
    "EPCR_Reason_For_Destination", "EPCR_Hospital_Inpatient_Destination",
    "EPCR_Narrative", "OPAP_Origin_Type", "OPAP_Destination_Type",
    "OPAP_From_Emergency_Dept", "OPAP_Incident_Type", "OPAP_Call_Type",
    "OPAP_Urgency_Reason", "OPAP_Transport_Priority",
    "OPAP_Level_Of_Service_Requested", "OPAP_IOS", "OPAP_Transport_Miles",
    "TNET_LevelOfService", "TNET_LevelOfServiceDescription",
    "EPCR_Primary_Payment_Method", "EPCR_Insurance_Companies",
    "EPCR_Patient_Gender", "EPCR_Destination_Name", "EPCR_Destination_Address",
    "EPCR_Agency_Name", "EPCR_Agency_Number", "OPAP_Origin_Name",
    "OPAP_Origin_Address", "OPAP_Origin_City", "OPAP_Origin_State",
    "OPAP_Origin_Zip", "OPAP_Destination_Name", "OPAP_Destination_Address",
    "OPAP_Destination_City", "OPAP_Destination_State", "OPAP_Destination_Zip",
    "OPAP_Initiating_Facility", "OPAP_Ordering_Facility", "OPAP_BU_Name",
    "OPAP_Region", "OPAP_Unit_Number", "TNET_CadName", "TNET_ContractName",
    "EPCR_Alcohol_Drug_Use", "EPCR_Medication_Allergies", "TNET_TripLegId",
    "TNET_chunkid", "TNET_ContractId", "TNET_ServiceType",
    "TNET_ServiceTypeDescription", "OPAP_GroundOPSKey", "OPAP_RunId",
    "OPAP_Master_Incident_ID", "OPAP_Call_Outcome", "MDM_PCRID",
    "MDM_MEDSPCR_ID", "MDM_GoldenRecord", "EPCR_Destination_Type",
    "TNET_LosQuestions", "TNET_ClinicalData", "TNET_RequestDate",
    "OPAP_Time_Call_Received", "OPAP_Time_Assigned", "OPAP_Time_Enroute",
    "OPAP_Time_At_Scene", "OPAP_Time_Patient_Contact",
    "OPAP_Time_Depart_Scene", "OPAP_Time_Arrived_Destination",
    "OPAP_Time_Call_Cleared",
]

if not EPCR_COLUMNS:
    print("No epcr columns pulled, nothing to compare.")
else:
    unknown = [c for c in EPCR_COLUMNS if c not in EPCR_SPEC_COLUMNS]
    missing = [c for c in EPCR_SPEC_COLUMNS if c not in EPCR_COLUMNS]

    print(f"columns in the table : {len(EPCR_COLUMNS)}")
    print(f"columns in the spec  : {len(EPCR_SPEC_COLUMNS)}")
    print()

    if not unknown and not missing:
        print("PASS   the table and the spec describe the same columns")
    if unknown:
        print(f"CHECK  {len(unknown)} column(s) in the table the spec does not list.")
        print("       The service will ignore these. Add them to epcr_fields.json,")
        print("       to send or to withhold, if any of them bear on necessity.")
        for c in unknown:
            print("        ", c)
        print()
    if missing:
        print(f"CHECK  {len(missing)} column(s) the spec expects and the table does")
        print("       not have. The service treats an absent column as absent, not")
        print("       as negative, so this is survivable, but confirm it is intended.")
        for c in missing[:15]:
            print("        ", c)
""")

md("""
Same identifier check as section 7, now run against both halves. Free text
written by a requester can name a patient even when the structured fields are
clean, and a crew narrative is free text by definition: it is written at the
bedside, in prose, by someone who has the patient's chart open.

The record also carries structured identifiers the trip request never had.
Destination address and agency name are in the file on purpose, since the folder
holds the full dataset, but they are what makes these folders something to keep
inside Databricks rather than attach to a ticket.
""")

code("""
import re

DOB_PATTERN = re.compile(r"\\b\\d{1,2}/\\d{1,2}/\\d{2,4}\\b")
SSN_PATTERN = re.compile(r"\\b\\d{3}-\\d{2}-\\d{4}\\b")
MRN_PATTERN = re.compile(r"\\b(?:mrn|medical record)\\s*[:#]?\\s*\\w+", re.IGNORECASE)

real_failures = []

for stem in REAL_PAYLOADS:
    trip = REAL_PAYLOADS[stem]
    patient = trip["tripLegs"][0]["patientInfo"]
    clinical = trip["tripLegs"][0]["clinicalData"]

    populated = []
    for key in patient:
        if key in ALLOWED_PATIENT_KEYS:
            continue
        if patient[key] not in ("", None, False):
            populated.append(key)

    dob_hits = DOB_PATTERN.findall(clinical)
    ssn_hits = SSN_PATTERN.findall(clinical)
    mrn_hits = MRN_PATTERN.findall(clinical)

    if populated or dob_hits or ssn_hits or mrn_hits:
        real_failures.append(stem)
        print(f"CHECK  {stem}")
        if populated:
            print(f"         patientInfo populated: {populated}")
        if dob_hits:
            print(f"         date-like strings in clinicalData: {dob_hits[:3]}")
        if ssn_hits:
            print(f"         SSN-like strings: {len(ssn_hits)} found")
        if mrn_hits:
            print(f"         MRN-like strings: {mrn_hits[:2]}")

print()
if real_failures:
    print(f"{len(real_failures)} of {len(REAL_PAYLOADS)} need review before they leave Databricks.")
    print("Free text can carry identifiers the structured fields do not. Read them.")
else:
    print(f"All {len(REAL_PAYLOADS)} clean on the automated checks.")
    print("Automated checks are not a substitute for reading a sample.")

EPCR_FREE_TEXT = ["EPCR_Narrative", "EPCR_Chief_Complaint", "EPCR_Primary_Impression",
                  "EPCR_Secondary_Impressions", "EPCR_Complaint_Anatomic_Location",
                  "EPCR_Complaint_Organ_System", "EPCR_Patient_Evaluation_Care",
                  "EPCR_Medical_Surgical_History", "EPCR_Current_Medications",
                  "EPCR_Reason_For_Destination", "TNET_LevelOfServiceDescription"]

epcr_flagged = {}

print()
print("--- patient care record free text ---")
print()

if not EPCR_BY_TRIP:
    print("No records pulled, nothing to scan.")
else:
    scanned = 0
    for key in EPCR_BY_TRIP:
        for row in EPCR_BY_TRIP[key]:
            hits = []
            for column in EPCR_FREE_TEXT:
                if column not in EPCR_COLUMNS:
                    continue
                text = row.get(column)
                if text is None or str(text).strip() in ("", "nan", "None"):
                    continue
                text = str(text)
                scanned += 1
                if DOB_PATTERN.findall(text):
                    hits.append((column, "date-like", DOB_PATTERN.findall(text)[:2]))
                if SSN_PATTERN.findall(text):
                    hits.append((column, "SSN-like", ["redacted"]))
                if MRN_PATTERN.findall(text):
                    hits.append((column, "MRN-like", MRN_PATTERN.findall(text)[:1]))
            if hits:
                epcr_flagged[key] = hits

    print(f"free text values scanned : {scanned}")
    print(f"trips flagged            : {len(epcr_flagged)}")
    print()

    for key in list(epcr_flagged)[:5]:
        print(f"CHECK  {key}")
        for column, kind, sample in epcr_flagged[key]:
            print(f"         {column}: {kind} {sample}")
    if len(epcr_flagged) > 5:
        print(f"... and {len(epcr_flagged) - 5} more")

    print()
    print("A narrative is written at the bedside and a crew can name anyone in it.")
    print("These patterns catch dates and record numbers. They do not catch names.")
    print("Read a sample of EPCR_Narrative before any of this leaves Databricks.")
""")

md("""
### 10d. Write one folder per trip

`json_payloads3/<trip request id>/` with `payload.json` and `epcr.csv` in it.

The csv carries every column the pull returned, in the order the table returned
them.

With `REQUIRE_EPCR` on, a trip whose record says nothing gets **no folder**, and
is listed in the output instead so the misses are still counted. An empty csv in
a folder is worse than no folder: it costs someone the trouble of opening it to
find out there is nothing there.

`shutil.copyfile` rather than `dbutils.fs.cp` because `/Workspace` paths are
reachable as ordinary files from the driver. The write goes to `/tmp` first so a
permissions failure on the workspace folder does not lose the work.
""")

code("""
real_written = []
real_copied = []
real_failed_copy = []
unpaired = []
epcr_written = 0
epcr_empty = 0

os.makedirs(JSON_OUTPUT_DIR, exist_ok=True)

for stem in REAL_PAYLOADS:
    if stem in real_failures:
        continue
    if len(real_written) >= MAX_PAYLOADS:
        break

    trip = REAL_PAYLOADS[stem]
    trip_request_id = str(trip["sourceSystemTripId"])

    # The pair rule, enforced where the folder is actually created. Nothing is
    # written for a trip whose record says nothing: an empty csv in a folder is
    # worse than no folder, because it costs someone the trouble of opening it.
    if REQUIRE_EPCR and not EPCR_BY_TRIP.get(trip_request_id):
        unpaired.append(trip_request_id)
        continue

    tmp_folder = os.path.join(TMP_DIR, RUN_TS, trip_request_id)
    os.makedirs(tmp_folder, exist_ok=True)

    tmp_payload = os.path.join(tmp_folder, "payload.json")
    with open(tmp_payload, "w") as handle:
        json.dump(trip, handle, indent=4)

    tmp_epcr = os.path.join(tmp_folder, "epcr.csv")
    rows = EPCR_BY_TRIP.get(trip_request_id, [])
    if rows:
        pd.DataFrame(rows)[EPCR_COLUMNS].to_csv(tmp_epcr, index=False)
        epcr_written += 1
    else:
        pd.DataFrame(columns=EPCR_COLUMNS or [EPCR_JOIN_COLUMN]).to_csv(
            tmp_epcr, index=False)
        epcr_empty += 1

    real_written.append((trip_request_id, tmp_folder))

    target_folder = os.path.join(JSON_OUTPUT_DIR, trip_request_id)
    try:
        os.makedirs(target_folder, exist_ok=True)
        shutil.copyfile(tmp_payload, os.path.join(target_folder, "payload.json"))
        shutil.copyfile(tmp_epcr, os.path.join(target_folder, "epcr.csv"))
        real_copied.append(target_folder)
    except Exception as exc:
        real_failed_copy.append((trip_request_id, f"{type(exc).__name__}: {exc}"))

eligible = len(REAL_PAYLOADS) - len(real_failures)

print(f"built              : {len(REAL_PAYLOADS)}")
print(f"held back          : {len(real_failures)} (failed the identifier check)")
if REQUIRE_EPCR:
    print(f"held back          : {len(unpaired)} (no populated record)")
print(f"eligible           : {eligible - len(unpaired)}")
print(f"MAX_PAYLOADS       : {MAX_PAYLOADS}")
print(f"written to /tmp    : {len(real_written)}")
print(f"copied to output   : {len(real_copied)}")
print()
print(f"folders with a record    : {epcr_written}")
print(f"folders with an empty csv: {epcr_empty}")
print()

if REQUIRE_EPCR and epcr_empty:
    print("FAIL   An empty csv was written with REQUIRE_EPCR on. That is a bug in")
    print("       this notebook, not a data finding. Do not ship these folders.")
    print()

if unpaired:
    print(f"{len(unpaired)} trip(s) had clinical data but no populated record, so no")
    print("folder was written for them. Set REQUIRE_EPCR = False to build those as")
    print("order-only folders.")
    print(f"  {', '.join(unpaired[:10])}{' ...' if len(unpaired) > 10 else ''}")
    print()

if eligible - len(unpaired) > MAX_PAYLOADS:
    print(f"{eligible - len(unpaired) - MAX_PAYLOADS} eligible trip(s) skipped by MAX_PAYLOADS.")
    print("Raise MAX_PAYLOADS in cell 1 to write more.")
    print()

if epcr_empty and not epcr_written:
    print("CHECK  Every csv is header only. No trip in this pull matched a record.")
    print("       Confirm the join column before treating this as a finding.")
    print()

if real_copied:
    print(f"in {JSON_OUTPUT_DIR}:")
    for path in real_copied[:10]:
        name = os.path.basename(path)
        size = os.path.getsize(os.path.join(path, "epcr.csv"))
        print(f"   {name}/   payload.json + epcr.csv ({size:,} bytes)")
    if len(real_copied) > 10:
        print(f"   ... and {len(real_copied) - 10} more")

if real_failed_copy:
    print()
    print(f"{len(real_failed_copy)} could not be copied, still in {TMP_DIR}/{RUN_TS}:")
    for trip_id, err in real_failed_copy[:5]:
        print(f"  {trip_id}: {err[:110]}")
""")

md("""
### Read one folder back

The check that the pair is usable: the payload parses, the csv has one row, and
the trip id in the csv is the folder name. Anything that fails here fails in the
service too.
""")

code("""
if not real_copied:
    print("Nothing written, nothing to read back.")
else:
    folder = real_copied[0]
    trip_id = os.path.basename(folder)

    with open(os.path.join(folder, "payload.json")) as handle:
        back = json.load(handle)

    record = pd.read_csv(os.path.join(folder, "epcr.csv"), dtype=str)

    print(f"folder                 : {trip_id}")
    print(f"payload trip id        : {back['sourceSystemTripId']}")
    print(f"payload losQuestions   : {len(back['tripLegs'][0]['losQuestions'])}")
    print(f"epcr rows              : {len(record)}")
    print(f"epcr columns           : {len(record.columns)}")
    print()

    if len(record) == 0:
        print("No record for this trip. The service scores the order and reports")
        print("the record as unmatched rather than as a negative.")
    else:
        row = record.iloc[0]
        key_in_csv = str(row.get(EPCR_JOIN_COLUMN))
        print(f"epcr {EPCR_JOIN_COLUMN:<18}: {key_in_csv}")
        if key_in_csv != trip_id:
            print("FAIL   the csv is for a different trip than the folder name")
        else:
            print("PASS   folder name, payload and csv agree")
        print()

        populated = [c for c in record.columns
                     if str(row.get(c)).strip() not in ("", "nan", "None")]
        print(f"populated columns      : {len(populated)} of {len(record.columns)}")
        print()
        for column in populated[:20]:
            value = str(row[column])
            print(f"   {column:38} {value[:60]}")
        if len(populated) > 20:
            print(f"   ... and {len(populated) - 20} more")
""")

md("""
## What to do with these

Copy a folder out of `json_payloads3` and give it to the service. In the web UI,
select both files at once: the payload is read as the order and the csv as the
record, and the two assessments appear one above the other.

The service reads `payload.json` on its own happily, so a folder with an empty
csv is still a usable test. It will say the record is unmatched rather than
treating an absent record as evidence against the trip.

Nothing in `json_payloads3` is de-identified. The payload is scrubbed; the csv is
not, and it carries destination addresses, agency names and a crew narrative. It
stays inside Databricks until someone has read a sample and said otherwise.

### What the pair is for

Two assessments of the same transport, one from what was said beforehand and one
from what was written afterwards. Where they agree, the order-entry guidance is
predicting what the record will support, which is the whole point of asking at
order entry. Where they disagree, one of them is wrong, and which one decides
what gets fixed: the guidance, or the documentation.

Neither number means much until a reviewer has labelled a sample. Until then this
is a disagreement rate, not an accuracy rate.
""")

nb["cells"] = C
nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
nb.metadata["language_info"] = {"name": "python", "version": "3.11"}

with open("/home/claude/med_nec_payload_builder/med_nec_payload_builder.ipynb", "w") as handle:
    nbf.write(nb, handle)

print(f"written: {len(C)} cells, {sum(1 for c in C if c.cell_type == 'code')} code")
