# Phase 1 EDA — What We're Solving and How This Notebook Gets Us There

## The Goal

The new operating system goes live before year-end. When it does, our reported numbers are going to move —
possibly a lot — because the new system measures navigation differently than the old one.

The problem is we can't currently explain *why* any navigation decision was made. The system records where
the patient was sent, but the reasoning lives only in free-text nurse notes. Today the only way to answer a
client's question is to read notes one at a time.

**This notebook builds the historical baseline** so that when the numbers shift at go-live, we can tell each
client exactly what changed and why — before they see it in a dashboard.

## The Three Buckets

| Bucket | Size today | What we need to know |
|---|---|---|
| **Self-care** | ~18–20% of navigations | How much of this was truly "no care needed" versus a patient driving themselves to urgent care? |
| **NMTARA 6** | Triage not completed | Why did triage fail? Assumed to be mostly patient refusal, but unverified. |
| **1–5 ambulance overrides** | Triage said no ambulance, nurse sent one | What drove the override — patient demand, nothing else open, mobility, or clinical judgment? |

All three are needed together. One bucket alone doesn't make a complete change-management conversation.

## How the Notebook Solves It

The notebook works in three stages: **prove the data is trustworthy**, **extract the reasons**, then
**restate the baseline**.

### Stage 1 — Prove the data is trustworthy (Sections 1–5)

Before analyzing anything, the notebook answers the questions that would invalidate the results:

- **What counts as a call?** Every time a nurse picks up the phone, a "work set ID" is created. One patient
  can generate several, and some are purely operational — the nurse calling a facility, confirming a ride.
  If we count those as navigations, every percentage we report is wrong. The notebook builds an episode-level
  view and separates operational records from clinical ones.

- **Are the notes good enough?** The working assumption is roughly 25% of notes won't have enough detail.
  The notebook measures this per bucket rather than assuming it, so if one bucket has thin documentation we
  say so up front instead of discovering it in the results.

- **Are the reasons even in the text?** A cheap keyword pass tests whether the reasons we expect — no
  provider available, patient refused, facility closed, mobility barrier — actually appear in the notes. This
  runs before any AI spend and produces the candidate list of reason categories.

### Stage 2 — Extract the reasons (Sections 6–7)

This reuses the pipeline already built in `nurse_nav_eda.py`, retargeted from ED-appropriateness to the
three buckets. Two design choices matter for the business:

**The AI extracts facts; it does not make the judgment call.** The model pulls out what the note says — where
the patient actually ended up, how they got there, what got in the way. A separate, deterministic rules layer
turns those facts into categories. This means clinical leadership can change the business rules without
re-running the AI, and no one has to trust a black box.

**Every finding is backed by a verbatim quote.** If the extraction says "no provider was available," it must
cite the exact sentence in the note that says so. That makes the output auditable — Dr. Stites or
Dr. Troutman can review the evidence rather than accept a score.

The notebook then **recasts history into the new framework**: splitting today's combined outcomes
("rideshare to ER," "self-care") into the three separate decisions the new system will capture — how fast,
where, and how they get there. This is what makes before-and-after comparable.

### Stage 3 — Restate the baseline (Sections 8–9)

- **Validation** against the cases Anisa's team already coded by hand, with the disagreements listed
  individually for review. This is the trust-building step before anything reaches a client.

- **Before-and-after tables**, national and per client, showing today's reported numbers next to the restated
  numbers and the size of the gap. This is the deliverable the account teams use.

The self-care restatement is the headline output: if the bucket breaks down into urgent care and virtual care,
the drop at go-live is a good-news story. If a meaningful share was actually going to the ED, that's a
conversation we need to prepare for.

## What This Notebook Deliberately Does Not Do

It does not train anything to score future calls. Historical notes reflect the old homegrown protocol; the
new system moves to the Schmitt Thompson standard, which means nurses will be asking different questions.
This is a **one-time historical baseline**, not a production model.

## What We Need to Proceed

| Item | Owner |
|---|---|
| Confirm the correct episode key and operational-call flag; reconcile totals against Power BI | Rich |
| Confirm NMTARA code definitions and Logis field meanings | Nathan Haron |
| Confirm the human-coded validation set and its label column | Anisa |
| Review the evidence sample; sign off on reason categories | Dr. Stites / Dr. Troutman |
| Decide whether the historical reason categories become the structured override reason codes in the new build | Anisa / Shelly |

That last item is the highest-leverage one. If the categories we find in the history become the dropdown the
nurses see in the new system, the baseline and the go-forward reporting line up automatically — and we never
have to do this analysis again.
