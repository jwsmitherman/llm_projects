import React, { useState } from 'react'
import Icon from './Icon.jsx'

// Embeds a Power Apps canvas app in-place.
//
// The URL must carry ?source=iframe. A URL copied straight from the browser
// address bar will not frame correctly.
//
//   https://apps.powerapps.com/play/e/{environmentId}/a/{appId}?tenantId={tenantId}&source=iframe
//
// screenColor should roughly match the app's loading background so the frame
// doesn't flash white before the app paints.

const SCREEN_COLOR = 'rgba(76,29,149,1)' // --brand-700

export default function PowerAppFrame({ url, title }) {
  const [state, setState] = useState('loading')

  if (!url) return null

  const src = url.includes('source=')
    ? url
    : `${url}${url.includes('?') ? '&' : '?'}source=iframe&screenColor=${SCREEN_COLOR}`

  return (
    <div className="paframe">
      {state === 'loading' && (
        <div className="paframe__state">
          <span className="paframe__spinner" />
          <p>Loading {title}…</p>
        </div>
      )}

      {state === 'error' && (
        <div className="paframe__state">
          <Icon name="TriangleAlert" size={22} />
          <p>
            Couldn't load {title} here. Check that the app is shared with you and that the
            URL includes <code>?source=iframe</code>.
          </p>
          <a className="paframe__fallback" href={url} target="_blank" rel="noreferrer">
            Open in a new tab instead
          </a>
        </div>
      )}

      <iframe
        className="paframe__iframe"
        src={src}
        title={title}
        onLoad={() => setState('ready')}
        onError={() => setState('error')}
        allow="geolocation; microphone; camera; fullscreen; clipboard-write"
        data-state={state}
      />
    </div>
  )
}
