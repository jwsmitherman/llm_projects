# Grace.ai

React front end for the Grace.ai hospice care companion, built to the approved mockup:
brand home screen, four practice areas, tool grids, and a bottom tab bar. Renders in a
phone frame on desktop for review and goes full-bleed on an actual phone.

## Run it

Needs Node 20 or newer (`node -v` to check).

```bash
npm install     # once
npm run dev     # http://localhost:5173
```

That's the whole setup. Sign-in accepts any name — it's a demo gate, not auth.

To see it the way it behaves in production (built assets, gzip, real caching):

```bash
npm run local   # builds, then serves on http://localhost:8080
```

### It runs with no internet

Fonts are bundled from `node_modules` rather than fetched from Google, and nothing else
in the app calls out. After `npm install` finishes you can pull the network cable and it
works — verified by loading the app with all non-localhost requests blocked.

### If something goes wrong

| Symptom | Fix |
| --- | --- |
| `EADDRINUSE` on 5173 | `npm run dev -- --port 5174` |
| `Unexpected token '??='` or similar | Node is too old — needs 20+ |
| Blank page, console mentions modules | You opened `dist/index.html` directly; browsers block ES modules over `file://`. Use `npm run local`. |
| Fonts look wrong after editing | Delete `node_modules/.vite` and restart |

## Where the content lives

Everything on every screen comes from `src/data/catalog.js`. Add, rename, or reorder a
tool there and the grids update; no component changes needed.

Two of the four areas are marked `draft: true`:

| Area | Status |
| --- | --- |
| Frontline Agent Assistants | From the mockup — 10 tools |
| Compliance Audits | From the mockup — 12 tools |
| Clinical Care Quality | **Placeholder** — plausible items pending sign-off |
| Back Office Agentic Workflows | **Placeholder** — plausible items pending sign-off |

Draft areas show a "Draft" chip on the home tile and a banner on the screen, so nobody in
a review mistakes invented scope for approved scope. Delete the `draft: true` line once
the real list lands.

## What's real and what isn't

Real: navigation, layout, the two approved tool lists, responsive behaviour, the sign-in
screen.

Not real: every tool opens a "Not built yet" screen. There's no data layer, no EHR
integration, no AI calls. The screens exist so the flow can be walked end to end in a
review without dead ends.

The hero has a marked photography slot rather than a stock image — drop the approved
BrightSpring asset in as a background on `.hero__art`.

## Layout

```
server.js                  Express host for App Service
src/
  App.jsx                  navigation state, phone frame, tab bar
  data/catalog.js          all screen content
  components/Icon.jsx      explicit lucide icon map
  screens/Home.jsx
  screens/Category.jsx     the tool grids
  screens/Tool.jsx         per-tool stub
  screens/SignIn.jsx
  styles.css               palette and type tokens at the top
```

## Deploying

Nothing here depends on Azure — `npm run dev` is the whole story for local work. When you
do want it hosted, [DEPLOY.md](./DEPLOY.md) and `.github/workflows/azure-deploy.yml`
cover the App Service path. Delete both if you'd rather not carry them.
