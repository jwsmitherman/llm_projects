import React from 'react'
import { createRoot } from 'react-dom/client'

// Fonts are bundled from node_modules, not fetched from a CDN — the app runs
// with no network access at all once `npm install` has finished.
import '@fontsource/inter/latin-400.css'
import '@fontsource/inter/latin-500.css'
import '@fontsource/inter/latin-600.css'
import '@fontsource/inter/latin-700.css'
import '@fontsource/playfair-display/latin-500.css'

import App from './App.jsx'
import './styles.css'

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
