// Every screen in the app is generated from this file.
//
// To embed a Power Apps canvas app in a tool screen, add powerAppUrl to that
// tool. The URL MUST include ?source=iframe — a URL copied from the browser
// address bar will not frame:
//
//   { icon: 'Mic', name: 'Dictation', blurb: '...',
//     powerAppUrl: 'https://apps.powerapps.com/play/e/<env>/a/<app>?tenantId=<tenant>&source=iframe' }
//
// Without powerAppUrl the tool opens the "Not built yet" stub. To add or rename a tool,
// edit it here — no component changes needed.
//
// The Frontline Agent Assistants and Compliance Audits lists come straight from
// the approved mockup. Clinical Care Quality and Back Office Agentic Workflows
// are PLACEHOLDERS: plausible hospice workflows standing in until the real lists
// are signed off. They are marked `draft: true` and render a "Draft" chip so
// nobody mistakes them for approved scope.

export const brand = {
  product: 'Grace',
  suffix: '.ai',
  tagline: 'Your Hospice Care AI Companion',
  blurb:
    'Compassionate intelligence, automation, and support so every moment matters.',
  sealTop: 'Comfort · Dignity · Peace',
  sealBottom: 'Every Moment, Every Family',
  footer: 'Honoring lives. Supporting families. Together.',
  org: 'BrightSpring Health Services',
}

export const categories = [
  {
    id: 'frontline',
    name: 'Frontline Agent Assistants',
    short: 'Frontline\nAgent Assistants',
    icon: 'Headset',
    heading: 'Tools that empower you at every visit.',
    description:
      'AI-powered assistants to help you deliver compassionate care, reduce documentation time, and focus on what matters most — your patients and families.',
    tools: [
      { icon: 'FileText', name: 'Visit Notes', blurb: 'Capture accurate visit notes with ease.' },
      { icon: 'Mic', name: 'Dictation', blurb: 'Speak your notes and let AI turn them into structured documentation.' },
      { icon: 'HeartHandshake', name: 'Care Plans', blurb: 'Create and update patient-centered care plans.' },
      { icon: 'Pill', name: 'Medication Documentation', blurb: 'Ensure accurate medication records and reconciliation.' },
      { icon: 'Activity', name: 'Symptom & Pain Assessment', blurb: 'Track and manage symptoms and comfort levels.' },
      { icon: 'Target', name: 'Goals of Care Documentation', blurb: 'Document goals of care and advance directives.' },
      { icon: 'MessagesSquare', name: 'Family Communication Notes', blurb: 'Record meaningful updates for families.' },
      { icon: 'Users', name: 'Volunteer & Bereavement Support', blurb: 'Coordinate support for patients and families.' },
      { icon: 'Package', name: 'Equipment & Supply Management', blurb: 'Track and request equipment and supplies.' },
      { icon: 'BadgeCheck', name: 'Hospice Eligibility Support', blurb: 'Assist with eligibility information and guidance.' },
    ],
  },
  {
    id: 'quality',
    name: 'Clinical Care Quality',
    short: 'Clinical\nCare Quality',
    icon: 'Stethoscope',
    draft: true,
    heading: 'Keep quality visible.',
    description:
      'Monitor outcomes, close the loop on findings, and keep clinical performance in view across every team.',
    tools: [
      { icon: 'BarChart3', name: 'Quality Measure Review', blurb: 'Review performance against required measures.' },
      { icon: 'Upload', name: 'HIS Submission Tracking', blurb: 'Track Hospice Item Set submissions and timeliness.' },
      { icon: 'MessageSquareHeart', name: 'CAHPS Hospice Survey', blurb: 'Monitor family experience survey results.' },
      { icon: 'Thermometer', name: 'Symptom Management Outcomes', blurb: 'Assess comfort outcomes across the caseload.' },
      { icon: 'TriangleAlert', name: 'Incident & Event Review', blurb: 'Review events and track follow-up actions.' },
      { icon: 'ClipboardList', name: 'Chart Audits', blurb: 'Sample charts and surface documentation gaps.' },
      { icon: 'GraduationCap', name: 'Clinical Competency Tracking', blurb: 'Track competencies and required training.' },
      { icon: 'GitCompareArrows', name: 'Care Plan Effectiveness', blurb: 'Compare care plan goals against outcomes.' },
    ],
  },
  {
    id: 'backoffice',
    name: 'Back Office Agentic Workflows',
    short: 'Back Office\nAgentic Workflows',
    icon: 'Workflow',
    draft: true,
    heading: 'Run the work behind the care.',
    description:
      'Agentic workflows that move referrals, authorizations, billing, and staffing forward without the manual chase.',
    tools: [
      { icon: 'Inbox', name: 'Referral Intake', blurb: 'Capture and triage incoming referrals.' },
      { icon: 'FileCheck2', name: 'Eligibility & Authorization', blurb: 'Verify coverage and manage authorizations.' },
      { icon: 'Receipt', name: 'Billing & Claims', blurb: 'Prepare claims and resolve billing exceptions.' },
      { icon: 'CalendarClock', name: 'Scheduling & Staffing', blurb: 'Match visits to available clinicians.' },
      { icon: 'UserPlus', name: 'Staff Onboarding', blurb: 'Move new hires through onboarding steps.' },
      { icon: 'ShoppingCart', name: 'Supply Ordering', blurb: 'Automate routine supply replenishment.' },
      { icon: 'Building2', name: 'Vendor Management', blurb: 'Track vendor contracts and performance.' },
      { icon: 'PieChart', name: 'Reporting & Analytics', blurb: 'Assemble operational reports on request.' },
    ],
  },
  {
    id: 'compliance',
    name: 'Compliance Audits',
    short: 'Compliance\nAudits',
    icon: 'ShieldCheck',
    heading: 'Ensure compliance. Reduce risk.',
    description:
      'Comprehensive audits and insights to help you meet regulatory requirements and maintain quality standards.',
    tools: [
      { icon: 'Landmark', name: 'Hospice Conditions of Participation', blurb: 'Ensure compliance with CoPs.' },
      { icon: 'ClipboardCheck', name: 'Plan of Care Compliance', blurb: 'Verify plan content and regulatory compliance.' },
      { icon: 'FileSearch', name: 'Documentation Compliance', blurb: 'Identify gaps and ensure complete documentation.' },
      { icon: 'HeartHandshake', name: 'Bereavement Program Compliance', blurb: 'Ensure bereavement program requirements are met.' },
      { icon: 'Pill', name: 'Medication Compliance', blurb: 'Monitor medication adherence and reconciliation.' },
      { icon: 'Biohazard', name: 'Infection Prevention Compliance', blurb: 'Ensure adherence to infection control standards.' },
      { icon: 'CalendarSearch', name: 'Visit Utilization Compliance', blurb: 'Ensure visits align with coverage requirements.' },
      { icon: 'MapPinCheck', name: 'Electronic Visit Verification (EVV)', blurb: 'Ensure EVV accuracy and compliance.' },
      { icon: 'BarChart3', name: 'Quality Measure Compliance', blurb: 'Track and improve performance on required measures.' },
      { icon: 'ListChecks', name: 'Corrective Actions Tracking', blurb: 'Track issues and monitor resolutions.' },
      { icon: 'FileBadge', name: 'CTI Audit', blurb: 'Validate Certificate of Terminal Illness completion.' },
      { icon: 'PieChart', name: 'Compliance Dashboards', blurb: 'Monitor compliance performance and audit insights.' },
    ],
  },
]

export const tabs = [
  { id: 'home', label: 'Home', icon: 'House' },
  { id: 'patients', label: 'Patients', icon: 'Users' },
  { id: 'insights', label: 'Insights', icon: 'ChartNoAxesColumn' },
  { id: 'more', label: 'More', icon: 'Ellipsis' },
]
