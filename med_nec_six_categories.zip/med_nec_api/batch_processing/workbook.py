"""Builds the review workbook from a completed batch run.

The sheets exist because of what was asked for in the 29 October review:

  "is there a way to take this blob and turn it into structured data so that we
   can easily see what the input was? Because you can't at scale look at this."

  "I want to look at this for 1000 calls, but in a spreadsheet or somewhere we
   can quickly go through a whole bunch together over an hour or two."

  "here's the question, here's the answer, whether it met the criteria, the
   evidence, the reason, and then the confidence level."

The 6 November review changed the shape of it:

  Dave: "I think these are independent. I think we should score on each category
   for each trip, because one trip could be that they could have an altered LOC,
   they could be unconscious, and they could also have a mobility restriction."

The categories are the six from the in-person meeting doc: mobility, level of
consciousness, medical monitoring, level of service, modifiers, and isolation
precautions. Four are read from the words on the order. Level of service and
modifiers are read off the payload, because the order already states them, and
the modifier scale comes from prompts/med_nec_knowledge.json rather than being
restated here.

  Dave: "If there's a way to pull all this together into a way that we can just
   look it up really succinctly for each one, and then look at 51 after the
   other ... we need it in a way that we can hit a whole bunch of these one
   after the other without jumping around."

  Mukund: "if possible, break down the EPCR data into the columns so that we
   have that ready to view, not just as a blob."

So this writes ONE sheet. One row per trip, every column block on that row:
the category scores, the order verdict, the record verdict, each question with
what the model made of it, the ePCR field by field, and the de-identification
evidence. There are no other tabs to jump between, which is the whole point.

Not changed, on purpose. Dave on the clarifying-question wording: "I'm not
ready to change anything. We should review a whole bunch of these at scale, and
then figure out if a pattern emerges." The prompts are untouched here.
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill

# Origin and destination codes read as words, so a reviewer is not decoding
# letters. These are the CMS modifiers.
MODIFIERS = {
    "H": "Hospital", "S": "Skilled nursing facility", "P": "Physician office",
    "R": "Residence", "E": "Residential/domiciliary/custodial facility",
    "N": "Skilled nursing facility", "D": "Diagnostic or therapeutic site",
    "J": "Freestanding ESRD facility", "G": "Hospital-based ESRD facility",
    "X": "Intermediate stop", "I": "Site of transfer",
}

# The six categories from the in-person meeting doc (Categories_in_person_meeting,
# 23 October). Four are decided from the words on the order; the other two are
# read off the payload itself, because the order already carries them as fields:
# level of service is stated on the leg, and the modifiers are the origin and
# destination codes.
#
# The word-matched four. Matched on word boundaries against text normalised to
# plain words, so "altered_mental" (a criterion id) and "Altered mental status?"
# (the question a nurse sees) both hit the same entry. Writing these with
# underscores and matching them raw was the earlier defect: every finding whose
# only clue was in prose fell through to the catch-all.
CATEGORIES = {
    "Mobility": ("bed confined", "bed confinement", "bedbound", "bed bound",
                 "cannot sit", "sit safely", "mobility", "ambulate", "ambulatory",
                 "non ambulatory", "stretcher", "gurney", "contraindicated other means",
                 "weight bearing", "transfer assist", "person assist", "assist",
                 "contracture", "positioning", "wheelchair", "hoyer", "lift",
                 "bariatric", "fall risk", "immobile"),
    "Level of consciousness": (
                  "altered mental", "altered loc", "loc", "mental status", "sedation",
                  "sedated", "confusion", "confused", "unresponsive", "unconscious",
                  "behavioral", "psychiatric", "psych", "consciousness", "gcs",
                  "mentation", "oriented", "orientation", "a o", "dementia",
                  "delirium", "agitated", "agitation", "combative", "sitter",
                  "edo", "emergency detention"),
    "Medical monitoring": (
                   "cardiac", "iv", "intravenous", "oxygen", "o2", "airway",
                   "suction", "ventilator", "vent", "trach", "bipap", "cpap",
                   "medication", "medications", "vitals", "vital signs", "monitor",
                   "monitoring", "monitored", "infusion", "drip", "pump",
                   "restraint", "restraints", "telemetry", "ecg", "ekg", "spo2",
                   "saturation", "titrate", "wound", "drain"),
    "Isolation precautions": (
                   "isolation", "precautions", "contact precautions",
                   "droplet", "airborne", "quarantine", "ppe", "mrsa", "vre",
                   "c diff", "cdiff", "clostridium", "tuberculosis", "tb",
                   "covid", "infectious", "communicable"),
}

CATEGORY_PATTERNS = {
    name: [re.compile(r"\b" + re.escape(term) + r"\b") for term in terms]
    for name, terms in CATEGORIES.items()
}

# The two read from the payload rather than from the words.
DATA_CATEGORIES = ["Level of service", "Modifiers"]

CATEGORY_ORDER = list(CATEGORIES) + DATA_CATEGORIES


def load_modifier_scale() -> List[str]:
    """The origin/destination codes, lowest to highest, from the knowledge file.

    Read rather than restated, so the scale the workbook scores against is the
    same one the model is briefed on. If the file moves, the fallback is that
    same list as of the 23 October knowledge build.
    """
    path = Path(__file__).resolve().parent.parent / "prompts" / "med_nec_knowledge.json"
    try:
        trees = json.loads(path.read_text()).get("decision_trees") or {}
        scale = [entry["code"] for entry
                 in trees.get("modifier_scale_lowest_to_highest") or []]
        if scale:
            return scale
    except Exception:
        pass
    return ["S", "R", "E", "P", "N", "D", "J", "G", "X", "H"]


MODIFIER_SCALE = load_modifier_scale()


def score_level_of_service(los: Any) -> Dict[str, Any]:
    """Level of service as its own category, read off the leg.

    ALS and SCT are ordered when the facility expects advanced intervention en
    route, which is the thing this category is meant to capture. BLS is scored 1
    rather than 0 because the level was stated, it just carries less on its own.
    """
    text = _words(los).strip()
    if not text:
        return {"score": 0, "label": "not stated on the order", "confidence": None,
                "evidence": "", "criteria": ""}
    if "sct" in text or "specialty" in text:
        return {"score": 2, "label": "SCT ordered", "confidence": "High",
                "evidence": str(los), "criteria": "level_of_service"}
    if "als" in text:
        return {"score": 2, "label": "ALS ordered", "confidence": "High",
                "evidence": str(los), "criteria": "level_of_service"}
    if "bls" in text:
        return {"score": 1, "label": "BLS ordered", "confidence": "High",
                "evidence": str(los), "criteria": "level_of_service"}
    return {"score": 1, "label": f"stated as {los}", "confidence": "Medium",
            "evidence": str(los), "criteria": "level_of_service"}


def score_modifiers(pickup: Any, dropoff: Any) -> Dict[str, Any]:
    """Origin and destination as their own category.

    Scored by the rule already in prompts/med_nec_knowledge.json: "Use the
    higher level of care tree when the origin modifier is lower on the scale
    than the destination ... the lower level of care tree when the origin is
    higher than or similar to the destination, such as discharges to a residence
    or nursing home."

    So an upward transport scores 2: it is the case the higher-level tree
    governs. A discharge direction scores 1, meaning the pair alone does not
    carry the trip. Codes missing scores 0, which is a data problem to see.
    """
    origin = str(pickup or "").strip().upper()
    destination = str(dropoff or "").strip().upper()
    words = f"{MODIFIERS.get(origin, origin or '?')} to {MODIFIERS.get(destination, destination or '?')}"

    if not origin or not destination:
        return {"score": 0, "label": "origin or destination code missing",
                "confidence": None, "evidence": words, "criteria": ""}
    if origin not in MODIFIER_SCALE or destination not in MODIFIER_SCALE:
        return {"score": 1, "label": f"{origin} to {destination}, not on the scale",
                "confidence": "Low", "evidence": words, "criteria": "modifiers"}

    here, there = MODIFIER_SCALE.index(origin), MODIFIER_SCALE.index(destination)
    if there > here:
        label = f"{origin} to {destination}, upward, higher level of care tree"
        score, confidence = 2, "High"
    elif there == here:
        label = f"{origin} to {destination}, same level"
        score, confidence = 1, "Medium"
    else:
        label = f"{origin} to {destination}, discharge direction, lower level of care tree"
        score, confidence = 1, "Medium"
    return {"score": score, "label": label, "confidence": confidence,
            "evidence": words, "criteria": "modifiers"}


def _words(*parts: Any) -> str:
    """Lower case, punctuation to spaces. "A&O x1-2" -> " a o x1 2 "."""
    return " " + re.sub(r"[^a-z0-9]+", " ", " ".join(
        str(p or "") for p in parts).lower()).strip() + " "


def categories_for(criterion_id, question, answer, evidence=None,
                   reason=None) -> List[str]:
    """Every category a finding touches, not just the first one matched.

    Dave, 6 November: "these are independent ... one trip could be that they
    could have an altered LOC, they could be unconscious, and they could also
    have a mobility restriction."

    A finding naming both a stretcher and cardiac monitoring belongs in mobility
    AND monitoring. Returning one primary category lost the second, which is
    what the review found. The model's quoted evidence counts too, because that
    is where the second category usually shows up: the question asks about
    special handling, the quote is what the handling was.
    """
    haystack = _words(criterion_id, question, answer, evidence, reason)
    return [name for name, patterns in CATEGORY_PATTERNS.items()
            if any(p.search(haystack) for p in patterns)]


_NEGATIVE = re.compile(
    r"^(no|none|n a|not applicable|negative|denies|unknown|nil|false|0)\b")


def is_negative(answer: Any) -> bool:
    """Whether an answer says the thing was not the case.

    Deliberately narrow: it reads the start of the answer only, so "No" and
    "No (Discharge, Behavioral Transfer or Other Reason)" both count, while an
    answer that happens to contain the word "no" further in does not.
    """
    text = _words(answer).strip()
    return bool(text) and bool(_NEGATIVE.match(text))


def score_category(findings: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Roll a category's findings up into one score.

    Derived here from what the model already returned per question. The model is
    not asked to score categories, so nothing about the determination changes.

    2  supports    a criterion in this category is documented and cited
    1  insufficient the category is addressed, but not enough on its own
    0  not documented, or asked and answered no

    A category is matched on the words in the question, so a question that names
    the category and is answered "No" lands here too: the EDO question on every
    Texas order mentions detention whatever the answer, and an answer listing
    "Behavioral Transfer" among its options mentions behaviour even when that
    option was not the one chosen. Scoring those 1 would read as "addressed but
    short", which is wrong. Asked and answered no is 0.
    """
    if not findings:
        return {"score": 0, "label": "not documented", "confidence": None,
                "evidence": "", "criteria": ""}

    supporting = [f for f in findings if f.get("nonMedNec") is False
                  and (f.get("criterionId") or f.get("evidence"))]
    if supporting:
        best = supporting
        score, label = 2, "supports"
    elif all(is_negative(f.get("answer")) for f in findings):
        best = findings
        score, label = 0, "asked, answered no"
    else:
        best = findings
        score, label = 1, "insufficient"

    rank = {"High": 3, "Medium": 2, "Low": 1}
    confidence = max((f.get("confidence") for f in best if f.get("confidence")),
                     key=lambda c: rank.get(c, 0), default=None)

    return {
        "score": score,
        "label": label,
        "confidence": confidence,
        "evidence": " | ".join(str(f.get("evidence")) for f in best
                               if f.get("evidence"))[:600],
        "criteria": ", ".join(sorted({str(f.get("criterionId")) for f in best
                                      if f.get("criterionId")})),
    }


def question_of(pair: Dict[str, Any]) -> Any:
    """The question text, whichever key the pair came in under.

    The parser emits "question"; the structured losQuestions path emits
    "questionText". Reading only one of them left every Q column blank for
    production orders, which is the other half of the "question = None" Dave
    saw in the workbook: the first half was the parser, this was the reader.
    """
    return pair.get("question") or pair.get("questionText")


def duplicate_flag(r: Dict[str, Any]) -> str:
    """Whether this trip was submitted more than once, and whether it mattered.

    Josh found these by hand: two payloads under one trip id. Only the latest is
    scored, so the distinction a reviewer needs is whether the earlier
    submission said something different.
    """
    count = r.get("payloadCount") or 1
    if count <= 1:
        return ""
    variants = r.get("payloadVariants") or 1
    if variants > 1:
        return f"YES, {count} submissions, {variants} differ"
    return f"resubmitted {count}x, identical"


# Columns the ePCR extract may carry that no reviewer needs and that would put
# identifiers back into a workbook people email around. The extract is scrubbed
# for identifier patterns inside free text, not column by column, so this is the
# column-level half of that. Substring match, case-insensitive, deny by name.
RECORD_WITHHOLD = (
    "name", "dob", "birth", "ssn", "mrn", "address", "street", "city", "zip",
    "postal", "phone", "email", "insur", "payer", "payor", "payment", "policy",
    "member", "subscriber", "account", "guarantor", "medicaid", "medicare",
    "licen", "crew", "employee", "unit_number", "vehicle",
)

# Shown first, in this order, because this is what decides the verdict. Anything
# else the extract carries follows, so the tab is the whole record rather than a
# curated slice of it.
RECORD_LEAD = [
    "EPCR_Level_Of_Care_Provided", "EPCR_Transport_Method",
    "EPCR_Primary_Impression", "EPCR_Secondary_Impressions",
    "EPCR_Chief_Complaint", "EPCR_Working_Diagnosis",
    "EPCR_Procedures_Performed", "EPCR_Medications_Given",
    "EPCR_Initial_SBP", "EPCR_Initial_DBP", "EPCR_Initial_Heart_Rate",
    "EPCR_Initial_Respiratory_Rate", "EPCR_Initial_SpO2", "EPCR_Initial_GCS",
    "EPCR_Patient_Evaluation_Care", "EPCR_Medical_Surgical_History",
    "EPCR_Current_Medications", "EPCR_Reason_For_Destination",
    "EPCR_Narrative",
]


def record_columns(seen: Dict[str, Any]) -> Dict[str, Any]:
    """The ePCR row broken into its own columns, lead fields first.

    Mukund, 6 November: "if possible, break down the EPCR data into the columns
    so that we have that ready to view, not just as a blob."
    """
    ACRONYMS = {"sbp": "SBP", "dbp": "DBP", "hr": "HR", "spo2": "SpO2",
                "gcs": "GCS", "bp": "BP", "ekg": "ECG", "ecg": "ECG",
                "bls": "BLS", "als": "ALS", "iv": "IV", "los": "LOS",
                "epcr": "ePCR", "id": "id"}

    def label(field: str) -> str:
        words = field.replace("EPCR_", "").replace("TNET_", "").split("_")
        out = [ACRONYMS.get(w.lower(), w.lower()) for w in words if w]
        return " ".join(out)[:1].upper() + " ".join(out)[1:]

    out: Dict[str, Any] = {}
    for field in RECORD_LEAD:
        if field in seen:
            out[label(field)] = seen.get(field)
    # The trip id is already the first column of every tab.
    rest = [f for f in seen
            if f not in RECORD_LEAD
            and "triprequestid" not in f.lower()
            and not any(bad in f.lower() for bad in RECORD_WITHHOLD)]
    for field in sorted(rest):
        out.setdefault(label(field), seen.get(field))
    return out


def agreement(order_meets, record_meets) -> str:
    if order_meets is None or record_meets is None:
        return "no record verdict"
    if order_meets == record_meets:
        return "agree"
    return "order meets, record does not" if order_meets else "record meets, order does not"


def yes_no(value: Any) -> Any:
    """True/False as words. Excel renders a bare bool as 0 or 1 in a mixed
    column, and "0" in a column headed "meets" is a verdict nobody should have
    to decode."""
    if value is True:
        return "yes"
    if value is False:
        return "no"
    return ""


def build(results: List[Dict[str, Any]], out_path: Path, scored: bool) -> Path:
    """One sheet. Everything about a trip on that trip's row.

    Dave, 6 November: "Is there a way to have all this in one spreadsheet?" and
    again later, "let me rework this and get this all in one spreadsheet because
    it's kind of a pain in the butt to go back and forth."

    So there are no other tabs. What used to be the Trips, Order answers, ePCR,
    Question findings, Disagreements and De-identification sheets are column
    blocks on the one row now, left to right in the order a reviewer reads them:

      identity -> category scores -> order verdict -> record verdict ->
      your call -> question by question -> the record -> de-identification

    Blocks are separated by a blank spacer column with the block name in its
    header, so the sheet can be read across and collapsed by group.
    """
    rows: List[Dict[str, Any]] = []

    for r in results:
        trip_id = r["tripRequestId"]
        order = (r.get("order") or {}).get("body") or {}
        record = (r.get("record") or {}).get("body") or {}
        od = order.get("detail") or {}
        rd = record.get("detail") or {}
        meta = order.get("meta") or {}
        findings = od.get("questionFindings") or []

        order_meets = order.get("meetsMedicalNecessity")
        record_meets = record.get("meetsMedicalNecessity") if r.get("record") else None

        # Every finding lands in every category it touches, then each category is
        # scored on its own. A finding naming a stretcher and cardiac monitoring
        # counts in mobility and in monitoring.
        by_category: Dict[str, List[Dict[str, Any]]] = {c: [] for c in CATEGORIES}
        finding_categories: Dict[int, List[str]] = {}
        uncategorised: List[str] = []
        for n, f in enumerate(findings):
            hits = categories_for(f.get("criterionId"), f.get("question"),
                                  f.get("answer"), f.get("evidence"), f.get("reason"))
            finding_categories[n] = hits
            for name in hits:
                by_category[name].append(f)
            if not hits:
                uncategorised.append(str(f.get("question") or f.get("criterionId") or "")[:80])

        scores = {c: score_category(by_category[c]) for c in CATEGORIES}
        # These two are not guessed from the wording. The order states them.
        scores["Level of service"] = score_level_of_service(r.get("levelOfService"))
        scores["Modifiers"] = score_modifiers(r.get("pickupCode"), r.get("dropoffCode"))

        row: Dict[str, Any] = {
            "Trip request id": trip_id,
            "Order submitted": r.get("orderedAt"),
            "Level of service": r.get("levelOfService"),
            "Trip type": r.get("tripType"),
            "Origin": MODIFIERS.get(str(r.get("pickupCode") or "").upper(), ""),
            "Destination": MODIFIERS.get(str(r.get("dropoffCode") or "").upper(), ""),
            "Trip reason": r.get("tripReason"),
            "Facility pay reason": r.get("facilityPayReason"),
            "Duplicate payloads": duplicate_flag(r),
            "Questions answered": len(r.get("pairs") or []),
        }

        # Scored per category, not one category per trip. Dave: "these are
        # independent ... they could have an altered LOC, they could be
        # unconscious, and they could also have a mobility restriction."
        row["CATEGORY SCORES"] = None
        for c in CATEGORY_ORDER:
            row[f"{c}: score"] = scores[c]["score"]
            row[f"{c}: finding"] = scores[c]["label"]
            row[f"{c}: confidence"] = scores[c]["confidence"]
            row[f"{c}: evidence"] = scores[c]["evidence"]
        row["Categories supporting"] = sum(
            1 for c in CATEGORY_ORDER if scores[c]["score"] == 2)
        row["Category score total"] = sum(scores[c]["score"] for c in CATEGORY_ORDER)
        # Nothing is filed under a catch-all any more, so a finding that matched
        # no category is named here instead of disappearing into one.
        row["Findings in no category"] = " | ".join(uncategorised)

        row["ORDER (what was known at order entry)"] = None
        row.update({
            "Order: meets": yes_no(order_meets),
            "Order: determination": od.get("determination"),
            "Order: confidence": od.get("confidence"),
            "Order: summary": order.get("clinicalSummary"),
            "Order: basis": od.get("basis"),
            "Order: clarifying question": order.get("clarifyingQuestion"),
        })

        row["RECORD (what the crew documented)"] = None
        row.update({
            "Record: meets": yes_no(record_meets),
            "Record: determination": rd.get("determination"),
            "Record: confidence": rd.get("confidence"),
            "Record: summary": record.get("clinicalSummary"),
            "Record: basis": rd.get("basis"),
            "Record: strongest evidence": rd.get("strongestEvidence"),
            "Record: documentation gaps": " | ".join(record.get("documentationGaps") or []),
            "Agreement": agreement(order_meets, record_meets),
        })

        # Left empty on purpose: the reviewer's verdict goes beside the model's,
        # on the same row, so agreement can be counted without a second file.
        row["YOUR CALL"] = None
        row["SME: meets"] = ""
        row["SME: category at issue"] = ""
        row["SME: notes"] = ""

        # Question by question: the answer, then what the model made of it. This
        # is the old Question findings sheet, folded onto the trip's own row.
        row["QUESTION BY QUESTION"] = None
        answered = {str(question_of(p) or "").strip(): p for p in (r.get("pairs") or [])}
        used: set = set()
        slot = 0
        for n, f in enumerate(findings):
            slot += 1
            question = str(f.get("question") or "").strip()
            used.add(question)
            row[f"Q{slot}"] = question
            row[f"A{slot}"] = f.get("answer") or (
                answered.get(question, {}).get("answer"))
            row[f"Q{slot} supports necessity"] = yes_no(f.get("nonMedNec") is False)
            row[f"Q{slot} categories"] = ", ".join(finding_categories.get(n, []))
            row[f"Q{slot} criterion"] = f.get("criterionId")
            row[f"Q{slot} evidence"] = f.get("evidence")
            row[f"Q{slot} reason"] = f.get("reason")
            row[f"Q{slot} confidence"] = f.get("confidence")
            row[f"Q{slot} citation"] = f.get("citation")
        # Answers the model returned no finding for still belong on the row: a
        # question that was asked and ignored is itself worth seeing.
        for pair in (r.get("pairs") or []):
            question = str(question_of(pair) or "").strip()
            if question in used:
                continue
            slot += 1
            row[f"Q{slot}"] = question
            row[f"A{slot}"] = pair.get("answer")
            row[f"Q{slot} supports necessity"] = ""
            row[f"Q{slot} categories"] = ", ".join(
                categories_for(None, question, pair.get("answer")))
            row[f"Q{slot} criterion"] = ""
            row[f"Q{slot} evidence"] = ""
            row[f"Q{slot} reason"] = "no finding returned for this answer"
            row[f"Q{slot} confidence"] = ""
            row[f"Q{slot} citation"] = ""

        # The ePCR, one field per column. Mukund: "break down the EPCR data into
        # the columns so that we have that ready to view, not just as a blob."
        row["ePCR"] = None
        sel = rd.get("selection") or {}
        row["ePCR matched"] = yes_no(bool(r.get("record")))
        row["ePCR note"] = "" if r.get("record") else (
            "no patient care record matched this trip")
        if r.get("record"):
            for name, value in record_columns(r.get("recordFields") or {}).items():
                row[f"ePCR {name}"] = value
        row["ePCR fields read"] = sel.get("populated")
        row["ePCR fields offered"] = sel.get("offered")
        row["ePCR fields withheld"] = sel.get("withheld")

        # Kept on the row rather than in a sheet of its own: this is the evidence
        # that nothing identifying was sent, per trip, auditable in place.
        rep = r.get("deid") or {}
        row["DE-IDENTIFICATION"] = None
        row.update({
            "Patient fields cleared": ", ".join(rep.get("patientFieldsCleared") or []),
            "Identifying fields dropped": (len(rep.get("droppedTop") or [])
                                           + len(rep.get("droppedLeg") or [])),
            "Free text masked in": ", ".join(rep.get("maskedIn") or []),
            "Patterns hit": ", ".join(rep.get("patternsHit") or []),
            "UNKNOWN fields (classify these)": ", ".join(
                (rep.get("unknownTop") or []) + (rep.get("unknownLeg") or [])),
            "Held back": "YES" if r.get("leak") else "",
            "Order ms": (r.get("order") or {}).get("ms"),
            "Record ms": (r.get("record") or {}).get("ms"),
            "Tokens in": meta.get("inputTokens"),
            "Tokens out": meta.get("outputTokens"),
            "Error": r.get("error") or (r.get("order") or {}).get("error"),
        })

        rows.append(row)

    frame = pd.DataFrame(rows)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        frame.to_excel(writer, sheet_name=SHEET, index=False)
        format_sheet(writer.sheets[SHEET])

    return out_path


SHEET = "Med nec review"

# The spacer columns. Written as a key with a None value so pandas keeps the
# column and its position; they carry no data, only the name of what follows.
BLOCKS = ("CATEGORY SCORES", "ORDER (what was known at order entry)",
          "RECORD (what the crew documented)", "YOUR CALL",
          "QUESTION BY QUESTION", "ePCR", "DE-IDENTIFICATION")


def format_sheet(sheet) -> None:
    """Make one very wide sheet navigable.

    Rows stay one line tall on purpose. Wrapping prose made each row as tall as
    its longest cell, which is the opposite of reading 51 trips one after the
    other. Long text is clipped in the cell and read in the formula bar.
    """
    sheet.freeze_panes = "B2"
    sheet.auto_filter.ref = sheet.dimensions

    fill = PatternFill("solid", fgColor="DDE5F0")
    block = PatternFill("solid", fgColor="1F3864")
    header_font = Font(bold=True, size=10)
    block_font = Font(bold=True, size=10, color="FFFFFF")

    for column in sheet.columns:
        letter = column[0].column_letter
        header = str(column[0].value or "")
        cell = column[0]
        cell.alignment = Alignment(vertical="bottom", wrap_text=False)

        if header in BLOCKS:
            cell.fill = block
            cell.font = block_font
            sheet.column_dimensions[letter].width = 3
            continue

        cell.fill = fill
        cell.font = header_font
        width = max((len(str(c.value)) for c in column[:80] if c.value), default=10)
        if header.endswith((": score", ": finding", ": confidence")):
            cap = 16
        elif header.startswith(("Order: summary", "Order: basis", "Record: summary",
                                "Record: basis", "Order: clarifying")):
            cap = 70
        else:
            cap = 45
        sheet.column_dimensions[letter].width = min(max(width + 2, 11), cap)
        for data_cell in column[1:]:
            data_cell.alignment = Alignment(vertical="top", wrap_text=False)

    for n in range(2, sheet.max_row + 1):
        sheet.row_dimensions[n].height = 15
