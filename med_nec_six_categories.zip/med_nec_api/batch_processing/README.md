# Batch processing

The same engine as the review screen, run over a file of trip requests instead of
one at a time. This process does no thinking of its own: it reads the export,
de-identifies every payload, posts it to the service, and writes the workbook.

The service and the review screen are untouched and keep working as they do now.

```
med_nec_api\
  app.py  llm.py  prompts\  static\      the service and the review screen
  batch_processing\
    actual_payloads\                      drop the export here
    batch_results\                        workbooks land here
    batch_process.py                      the entry point
    deidentify.py
    workbook.py
```

## Two commands, two windows

**First**, start the service and leave it running. Same command as always,
from `med_nec_api`:

```powershell
python -m uvicorn app:app --port 8000
```

That is the same service the review screen uses, on `http://127.0.0.1:8000`.
`http://127.0.0.1:8000/ui` still works while the batch runs.

**Then**, in a second window:

```
batch_processing\run_batch.cmd
```

or directly:

```powershell
python batch_processing\batch_process.py
```

Put the export from the Transport.net query in `actual_payloads\` and run with no
arguments. It picks up the newest `.csv` or `.xlsx` it finds. Workbooks land in
`batch_results\`.

It uses the same `.venv` as the service, so there is nothing extra to install.

**Note there are two batch runners and they do different jobs.**
`med_nec_api\run_batch.py` posts a folder of JSON files from `inbox\`.
`batch_processing\batch_process.py` is this one: it reads the production export,
de-identifies it, and writes the review workbook.

## Run the dry run first

```
run_batch.cmd --dry-run
```

De-identifies, writes the workbook with no determinations, and sends nothing. On
a new extract this is the cheapest way to see what the scrubber found before a
line of clinical text leaves the machine.

## What the input looks like

One row per trip, from the query against `O_RequestEventLogs`:

| Column | |
|---|---|
| `RequestPayload` | the raw JSON, `EventJson` from the event log |
| `TripRequestId` | the trip |
| `EventTimeStamp` | optional, but see below |

Other columns are ignored. `--payload-column` / `--trip-column` /
`--timestamp-column` if yours are named differently.

**Include the timestamp.** `O_RequestEventLogs` holds an `EventId = 3` row per
submission, so a trip that was edited and resubmitted appears twice. With a
timestamp the latest submission is kept, which is the order as it finally stood.
Without one the row kept is arbitrary, and the run says so.

## De-identification

`deidentify.py`. The rule is ALLOW, not DENY: every field is dropped unless it is
named, because a deny list is only as good as its author's imagination and nobody
on this project had seen a production payload until this week. A payload goes
from roughly 13KB to 2.3KB. What survives is the question and answer pairs, the
level of service, the origin and destination codes, the trip reason, and the free
text boxes, scrubbed.

Three guards, in order:

1. **An unrecognised field stops the run.** It is dropped and reported, and the
   batch refuses to send until someone has classified it in `deidentify.py`.
   `--allow-unknown-fields` proceeds once the list has been read.
2. **Free text is scrubbed against the patient's own name**, read out of
   `patientInfo` before that block is blanked. A requester who typed the name
   into an answer box is caught, which no pattern would do.
3. **Residual scan.** The cleaned payload is searched again for anything that
   looks like an identifier. A hit holds that trip back rather than sending it.

## The workbook

**One sheet, one row per trip.** Dave, 6 November: *"let me rework this and get
this all in one spreadsheet because it's kind of a pain in the butt to go back
and forth."* There are no other tabs. The row reads left to right in blocks,
each introduced by a narrow dark spacer column:

| Block | |
|---|---|
| (identity) | Trip id, submitted, level of service, origin and destination in words, trip reason, duplicate-payload flag |
| CATEGORY SCORES | The six categories from the in-person meeting doc, each scored on its own: **mobility**, **level of consciousness**, **medical monitoring**, **isolation precautions**, **level of service**, **modifiers**. 2 supports, 1 insufficient, 0 not documented or asked and answered no. Plus confidence and the evidence |
| ORDER | What the model made of the order at entry: meets, determination, confidence, summary, basis, clarifying question |
| RECORD | The same against the ePCR, plus documentation gaps and the agreement verdict |
| YOUR CALL | Empty, for the reviewer's own verdict beside the model's |
| QUESTION BY QUESTION | Per question: `Q1`, `A1`, whether it supports necessity, its categories, criterion, evidence, reason, confidence, citation. Answers the model returned no finding for are listed too |
| ePCR | The record field by field, not as a blob |
| DE-IDENTIFICATION | What was cleared, dropped, masked and flagged for this trip, plus latency, tokens and any error |

Trip id is frozen, a filter is on every column, and rows are one line tall so 51
trips scan down the sheet rather than scrolling.

Four categories are derived **here, by keyword** from the words on the order,
not decided by the model, and their scores are rolled up from the findings the
model already returned per question.

**Level of service** and **modifiers** are not guessed from wording: the order
states them, so they are read off the payload. Level of service scores ALS and
SCT at 2 and BLS at 1. Modifiers are scored by the rule already in
`prompts\med_nec_knowledge.json` — origin lower on the scale than destination
means the higher level of care tree governs, so an upward transport scores 2 and
a discharge direction scores 1. The scale is read from that file, not restated,
so the workbook and the model score against the same one.

Nothing about a determination changes: these are rollups of findings the model
already returned. A finding that matches no category is named in **Findings in
no category** rather than filed under a catch-all. If the categories are going
to carry weight with Anna and Ed they should come from the model against the
criteria instead of from keywords here.

## Patient care records

Put the ePCR extract in `actual_pcr\`. It is picked up automatically, matched to
trips on `TNET_TripRequestId`, and scored by the same model against the record
prompt. A matched record fills the ePCR block of that trip's row and gets an
agreement verdict against its order.

Identifier patterns in the crew's free text, `EPCR_Narrative` above all, are
masked before anything is sent. Which columns the model is allowed to read is
decided by the service, in `prompts\epcr_fields.json`: 50 of them, with payment
method, insurance, addresses and agency names withheld. The file on disk keeps
every column.

A record with `MDM_GoldenRecord` other than `T`, or with no clinical content, is
reported as unmatched and gets no verdict. An absent record is not evidence
against a trip.

### Other sources

```
run_batch.cmd --records ..\..\med_nec_payload_builder\json_payloads3
```

Takes either the folder-per-trip tree the builder notebook writes, or a single
wide csv with a `TNET_TripRequestId` column. Trips with a record get a second
determination and an agreement verdict; trips without are scored on the order
alone and say so.

## Other arguments

```
--limit 5              first five trips, for a quick look
--workers 3            parallel requests. Mind the TPM quota
--base http://...      a service somewhere other than localhost:8000
--timeout 300          seconds; the record pass is the slow one
```
