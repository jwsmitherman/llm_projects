# prompts

Everything the model is told. None of it needs Python to change.

```
system_prompt.md          the order entry wording and output schema
epcr_prompt.md            the patient care record wording and output schema
med_nec_knowledge.json    the criteria, structured, shared by both
epcr_fields.json          which record columns are sent, which withheld, why
```

Two prompts because there are two assessments and they are not the same
question. The order entry prompt reads what a requester anticipates and may ask
one clarifying question, because the requester is still there to answer it. The
record prompt reads what a crew documented after the fact and reports gaps
instead, because a record cannot be amended by answering a prompt. Both render
from the same criteria file, so a criterion changed once changes both.

`llm.py` renders one into the other at startup and caches the result, so a change
here takes effect on the next restart. The compiled instruction currently runs to
about 14,000 characters and is sent whole on every call. There is no retrieval
step: the criteria set fits in one instruction, so there is nothing to retrieve
and no recall failure mode to design around.

## Changing the wording

Edit `system_prompt.md`. Placeholders are `{{name}}`, double braces, and are
filled from the criteria file:

| Placeholder | Filled from |
|---|---|
| `{{determination_question}}` | `determination_question` |
| `{{non_emergency_question}}` | `non_emergency_question` |
| `{{evaluation_principle}}` | `evaluation_principle` |
| `{{concepts}}` | `concepts`, one line each, name, axis, cited or inferred, phrasings |
| `{{presumed_necessary}}` | `presumed_necessary` |
| `{{bed_confinement}}` | `bed_confinement.elements` |
| `{{exclusions}}` | `exclusions` |
| `{{denial_criteria}}` | `denial_criteria.elements` |
| `{{policy_rules}}` | `policy_rules` |
| `{{non_specific_phrases}}` | `non_specific_phrases`, comma separated |

Single braces are left alone, which is what lets the JSON schema block sit in the
template literally. A `{{placeholder}}` with no matching name raises at startup
and names the ones it knows, rather than shipping a prompt with a hole in it.

## Changing the criteria

Edit `med_nec_knowledge.json`. Adding a concept, an exclusion or a policy rule
puts it in the instruction on the next restart with no code change.

Each concept carries `status`, either `cited` or `inferred`. Cited means it is
traceable to one of the five sources; inferred means it was added because the
criteria clearly imply it but no source states it outright. Three are inferred —
`bariatric`, `isolation` and `wound_ostomy` — and they are still waiting on SME
confirmation.

`open_conflicts` records places where two sources disagree, with an owner, rather
than silently picking one. Fall risk and oxygen are both in there.

`knowledge_version` is reported on every response as `meta.knowledgeVersion`.
**Bump it when you change the criteria**, or two runs will be indistinguishable
in the event log and you will not be able to tell which version produced a
determination.

## Checking a change

```powershell
python -c "import llm; p = llm.build_prompt(); print(len(p)); print(p[:600])"
python -c "import llm; p = llm.build_epcr_prompt(); print(len(p)); print(p[:600])"
```

That renders without calling the model or needing credentials, so it is the cheap
way to see what a change did before spending tokens on it. A leftover `{{name}}`
in the output is a placeholder the criteria file does not fill.

## Changing which record columns are sent

Edit `epcr_fields.json`. Every column in the ePCR table belongs to exactly one
of three places: a `send` group, a `withhold` group, or `key_column`. A column
in none of them is ignored by the service, and the builder notebook reports that
at pull time rather than letting it pass unnoticed.

Each `withhold` group carries a `reason`, and the review screen shows those
reasons rather than only the count. Two are not editorial preferences:
`EPCR_Primary_Payment_Method` and `EPCR_Insurance_Companies` are withheld because
a coverage determination that can see who pays is a compliance problem, and
`TNET_LosQuestions` and `TNET_ClinicalData` are withheld because they are the
order's own answers and sending them would make the second opinion a copy of the
first.

Bump `version` when the selection changes. It is reported back in every response
under `detail.selection.fieldsVersion`, which is what lets an old result be told
apart from a new one.

```powershell
python -c "import llm, json; s = llm.get_epcr_spec(); print(json.dumps({'version': s['version'], 'send': sum(len(g['columns']) for g in s['send']), 'withhold': sum(len(g['columns']) for g in s['withhold'])}, indent=2))"
```
