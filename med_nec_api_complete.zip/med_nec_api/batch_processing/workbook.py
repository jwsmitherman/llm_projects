"""Builds the review workbook from a completed batch run.

The sheets exist because of what was asked for in the 29 October review:

  "is there a way to take this blob and turn it into structured data so that we
   can easily see what the input was? Because you can't at scale look at this."

  "I want to look at this for 1000 calls, but in a spreadsheet or somewhere we
   can quickly go through a whole bunch together over an hour or two."

  "here's the question, here's the answer, whether it met the criteria, the
   evidence, the reason, and then the confidence level."
"""

from pathlib import Path
from typing import Any, Dict, List

import pandas as pd

# Origin and destination codes read as words, so a reviewer is not decoding
# letters. These are the CMS modifiers.
MODIFIERS = {
    "H": "Hospital", "S": "Skilled nursing facility", "P": "Physician office",
    "R": "Residence", "E": "Residential/domiciliary/custodial facility",
    "N": "Skilled nursing facility", "D": "Diagnostic or therapeutic site",
    "J": "Freestanding ESRD facility", "G": "Hospital-based ESRD facility",
    "X": "Intermediate stop", "I": "Site of transfer",
}

# The three categories Dave kept returning to. Keyword matched here, NOT decided
# by the model, and the column says so in its header.
CATEGORIES = {
    "mobility": ("bed_confined", "cannot_sit", "mobility", "ambulate", "stretcher",
                 "contraindicated_other_means", "weight_bearing", "transfer_assist",
                 "contracture", "positioning", "wheelchair"),
    "monitoring": ("cardiac", "iv", "oxygen", "airway", "suction", "ventilator",
                   "medication", "vitals", "monitor", "infusion", "restraint",
                   "telemetry", "ecg"),
    "mentation": ("altered_mental", "sedation", "confusion", "unresponsive",
                  "behavioral", "psychiatric", "consciousness", "gcs", "mentation"),
}


def categorise(criterion_id, question, answer) -> str:
    haystack = " ".join(str(x or "").lower() for x in (criterion_id, question, answer))
    for name, keys in CATEGORIES.items():
        if any(k in haystack for k in keys):
            return name
    return "administrative"


def agreement(order_meets, record_meets) -> str:
    if order_meets is None or record_meets is None:
        return "no record verdict"
    if order_meets == record_meets:
        return "agree"
    return "order meets, record does not" if order_meets else "record meets, order does not"


def build(results: List[Dict[str, Any]], out_path: Path, scored: bool) -> Path:
    trips, findings, answers, deid = [], [], [], []

    for r in results:
        trip_id = r["tripRequestId"]
        order = (r.get("order") or {}).get("body") or {}
        record = (r.get("record") or {}).get("body") or {}
        od = order.get("detail") or {}
        rd = record.get("detail") or {}
        meta = order.get("meta") or {}

        order_meets = order.get("meetsMedicalNecessity")
        record_meets = record.get("meetsMedicalNecessity") if r.get("record") else None

        trips.append({
            "Trip request id": trip_id,
            "Order submitted": r.get("orderedAt"),
            "Level of service": r.get("levelOfService"),
            "Trip type": r.get("tripType"),
            "Origin": MODIFIERS.get(str(r.get("pickupCode") or "").upper(), ""),
            "Destination": MODIFIERS.get(str(r.get("dropoffCode") or "").upper(), ""),
            "Trip reason": r.get("tripReason"),
            "Answers on the order": len(r.get("pairs") or []),
            "Order: meets": order_meets,
            "Order: determination": od.get("determination"),
            "Order: confidence": od.get("confidence"),
            "Order: summary": order.get("clinicalSummary"),
            "Order: basis": od.get("basis"),
            "Order: clarifying question": order.get("clarifyingQuestion"),
            "Record: meets": record_meets,
            "Record: determination": rd.get("determination"),
            "Record: summary": record.get("clinicalSummary"),
            "Record: strongest evidence": rd.get("strongestEvidence"),
            "Record: documentation gaps": " | ".join(record.get("documentationGaps") or []),
            "Agreement": agreement(order_meets, record_meets),
            "Facility pay reason": r.get("facilityPayReason"),
            "Order ms": (r.get("order") or {}).get("ms"),
            "Record ms": (r.get("record") or {}).get("ms"),
            "Tokens in": meta.get("inputTokens"),
            "Tokens out": meta.get("outputTokens"),
            "Error": r.get("error"),
        })

        for f in (od.get("questionFindings") or []):
            question, answer = f.get("question") or "", f.get("answer") or ""
            findings.append({
                "Trip request id": trip_id,
                "Level of service": r.get("levelOfService"),
                "Trip type": r.get("tripType"),
                "Category (derived, not the model)": categorise(f.get("criterionId"), question, answer),
                "Question": question,
                "Answer": answer,
                "Supports necessity": f.get("nonMedNec") is False,
                "Bearing": f.get("category"),
                "Criterion": f.get("criterionId"),
                "Evidence quoted": f.get("evidence"),
                "Reason": f.get("reason"),
                "Confidence": f.get("confidence"),
                "Citation": f.get("citation"),
            })

        flat = {"Trip request id": trip_id,
                "Order submitted": r.get("orderedAt"),
                "Level of service": r.get("levelOfService"),
                "Trip type": r.get("tripType")}
        for i, pair in enumerate(r.get("pairs") or [], 1):
            flat[f"Q{i}"] = pair.get("questionText")
            flat[f"A{i}"] = pair.get("answer")
        answers.append(flat)

        rep = r.get("deid") or {}
        deid.append({
            "Trip request id": trip_id,
            "Patient fields cleared": ", ".join(rep.get("patientFieldsCleared") or []),
            "Identifying fields dropped": len(rep.get("droppedTop") or []) + len(rep.get("droppedLeg") or []),
            "Free text masked in": ", ".join(rep.get("maskedIn") or []),
            "Patterns hit": ", ".join(rep.get("patternsHit") or []),
            "UNKNOWN fields (classify these)": ", ".join(
                (rep.get("unknownTop") or []) + (rep.get("unknownLeg") or [])),
            "Held back": "YES" if r.get("leak") else "",
        })

    trips_df = pd.DataFrame(trips)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        trips_df.to_excel(writer, sheet_name="Trips", index=False)
        pd.DataFrame(answers).to_excel(writer, sheet_name="Order answers", index=False)
        if scored:
            pd.DataFrame(findings).to_excel(writer, sheet_name="Question findings", index=False)
            disagree = trips_df[trips_df["Agreement"].isin(
                ["order meets, record does not", "record meets, order does not"])]
            disagree.to_excel(writer, sheet_name="Disagreements", index=False)
        pd.DataFrame(deid).to_excel(writer, sheet_name="De-identification", index=False)

        for sheet in writer.sheets.values():
            sheet.freeze_panes = "A2"
            for column in sheet.columns:
                letter = column[0].column_letter
                width = max((len(str(c.value)) for c in column[:60] if c.value), default=10)
                sheet.column_dimensions[letter].width = min(max(width + 2, 12), 60)

    return out_path
