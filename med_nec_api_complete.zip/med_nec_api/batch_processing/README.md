# Batch processing

The same engine as the review screen, run over a file of trip requests instead of
one at a time. This process does no thinking of its own: it reads the export,
de-identifies every payload, posts it to the service, and writes the workbook.

The service and the review screen are untouched and keep working as they do now.

```
med_nec_api\
  app.py  llm.py  prompts\  static\      the service and the review screen
  batch_processing\
    actual_payloads\                      drop the export here
    batch_results\                        workbooks land here
    batch_process.py                      the entry point
    deidentify.py
    workbook.py
```

## Two commands, two windows

**First**, start the service and leave it running. Same command as always,
from `med_nec_api`:

```powershell
python -m uvicorn app:app --port 8000
```

That is the same service the review screen uses, on `http://127.0.0.1:8000`.
`http://127.0.0.1:8000/ui` still works while the batch runs.

**Then**, in a second window:

```
batch_processing\run_batch.cmd
```

or directly:

```powershell
python batch_processing\batch_process.py
```

Put the export from the Transport.net query in `actual_payloads\` and run with no
arguments. It picks up the newest `.csv` or `.xlsx` it finds. Workbooks land in
`batch_results\`.

It uses the same `.venv` as the service, so there is nothing extra to install.

**Note there are two batch runners and they do different jobs.**
`med_nec_api\run_batch.py` posts a folder of JSON files from `inbox\`.
`batch_processing\batch_process.py` is this one: it reads the production export,
de-identifies it, and writes the review workbook.

## Run the dry run first

```
run_batch.cmd --dry-run
```

De-identifies, writes the workbook with no determinations, and sends nothing. On
a new extract this is the cheapest way to see what the scrubber found before a
line of clinical text leaves the machine.

## What the input looks like

One row per trip, from the query against `O_RequestEventLogs`:

| Column | |
|---|---|
| `RequestPayload` | the raw JSON, `EventJson` from the event log |
| `TripRequestId` | the trip |
| `EventTimeStamp` | optional, but see below |

Other columns are ignored. `--payload-column` / `--trip-column` /
`--timestamp-column` if yours are named differently.

**Include the timestamp.** `O_RequestEventLogs` holds an `EventId = 3` row per
submission, so a trip that was edited and resubmitted appears twice. With a
timestamp the latest submission is kept, which is the order as it finally stood.
Without one the row kept is arbitrary, and the run says so.

## De-identification

`deidentify.py`. The rule is ALLOW, not DENY: every field is dropped unless it is
named, because a deny list is only as good as its author's imagination and nobody
on this project had seen a production payload until this week. A payload goes
from roughly 13KB to 2.3KB. What survives is the question and answer pairs, the
level of service, the origin and destination codes, the trip reason, and the free
text boxes, scrubbed.

Three guards, in order:

1. **An unrecognised field stops the run.** It is dropped and reported, and the
   batch refuses to send until someone has classified it in `deidentify.py`.
   `--allow-unknown-fields` proceeds once the list has been read.
2. **Free text is scrubbed against the patient's own name**, read out of
   `patientInfo` before that block is blanked. A requester who typed the name
   into an answer box is caught, which no pattern would do.
3. **Residual scan.** The cleaned payload is searched again for anything that
   looks like an identifier. A hit holds that trip back rather than sending it.

## The workbook

| Sheet | |
|---|---|
| ePCR | One row per matched record: its own verdict, the gaps, the agreement against the order, and the clinical fields a reviewer wants beside it |
| Trips | One row per trip: level of service, origin and destination in words, both determinations, agreement, latency, tokens |
| Order answers | The JSON flattened to `Q1/A1, Q2/A2 …`, which is what makes a hundred trips readable in a sitting |
| Question findings | Per answer: question, answer, whether it supports necessity, the evidence quoted, the reason, the confidence, and a derived category |
| Disagreements | Where the order and the record reached different verdicts |
| De-identification | What was cleared, dropped, masked and flagged, per trip |

The category column is derived **here, by keyword**, not decided by the model.
Its header says so. If that column is going to carry weight in a review it should
come from the model against the criteria instead.

## Patient care records

Put the ePCR extract in `actual_pcr\`. It is picked up automatically, matched to
trips on `TNET_TripRequestId`, and scored by the same model against the record
prompt. Each matched trip gets a row on the **ePCR** tab and an agreement
verdict against its order.

Identifier patterns in the crew's free text, `EPCR_Narrative` above all, are
masked before anything is sent. Which columns the model is allowed to read is
decided by the service, in `prompts\epcr_fields.json`: 50 of them, with payment
method, insurance, addresses and agency names withheld. The file on disk keeps
every column.

A record with `MDM_GoldenRecord` other than `T`, or with no clinical content, is
reported as unmatched and gets no verdict. An absent record is not evidence
against a trip.

### Other sources

```
run_batch.cmd --records ..\..\med_nec_payload_builder\json_payloads3
```

Takes either the folder-per-trip tree the builder notebook writes, or a single
wide csv with a `TNET_TripRequestId` column. Trips with a record get a second
determination and an agreement verdict; trips without are scored on the order
alone and say so.

## Other arguments

```
--limit 5              first five trips, for a quick look
--workers 3            parallel requests. Mind the TPM quota
--base http://...      a service somewhere other than localhost:8000
--timeout 300          seconds; the record pass is the slow one
```
