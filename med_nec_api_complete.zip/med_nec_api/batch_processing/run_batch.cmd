@echo off
REM Runs every payload in actual_payloads\ through the service.
REM The service must already be running in another window:
REM     cd med_nec_api
REM     python -m uvicorn app:app --port 8000
cd /d "%~dp0"
if exist "..\.venv\Scripts\activate.bat" call "..\.venv\Scripts\activate.bat"
python batch_process.py %*
