"""Strip identifiers from a Transport.net trip request before it leaves for the model.

Design note, because this is the part that matters most.

The rule here is ALLOW, not DENY. A deny list is only as good as the author's
imagination, and nobody on this project has seen a production payload until now;
a field we have never met is exactly the field likely to carry a name. So every
field is dropped unless it is named below, and any field we do not recognise at
all is reported as UNKNOWN so a person decides, rather than being passed through
on the assumption that it looked harmless.

What the service actually reads is a short list: the clinical question and answer
pairs, the level of service, the origin and destination codes, and the trip
reason. Everything else exists to make the payload realistic and is not needed to
reach a determination.
"""

import json
import re
from typing import Any, Dict, List, Tuple

# ---------------------------------------------------------------- what we keep

# Top level. These reach the model or are needed to trace a row back to a trip.
KEEP_TOP = {
    "olosRequestId", "correlationId", "sourceSystemTripId", "requestDateTime",
    "tripReason", "tripReasonId", "contractId", "isRoundTrip",
    "msgActionType", "msgObjType", "configVersionId",
    "tripComment", "tripReasonQuestions",
    "requestType", "requestTypeId", "requestConfigType", "requestorType",
    "isTransferFacility", "isApprovalRequired", "roundTripType",
}

# Recognised, not identifying, and nothing the model needs. Dropped without
# comment so the UNKNOWN list stays short enough to actually read.
KNOWN_NONCLINICAL_TOP = {
    "allowPastTrips", "eligibilityCheckOnly", "idenCovid", "skipEligibility",
    "skipQueues", "requestQuickOrder", "returnTripPickupTime", "waitTimeMins",
    "userSelectedProviders", "isSigningRequired", "isUserTypeSigningReq",
    "isCallerFacilitySearchable", "isNotifyFacilitySearchable", "isReqFacilitySearchable",
}
KNOWN_NONCLINICAL_LEG = {
    "expiredSecs", "idenStandBy", "idenStandByActivated", "slaId",
    "sourceSystemTripLegId", "tripConcierge",
    # Authorisation and insurance. Not clinical, and payer-identifying.
    "insuranceInfo", "preauthNumber", "preCheckAuth", "preCheckBroker",
    "preCheckMatrixId", "referenceNumber",
}

# Trip leg. The clinical content plus the context Dave asked to see on screen.
KEEP_LEG = {
    "clinicalData", "losQuestions", "medicareQuestionTen",
    "levelOfService", "losCategory", "losCategoryLabel", "systemLos",
    "losReason", "losOverride", "losOverrideReason",
    "pickupLocTypeCode", "dropoffLocTypeCode",
    "pickupFacilityTypeId", "dropoffFacilityTypeId",
    "facilityPayReason", "facilityPayReasonId", "facPayOverrideReason",
    "apptTime", "msgReceived", "slaTypeId", "SLA",
    "tripLegId", "legNumber", "isTransfer",
    # Free text. Kept because it is often where the "why" lives, which is the
    # thing Dave keeps saying the check boxes lost. Scrubbed like clinicalData.
    "specialNeeds", "transRequestComment",
    # Context the model can reason about without identifying anyone.
    "transportDistance", "transportDuration", "transportDurationTraffic", "tripMiles",
    "idenOneWay", "idenReccur", "idenNow", "idenWillCall", "isApptTime",
    "medicareQuestionNums", "facilityPayOverride",
}

# Free text fields anywhere in the payload. Kept, but never passed through
# unscrubbed: a box a human can type into is a box a name can end up in.
FREE_TEXT_LEG = ("clinicalData", "specialNeeds", "transRequestComment", "losReason",
                 "losOverrideReason", "facPayOverrideReason")
FREE_TEXT_TOP = ("tripComment",)

# patientInfo is blanked wholesale. These two are units, not measurements, and
# the payload is malformed without them.
KEEP_PATIENT = {"heightUnit", "weightUnit"}

# Fields we know exist and know to be identifying. Named so an unknown field is
# genuinely unknown rather than merely unlisted.
KNOWN_IDENTIFYING_TOP = {
    "requesterName", "requesterFirstName", "requesterLastName", "requesterId",
    "requesterPhone", "requesterFacility", "requesterFacilityId", "requesterOffset",
    "createdBy", "createdByEmail", "approvedBy", "approvedByOffset", "dateApprovedBy",
    "notifyName", "notifyEmail", "notifyPhone", "notifyPhoneExt", "notifyFacilityId",
    "preferredNotifyMethod", "callerFacilityId", "department", "reqEntity", "reqRole",
    "reqPrimPhone", "reqPrimPhType", "reqSecPhone", "reqSecPhType",
    "signedBy", "signedByName", "signedByCredentials", "signedByEmailAddress",
    "signedByLicenseNo", "signedByOffset", "signedByPhoneNumber",
    "signedByPhoneNumberExt", "signedByProfession", "dateSignedBy",
    "pcsId", "contractName", "draftSystemId", "systemId",
}

KNOWN_IDENTIFYING_LEG_PREFIX = ("pickup", "dropoff")
KNOWN_IDENTIFYING_LEG = {
    "additionalPassengers", "additionalInsurances", "attachments",
    "authorizedBy", "addlAuthorizedBy", "addlAuthNumber", "addlAuthNumberNpi",
    "cadId", "cadUserId", "additionalFields",
    "displayPickupTime", "displayApptTime",
}

# Free text patterns. The structured fields are handled by the allow list; these
# catch what a requester typed into a box.
PATTERNS: List[Tuple[str, "re.Pattern[str]"]] = [
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("DOB", re.compile(r"\b\d{1,2}/\d{1,2}/(?:19|20)\d{2}\b")),
    ("DATE", re.compile(r"\b(?:19|20)\d{2}-\d{1,2}-\d{1,2}\b")),
    ("MRN", re.compile(r"\b(?:mrn|medical record(?:\s*(?:no|number|#))?)\s*[:#]?\s*[A-Za-z0-9-]+",
                       re.IGNORECASE)),
    ("ACCOUNT", re.compile(r"\b(?:acct|account|visit|encounter)\s*(?:no|number|#)?\s*[:#]\s*[A-Za-z0-9-]+",
                           re.IGNORECASE)),
    ("PHONE", re.compile(r"\(?\b\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")),
]


def _scrub_text(text: str, extra_names: List[str]) -> Tuple[str, List[str]]:
    """Mask patterns and any known name, returning the text and what was hit."""
    if not isinstance(text, str) or not text.strip():
        return text, []

    hits: List[str] = []

    # The patient's own name, taken from patientInfo before it is blanked. A
    # requester who typed the name into a free text box is the case a pattern
    # cannot catch, and this is the one chance to catch it by knowing the answer.
    for name in extra_names:
        name = (name or "").strip()
        if len(name) < 3:
            continue
        pattern = re.compile(r"\b" + re.escape(name) + r"\b", re.IGNORECASE)
        if pattern.search(text):
            text = pattern.sub("[NAME]", text)
            hits.append("NAME")

    for label, pattern in PATTERNS:
        if pattern.search(text):
            text = pattern.sub(f"[{label}]", text)
            hits.append(label)

    return text, hits


def deidentify(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Return a cleaned copy plus a report of what was dropped, masked, unknown."""
    report: Dict[str, Any] = {
        "droppedTop": [], "droppedLeg": [], "unknownTop": [], "unknownLeg": [],
        "maskedIn": [], "patternsHit": [], "patientFieldsCleared": [],
    }

    # Names first: needed to scrub free text, and gone from the output after.
    names: List[str] = []
    legs_in = payload.get("tripLegs") or []
    for leg in legs_in:
        info = (leg or {}).get("patientInfo") or {}
        for key in ("firstName", "lastName", "middleName"):
            value = info.get(key)
            if isinstance(value, str) and value.strip():
                names.append(value.strip())
        for key in info:
            if key not in KEEP_PATIENT and info.get(key) not in ("", None, False):
                report["patientFieldsCleared"].append(key)

    clean: Dict[str, Any] = {}
    for key, value in payload.items():
        if key == "tripLegs":
            continue
        if key in KEEP_TOP:
            clean[key] = value
        elif key in KNOWN_IDENTIFYING_TOP or key in KNOWN_NONCLINICAL_TOP:
            report["droppedTop"].append(key)
        else:
            # Not recognised. Dropped, and surfaced for a person to classify.
            report["unknownTop"].append(key)

    clean_legs = []
    for leg in legs_in:
        leg = leg or {}
        clean_leg: Dict[str, Any] = {}
        for key, value in leg.items():
            if key == "patientInfo":
                continue
            if key in KEEP_LEG:
                clean_leg[key] = value
            elif (key in KNOWN_IDENTIFYING_LEG or key in KNOWN_NONCLINICAL_LEG
                  or key.startswith(KNOWN_IDENTIFYING_LEG_PREFIX)):
                report["droppedLeg"].append(key)
            else:
                report["unknownLeg"].append(key)

        # Scrub every free-text field the model will read, not only clinicalData.
        for field in FREE_TEXT_LEG:
            blob = clean_leg.get(field)
            if isinstance(blob, str) and blob.strip():
                scrubbed, hits = _scrub_text(blob, names)
                if hits:
                    clean_leg[field] = scrubbed
                    report["maskedIn"].append(field)
                    report["patternsHit"].extend(hits)

        questions = clean_leg.get("losQuestions")
        if isinstance(questions, list):
            for entry in questions:
                if not isinstance(entry, dict):
                    continue
                for field in ("answer", "questionText", "answerValue"):
                    value = entry.get(field)
                    if isinstance(value, str):
                        scrubbed, hits = _scrub_text(value, names)
                        if hits:
                            entry[field] = scrubbed
                            report["maskedIn"].append(f"losQuestions.{field}")
                            report["patternsHit"].extend(hits)

        blank_patient = {k: ((leg.get("patientInfo") or {}).get(k)) for k in KEEP_PATIENT}
        clean_leg["patientInfo"] = blank_patient
        clean_legs.append(clean_leg)

    for field in FREE_TEXT_TOP:
        blob = clean.get(field)
        if isinstance(blob, str) and blob.strip():
            scrubbed, hits = _scrub_text(blob, names)
            if hits:
                clean[field] = scrubbed
                report["maskedIn"].append(field)
                report["patternsHit"].extend(hits)

    clean["tripLegs"] = clean_legs

    for key in ("droppedTop", "droppedLeg", "unknownTop", "unknownLeg",
                "maskedIn", "patternsHit", "patientFieldsCleared"):
        report[key] = sorted(set(report[key]))

    return {"payload": clean, "report": report}


def residual_scan(payload: Dict[str, Any]) -> List[str]:
    """Last look at the cleaned payload. Anything here is a leak, not a warning."""
    text = json.dumps(payload)
    found = []
    for label, pattern in PATTERNS:
        for match in pattern.findall(text):
            if isinstance(match, str) and match.startswith("["):
                continue
            found.append(f"{label}: {str(match)[:40]}")
    return sorted(set(found))
