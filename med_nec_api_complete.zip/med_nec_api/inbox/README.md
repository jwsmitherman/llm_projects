# inbox

Drop trip request JSON files here and run:

```powershell
python run_batch.py --dir .\inbox
```

Every `*.json` in the folder gets posted at the service and the results land in
one workbook alongside them. Nothing else reads this folder, and the name carries
no meaning to the service: `--dir` takes any path, so pointing it straight at the
folder you downloaded from Databricks works just as well.

This exists because the review screen at `/ui` handles one trip at a time, which
is right for looking at a determination closely and wrong for fifty.

Payloads come from `med_nec_payload_builder.ipynb` in Databricks. Real payloads
should not be committed: they carry clinical free text, and while the builder
strips the structured patient fields and holds back anything matching a date of
birth, SSN or MRN pattern, that is a filter rather than a guarantee.

The builder writes one folder per trip, holding `payload.json` and `epcr.csv`.
The batch runner reads the orders only, so it is happy to be pointed at the
whole tree:

```powershell
python run_batch.py --dir .\inbox
```

The record assessment runs one trip at a time at `/ui`, where both files go on
the page together. There is no batch form of it yet, and `epcr.csv` is the file
to be most careful with: it is not de-identified.
