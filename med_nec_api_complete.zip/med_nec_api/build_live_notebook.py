"""Regenerates med_nec_live_test.ipynb."""

import nbformat as nbf

nb = nbf.v4.new_notebook()
C = []


def md(text):
    C.append(nbf.v4.new_markdown_cell(text.strip()))


def code(text):
    C.append(nbf.v4.new_code_cell(text.strip()))


md("""
# Medical necessity service — live test

Walks one trip request through the service and shows what comes back at each
point, then runs a whole folder and reports the numbers that matter for sizing.

The review screen at `/ui` does the same thing for someone who should not have to
read a notebook. This is the version you can take apart, and the only place the
raw response and the aggregate numbers sit side by side.

**Start the service first, in a terminal, from the `med_nec_api` folder:**

```powershell
az login
python -m uvicorn app:app --reload --port 8000
```

Every call here is a real model call. There are no stored answers: a payload the
model cannot be asked about returns a 503 with the reason, not a default.
""")

md("## 1. Settings")

code("""
import json, time, glob, os
from pathlib import Path
import httpx
import pandas as pd

BASE = "http://127.0.0.1:8000"
TIMEOUT = 180.0
PAYLOAD_DIR = Path("inbox")

pd.set_option("display.max_colwidth", 95)
pd.set_option("display.width", 220)

client = httpx.Client(base_url=BASE, timeout=TIMEOUT)
# rglob, not glob: the builder writes one folder per trip holding payload.json
# and epcr.csv. A flat folder of loose json files still works.
print("target     :", BASE)
print("payload dir:", PAYLOAD_DIR.resolve())
print("payloads   :", len(sorted(PAYLOAD_DIR.rglob("*.json"))) if PAYLOAD_DIR.is_dir() else "folder missing")
""")

md("""
## 2. Is the service up, and is the model reachable

Two different questions. The first cell says the service is running; the second
makes an actual model call. A failure in the second names the thing to check
rather than leaving you to read a stack trace.
""")

code("""
health = client.get("/healthz").json()
for key in ["status", "inference", "engineVersion", "knowledgeVersion"]:
    print(f"{key:18}: {health.get(key)}")
if health.get("modelImportError"):
    print()
    print("model import error:", health["modelImportError"])
""")

code("""
engine = client.get("/v1/engine").json()

print("reachable :", engine.get("reachable"))
if engine.get("reachable"):
    print("latency   :", engine.get("latencyMs"), "ms")
    print("reply     :", engine.get("reply"))
    print()
    for key, value in (engine.get("settings") or {}).items():
        print(f"  {key:18}: {value}")
else:
    print()
    print("error     :", str(engine.get("error"))[:400])
    print("what to do:", engine.get("hint"))
""")

md("""
## 3. The payload

Drop trip folders in `inbox/`. They come from `med_nec_payload_builder.ipynb` in
Databricks, which reads the trip table, parses `ClinicalData` into the structured
`losQuestions` array, strips every patient identifier, and writes
`<trip id>/payload.json` beside `<trip id>/epcr.csv`.

Loose json files in `inbox/` work too. The record half is simply absent for
those, and section 7a says so rather than failing.

Set `STEM` to pick a trip by folder or file name, or leave it as `None` to take
the first.
""")

code("""
STEM = None

available = sorted(PAYLOAD_DIR.rglob("*.json"))
if not available:
    raise FileNotFoundError(
        f"No payloads in {PAYLOAD_DIR.resolve()}. "
        "Generate some with med_nec_payload_builder.ipynb in Databricks.")

if STEM:
    matches = [p for p in available
               if p.stem == STEM or p.parent.name == STEM]
    if not matches:
        raise FileNotFoundError(f"No payload matching {STEM!r} under {PAYLOAD_DIR.resolve()}")
    path = matches[0]
else:
    path = available[0]

trip = json.loads(path.read_text())

# The record for this same trip, when the folder carries one.
epcr_path = path.parent / "epcr.csv"
if not epcr_path.is_file():
    epcr_path = None

print("file  :", path.relative_to(PAYLOAD_DIR))
print("record:", epcr_path.name if epcr_path else "none in this folder")
print("of    :", len(available), "payload(s) in the tree")
for other in available[:8]:
    print("   ", other.relative_to(PAYLOAD_DIR))
if len(available) > 8:
    print("    ...")
""")

md("""
## 4. What bears on the determination

Two things: the context the trip carries, and the answers themselves. The service
reads only the answers, but the context decides which decision tree governs, so
it is worth seeing both before submitting.
""")

code("""
leg = (trip.get("tripLegs") or [{}])[0]
reference = client.get("/v1/criteria/reference").json()

modifiers = {m["code"]: m["meaning"]
             for m in reference.get("modifierScaleLowestToHighest") or []}
order = [m["code"] for m in reference.get("modifierScaleLowestToHighest") or []]

origin = leg.get("pickupLocTypeCode")
destination = leg.get("dropoffLocTypeCode")
diagnosis = str(leg.get("medicareQuestionTen") or "").replace("DX:", "").strip()

print("level of service :", leg.get("levelOfService"), " of", reference.get("levelOfServiceScale"))
print("trip reason      :", trip.get("tripReason"))
print("diagnosis given  :", diagnosis or "none")
print("trip request id  :", trip.get("sourceSystemTripId"))
print("requested        :", trip.get("requestDateTime"))
print()
print("origin           :", origin, "-", modifiers.get(origin, "not on the modifier scale"))
print("destination      :", destination, "-", modifiers.get(destination, "not on the modifier scale"))
print()

if origin in order and destination in order:
    if order.index(origin) < order.index(destination):
        print("DECISION TREE    : higher level of care")
        print("                   Origin sits lower on the modifier scale than the")
        print("                   destination, so this is an upgrade in care.")
    else:
        print("DECISION TREE    : lower level of care")
        print("                   Origin is at or above the destination, which is the")
        print("                   discharge pattern.")
else:
    print("DECISION TREE    : not determined, lower level of care applies by default")
    print("                   One or both codes are missing from this payload. Worth")
    print("                   confirming Transport.net sends them, because without")
    print("                   them every order defaults to the same tree.")
""")

md("""
The answers, extracted the way the service extracts them. `losQuestions` when it
is populated, otherwise the flat `clinicalData` string parsed back into pairs.
Real payloads arrive both ways, so this is not a rare fallback.
""")

code("""
pairs = []
for q in leg.get("losQuestions") or []:
    if not isinstance(q, dict):
        continue
    answer = str(q.get("answer") or "").strip()
    if not answer:
        continue
    free = str(q.get("answerValue") or "").strip()
    if free and free.lower() != answer.lower():
        answer = f"{answer}: {free}"
    pairs.append({"questionId": q.get("questionId"),
                  "question": str(q.get("questionText") or "").strip()[:80],
                  "answer": answer[:110]})

print(f"{len(pairs)} answers from losQuestions")
if not pairs:
    print("losQuestions is empty or null, so the service parses clinicalData instead:")
    print()
    print(str(leg.get("clinicalData") or "")[:600])

pd.DataFrame(pairs) if pairs else None
""")

md("""
## 5. Submit

What Transport.net calls on submission. Three fields come back at the top level
and those are the only ones the UI acts on.
""")

code("""
started = time.perf_counter()
response = client.post("/v1/medical-necessity/evaluate", json=trip)
elapsed = int((time.perf_counter() - started) * 1000)

if response.status_code != 200:
    body = response.json()
    print("NO DETERMINATION")
    print()
    print("status    :", response.status_code)
    print("error     :", body.get("error"))
    print("detail    :", str(body.get("detail"))[:400])
    print("what to do:", body.get("hint"))
    print("action    :", body.get("action"))
    raise SystemExit("The model could not be reached. Nothing below will work.")

initial = response.json()
meta = initial["meta"]

print("round trip      :", elapsed, "ms")
print("  model         :", meta.get("modelMs"), "ms")
print("  service        :", meta.get("overheadMs"), "ms")
print("tokens in / out :", meta.get("inputTokens"), "/", meta.get("outputTokens"))
print("model calls     :", meta.get("modelCalls"))
if meta.get("estimatedCostUsd") is not None:
    print("cost            : $", meta["estimatedCostUsd"])
print()
print("meetsMedicalNecessity:", initial["meetsMedicalNecessity"])
print()
print("clinicalSummary:")
print(" ", initial["clinicalSummary"])
print()
print("clarifyingQuestion:")
print(" ", initial["clarifyingQuestion"])
""")

md("""
### What the requester sees

`clarifyingQuestion` is `null` when nothing needs asking, which is the signal to
show nothing and let the submission continue.
""")

code("""
question = initial["clarifyingQuestion"]

if question:
    print("+" + "-" * 76 + "+")
    print("|  Before this trip can be submitted" + " " * 41 + "|")
    print("+" + "-" * 76 + "+")
    for i in range(0, len(question), 72):
        print("|  " + question[i:i + 72].ljust(73) + "|")
    print("|" + " " * 76 + "|")
    print("|  [                                                      ]  [ Submit ]  |")
    print("+" + "-" * 76 + "+")
else:
    print("No question. The trip submits unchanged and the requester sees nothing.")
""")

md("""
## 6. Why it decided that

`detail` is what goes to the database rather than the screen. One row per
question and answer pair, each with the criterion it maps to, the citation behind
it, and the verbatim text it rests on.

**A criterion the model cannot quote is not documented.** That rule is in the
instruction, and the `evidence` column is how you check it held.
""")

code("""
detail = initial.get("detail") or {}

print("determination:", detail.get("determination"))
print("confidence   :", detail.get("confidence"))
print("basis        :", detail.get("basis"))
print()

findings = pd.DataFrame(detail.get("questionFindings") or [])
if len(findings):
    columns = [c for c in ["questionId", "category", "nonMedNec", "criterionId",
                           "evidence", "confidence"] if c in findings.columns]
    display(findings[columns])
else:
    print("no questionFindings returned")
""")

code("""
documented = pd.DataFrame(detail.get("criteriaDocumented") or [])
print(f"criteria documented: {len(documented)}")
display(documented if len(documented) else "none")

excluded = pd.DataFrame(detail.get("exclusionsTriggered") or [])
print(f"exclusions triggered: {len(excluded)}")
display(excluded if len(excluded) else "none")
""")

md("""
## 7. The clarifying answer

The requester types an answer and it goes back for reassessment. A re-evaluation
never asks again: the requester is asked once.

Edit `ANSWER` to try different responses against the same trip. That is the
cheapest way to see where the line actually sits.
""")

code("""
ANSWER = ("Patient had a stroke last week with dense left sided weakness. "
          "Cannot sit upright unsupported and requires two person assist for "
          "all transfers.")

if not question:
    print("Nothing was asked, so there is nothing to answer.")
    final = initial
else:
    started = time.perf_counter()
    final = client.post("/v1/medical-necessity/reevaluate", json={
        "tripRequest": trip,
        "clarification": {"question": question, "answer": ANSWER},
    }).json()
    reeval_ms = int((time.perf_counter() - started) * 1000)

    print("ANSWERED:", ANSWER)
    print()
    print(f"{'':16} {'before':<16} {'after':<16}")
    print(f"{'meets':16} {str(initial['meetsMedicalNecessity']):<16} {str(final['meetsMedicalNecessity']):<16}")
    print(f"{'determination':16} {str(detail.get('determination')):<16} {str((final.get('detail') or {}).get('determination')):<16}")
    print(f"{'confidence':16} {str(detail.get('confidence')):<16} {str((final.get('detail') or {}).get('confidence')):<16}")
    print()
    print("updated summary:")
    print(" ", final["clinicalSummary"])
    print()
    print("asked again:", final["clarifyingQuestion"])
    print("second call:", reeval_ms, "ms")
""")

md("""
## 7a. The patient care record

The second assessment, and the only one that reads what actually happened. The
order is what a requester anticipated; the record is what a crew wrote afterwards.

The whole csv goes over the wire and the service picks the columns. Payment
method and insurance never reach the model, and neither do the order's own
answers, which are in the record table too and would turn the second opinion into
a copy of the first.
""")

code("""
if epcr_path is None:
    print("No epcr.csv beside this payload, so there is nothing to assess here.")
    print("Folders written by med_nec_payload_builder.ipynb carry one.")
    record = None
else:
    trip_request_id = str(trip.get("sourceSystemTripId") or "")
    started = time.perf_counter()
    response = client.post("/v1/medical-necessity/evaluate-epcr",
                           json={"csv": epcr_path.read_text(),
                                 "tripRequestId": trip_request_id or None})
    epcr_ms = int((time.perf_counter() - started) * 1000)

    if response.status_code != 200:
        record = None
        body = response.json()
        print(f"{response.status_code}  {body.get('error')}")
        print(body.get("message") or body.get("detail"))
    else:
        record = response.json()
        selection = record["detail"].get("selection") or {}

        print("round trip        :", epcr_ms, "ms")
        print("record matched    :", selection.get("epcrMatched"))
        print(f"fields read       : {selection.get('populated')} of "
              f"{selection.get('offered')}   withheld {selection.get('withheld')}")
        print("fields version    :", selection.get("fieldsVersion"))
        print()
        print("meets medical necessity:", record["meetsMedicalNecessity"])
        print()
        print("summary:")
        print(" ", record["clinicalSummary"])
        print()
        print("strongest evidence:")
        print(" ", record["detail"].get("strongestEvidence"))
        print()
        gaps = record.get("documentationGaps") or []
        if gaps:
            print(f"documentation gaps ({len(gaps)}):")
            for gap in gaps:
                print("  -", gap)
        else:
            print("documentation gaps: none")
""")

md("""
Where the two agree, the order entry guidance is predicting what the record will
support, which is the whole point of asking at order entry. Where they disagree,
one of them is wrong, and which one decides what gets fixed.

Run this across a folder and the disagreement rate is the first real measure of
the guidance. It is not an accuracy rate until a reviewer has labelled a sample:
a disagreement says the two halves differ, not which half is right.
""")

code("""
if record is None:
    print("No record assessment to compare against.")
else:
    # `final` is the determination after the clarifying answer when one was
    # asked for, and `initial` otherwise. Section 7 sets it either way.
    order_meets = final["meetsMedicalNecessity"]
    record_meets = record["meetsMedicalNecessity"]

    print(f"order  : {order_meets}")
    print(f"record : {record_meets}")
    print()

    if record_meets is None:
        print("No record verdict. The record is unmatched or carries no clinical")
        print("content, which is not evidence against the trip.")
    elif order_meets == record_meets:
        print("They agree.")
    elif record_meets:
        print("The order read does not meet and the record reads meets.")
        print("Either the requester under-documented at order entry, or the")
        print("guidance asked for something the record shows another way.")
    else:
        print("The order read meets and the record reads does not.")
        print("This is the expensive direction: the trip was approved on an")
        print("expectation the record does not support, and a biller finds out.")

    for finding in (record["detail"].get("fieldFindings") or [])[:8]:
        print()
        print(f"  {finding['field']}: {str(finding['value'])[:70]}")
        print(f"    {finding['bearing']}  {finding.get('criterionId') or ''}")
        print(f"    {finding.get('reason')}")
""")

md("""
## 8. The whole folder

One call per payload. This is the run worth doing before a review: it produces
the determination mix and the latency and token numbers in one pass.

Set `ANSWER_QUESTIONS` to also send a standing clarifying answer wherever a
question came back, which doubles the calls.
""")

code("""
ANSWER_QUESTIONS = False
LIMIT = 0

STANDING_ANSWER = "No additional clinical detail is available for this retrospective trip."

batch = sorted(PAYLOAD_DIR.rglob("*.json"))
if LIMIT:
    batch = batch[:LIMIT]

print(f"{len(batch)} payloads, up to {len(batch) * (2 if ANSWER_QUESTIONS else 1)} calls")
print()

rows = []
for index, file in enumerate(batch, 1):
    payload = json.loads(file.read_text())
    label = file.relative_to(PAYLOAD_DIR).as_posix()
    row = {"file": label,
           "tripId": payload.get("sourceSystemTripId"),
           "los": ((payload.get("tripLegs") or [{}])[0]).get("levelOfService")}

    started = time.perf_counter()
    reply = client.post("/v1/medical-necessity/evaluate", json=payload)
    row["ms"] = int((time.perf_counter() - started) * 1000)
    row["status"] = reply.status_code

    if reply.status_code != 200:
        row["error"] = str(reply.json().get("detail"))[:90]
        rows.append(row)
        print(f"  [{index}/{len(batch)}] {label[:44]:44} ERROR {row['error'][:40]}")
        continue

    body = reply.json()
    d, m = body.get("detail") or {}, body.get("meta") or {}
    row.update({
        "meets": body["meetsMedicalNecessity"],
        "determination": d.get("determination"),
        "confidence": d.get("confidence"),
        "asked": bool(body["clarifyingQuestion"]),
        "inTok": m.get("inputTokens"),
        "outTok": m.get("outputTokens"),
        "modelMs": m.get("modelMs"),
        "cost": m.get("estimatedCostUsd"),
        "summary": body["clinicalSummary"],
        "question": body["clarifyingQuestion"],
        "criteria": ", ".join(str(c.get("criterionId")) for c in d.get("criteriaDocumented") or []),
        "exclusions": ", ".join(str(e.get("exclusionId")) for e in d.get("exclusionsTriggered") or []),
    })

    if ANSWER_QUESTIONS and body["clarifyingQuestion"]:
        after = client.post("/v1/medical-necessity/reevaluate", json={
            "tripRequest": payload,
            "clarification": {"question": body["clarifyingQuestion"],
                              "answer": STANDING_ANSWER},
        })
        if after.status_code == 200:
            row["meetsAfter"] = after.json()["meetsMedicalNecessity"]

    rows.append(row)
    print(f"  [{index}/{len(batch)}] {label[:44]:44} {str(row['determination'])[:16]:16} {row['ms']:>6} ms")

results = pd.DataFrame(rows)
print()
print(f"{len(results)} rows")
""")

code("""
columns = [c for c in ["file", "tripId", "los", "determination", "meets", "asked",
                       "confidence", "ms", "inTok", "outTok"] if c in results.columns]
results[columns]
""")

md("""
### The determination mix

Worth reading before the latency numbers. A run that is almost all one outcome is
usually telling you something about the criteria or the data rather than about
the trips.
""")

code("""
if "determination" in results:
    counts = results["determination"].value_counts(dropna=False)
    total = int(counts.sum())
    for value, count in counts.items():
        bar = "#" * int(40 * count / total)
        print(f"  {str(value):18} {count:>4}  {100*count/total:5.1f}%  {bar}")
    print()
    print(f"  asked a question   {int(results['asked'].fillna(False).sum()):>4}")
if "error" in results and results["error"].notna().any():
    print(f"  errors             {int(results['error'].notna().sum()):>4}")
""")

md("""
## 9. Sizing

The numbers for the submission timeout and the quota request. The architecture
slide carries a working figure of two to five seconds for the timeout; p95 here
is what confirms or breaks it.
""")

code("""
stats = client.get("/v1/stats").json()
print(json.dumps(stats, indent=2))
""")

code("""
latency = stats.get("latencyMs") or {}
sizing = stats.get("sizing") or {}
cost = stats.get("cost") or {}

print("round trip, milliseconds")
for label in ["p50", "p95", "max"]:
    print(f"  {label:6} {latency.get(label)}")
print()
print("model time only")
for label in ["modelP50", "modelP95"]:
    print(f"  {label:10} {latency.get(label)}")
print()
print("per trip, order entry")
print("  requests        :", sizing.get("requestsPerTrip"))
print("  model calls     :", sizing.get("modelCallsPerTrip"))
print("  mean tokens     :", sizing.get("meanTokensPerTrip"))
print()

# Counted apart from order entry on purpose. Records are scored retrospectively,
# often in a batch of their own, so folding them in would report a per-order cost
# no order actually incurs.
if sizing.get("recordAssessments"):
    print("per record, retrospective")
    print("  assessments     :", sizing.get("recordAssessments"))
    print("  model calls     :", sizing.get("modelCallsPerRecord"))
    print("  mean tokens     :", sizing.get("meanTokensPerRecord"))
    print()

p95 = latency.get("p95")
if p95 and p95 > 5000:
    print(f"CHECK  p95 is {p95/1000:.1f}s, above the two to five second working figure")
    print("       for the submission timeout. Three options to put in front of Dave:")
    print("       raise the timeout, drop to a smaller model, or stop holding the")
    print("       submission and return the determination asynchronously.")
elif p95:
    print(f"PASS   p95 is {p95/1000:.1f}s, inside the working figure for the timeout.")

if cost.get("ratesConfigured"):
    per_trip = sizing.get("modelCallsPerTrip") or 1
    mean = cost.get("meanPerCallUsd") or 0
    print()
    print(f"cost per trip   : ${mean * per_trip:.4f}")
    print(f"per 1,000 trips : ${mean * per_trip * 1000:.2f}")
else:
    print()
    print(cost.get("note"))
""")

md("""
On quota. Sonnet is deployed at 80K TPM. Mean tokens per trip times trips per
minute has to stay under that, and a trip that gets a clarifying question costs
two calls rather than one.
""")

code("""
TPM_QUOTA = 80000

mean_tokens = (stats.get("sizing") or {}).get("meanTokensPerTrip")
calls_per_trip = (stats.get("sizing") or {}).get("modelCallsPerTrip") or 1

if mean_tokens:
    # meanTokensPerTrip already totals every call made for that trip, including
    # a re-evaluation. Multiplying by calls per trip would count them twice.
    trips_per_minute = TPM_QUOTA / mean_tokens
    print(f"quota              : {TPM_QUOTA:,} TPM")
    print(f"tokens per trip    : {int(mean_tokens):,}")
    print(f"  across           : {calls_per_trip} model call(s)")
    print(f"ceiling            : {trips_per_minute:.0f} trips a minute")
    print()
    print("Compare that against peak order volume. If it is close, the quota needs")
    print("raising before pilot, not after.")
    print()
    print("This is the sustained ceiling, not a burst. A minute that runs over it")
    print("is throttled, and a throttled call inside a held submission is a timeout")
    print("from the requester's side.")
else:
    print("No token data yet. Run the batch above first.")
""")

md("""
## 10. Timeout behaviour

Transport.net holds the submission while the call is in flight and proceeds
unchanged if it does not answer in time. This is that path, forced with a short
client timeout rather than by waiting for a slow trip.
""")

code("""
try:
    httpx.post(f"{BASE}/v1/medical-necessity/evaluate?delayMs=8000",
               json=trip, timeout=2.0)
    print("returned in time")
except httpx.TimeoutException:
    print("client timed out at 2s")
    print()
    print("Transport.net submits the trip unchanged. No summary, no flag, no")
    print("question. The requester sees nothing and the order is not blocked.")
""")

md("""
## 11. Event log

One row per call. This stands in for the `request_event_logs` table on the
Transport.net side, and it is what `/v1/stats` aggregates.
""")

code("""
log_path = Path("request_event_log.jsonl")
if log_path.exists():
    events = pd.DataFrame(json.loads(line) for line in log_path.read_text().splitlines() if line.strip())
    columns = [c for c in ["receivedAtUtc", "callType", "determination",
                           "meetsMedicalNecessity", "clarifyingQuestionReturned",
                           "inputTokens", "outputTokens", "modelMs", "processingMs",
                           "knowledgeVersion"] if c in events.columns]
    display(events[columns].tail(20))
    print(f"{len(events)} events total")
else:
    print("No event log yet.")
""")

md("""
## What to do with this

- **Section 7 is where accuracy work happens.** Change `ANSWER` and re-run to see
  where the line sits between an answer that rescues a trip and one that does
  not. Cheaper than changing the criteria and re-running everything.
- **Section 8 then 9** is the run to do before a review. The determination mix
  tells you whether the criteria are behaving; p95 and the token numbers tell you
  whether the design holds.
- **To change what the model is told**, edit `prompts/system_prompt.md` or
  `prompts/med_nec_knowledge.json` and restart the service. Bump
  `knowledge_version` when you change the criteria, or two runs will be
  indistinguishable in the event log.
""")

nb["cells"] = C
nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
nb.metadata["language_info"] = {"name": "python", "version": "3.11"}

with open("med_nec_live_test.ipynb", "w") as handle:
    nbf.write(nb, handle)

print(f"written: {len(C)} cells, {sum(1 for c in C if c.cell_type == 'code')} code")
