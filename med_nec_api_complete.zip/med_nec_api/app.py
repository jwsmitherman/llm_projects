"""Medical necessity guidance service.

Transport.net posts a trip request on submission and gets back three things: a
clinical summary, a flag for whether the trip meets medical necessity, and a
clarifying question when one is needed.

Every determination comes from the Claude deployment in Azure AI Foundry,
authenticated with managed identity. There are no stored answers: a payload the
model cannot be asked about returns an error rather than a default, because a
default would be indistinguishable from a determination.
"""

import json
import logging
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).parent

try:  # a .env next to this file beats retyping settings in every terminal
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env.local", override=False)
    load_dotenv(ROOT / ".env", override=False)
except ImportError:
    pass

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("med-nec")

SERVICE_NAME = "med-nec-guidance"
SERVICE_VERSION = "0.3.0-local"

STATIC_DIR = ROOT / "static"
KNOWLEDGE_PATH = ROOT / "prompts" / "med_nec_knowledge.json"
EVENT_LOG_PATH = Path(os.environ.get("EVENT_LOG_PATH", ROOT / "request_event_log.jsonl"))

DEFAULT_DELAY_MS = int(os.environ.get("SIMULATED_LATENCY_MS", "0"))


def _rate(name: str) -> Optional[float]:
    """Price per million tokens. Unset means no cost is reported.

    Deliberately not defaulted. Foundry pricing is contract specific and a
    guessed number would end up in a sizing conversation as if it were real.
    """
    raw = os.environ.get(name, "").strip()
    try:
        return float(raw) if raw else None
    except ValueError:
        log.warning("%s is not a number, ignoring: %r", name, raw)
        return None


INPUT_RATE = _rate("COST_PER_MTOK_INPUT")
OUTPUT_RATE = _rate("COST_PER_MTOK_OUTPUT")


def estimate_cost(input_tokens: Optional[int], output_tokens: Optional[int]) -> Optional[float]:
    if INPUT_RATE is None or OUTPUT_RATE is None:
        return None
    cost = ((input_tokens or 0) / 1_000_000) * INPUT_RATE \
         + ((output_tokens or 0) / 1_000_000) * OUTPUT_RATE
    return round(cost, 6)

try:
    KNOWLEDGE_VERSION = json.loads(KNOWLEDGE_PATH.read_text()).get("knowledge_version")
except Exception:
    KNOWLEDGE_VERSION = None

llm = None
LLM_IMPORT_ERROR: Optional[str] = None
try:
    import llm as llm_module
    llm = llm_module
except Exception as exc:  # missing sdk, missing knowledge file
    LLM_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"
    log.error("llm.py did not import: %s", LLM_IMPORT_ERROR)

app = FastAPI(
    title="Medical necessity guidance service",
    description=(
        "Evaluates a non-emergent ground ambulance trip request against CMS medical "
        "necessity criteria. Post a trip request payload; the criteria are compiled "
        "into one instruction and the whole trip is assessed in a single model call."
    ),
    version=SERVICE_VERSION,
)

if STATIC_DIR.is_dir():
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class Clarification(BaseModel):
    question: str = Field(..., description="The clarifying question presented to the requester.")
    answer: str = Field(..., description="Free text the requester typed in response.")


class EpcrRequest(BaseModel):
    """One patient care record. Send a parsed row, or the CSV and let the service parse it."""
    row: Optional[Dict[str, Any]] = Field(None, description="A single ePCR row as an object.")
    csv: Optional[str] = Field(None, description="Raw CSV text. The first row is used unless tripRequestId is given.")
    tripRequestId: Optional[str] = Field(None, description="Which row to take when the CSV has several.")


class ReevaluateRequest(BaseModel):
    tripRequest: Dict[str, Any] = Field(..., description="The original trip request payload, unchanged.")
    clarification: Clarification


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def first_leg(trip: Dict[str, Any]) -> Dict[str, Any]:
    legs = trip.get("tripLegs") or []
    return legs[0] if legs else {}


def question_count(trip: Dict[str, Any]) -> int:
    if llm is None:
        return 0
    try:
        return len(llm.extract_pairs(trip))
    except Exception:
        return 0


def write_event(event: Dict[str, Any]) -> None:
    try:
        with EVENT_LOG_PATH.open("a") as handle:
            handle.write(json.dumps(event) + "\n")
    except Exception:
        pass


def envelope(
    trip: Dict[str, Any],
    block: Dict[str, Any],
    call_type: str,
    received_at: str,
    started: float,
    delay_ms: int,
) -> Dict[str, Any]:
    leg = first_leg(trip)
    if delay_ms > 0:
        time.sleep(delay_ms / 1000.0)
    processing_ms = int((time.perf_counter() - started) * 1000)
    responded_at = utc_now()

    detail = block.get("detail") or {}
    usage = detail.get("usage") or {}

    body = {
        "evaluationId": str(uuid.uuid4()),
        "olosRequestId": trip.get("olosRequestId"),
        "correlationId": trip.get("correlationId"),
        "sourceSystemTripId": trip.get("sourceSystemTripId"),
        "requesterFacilityId": trip.get("requesterFacilityId"),
        "levelOfService": leg.get("levelOfService"),
        "callType": call_type,

        "clinicalSummary": block.get("clinicalSummary"),
        "meetsMedicalNecessity": block.get("meetsMedicalNecessity"),
        "clarifyingQuestion": block.get("clarifyingQuestion"),

        "detail": detail,

        "meta": {
            "service": SERVICE_NAME,
            "serviceVersion": SERVICE_VERSION,
            "engineVersion": llm.engine_version() if llm else None,
            "knowledgeVersion": KNOWLEDGE_VERSION,
            "inference": "foundry-model",
            "questionsEvaluated": question_count(trip),

            "inputTokens": usage.get("inputTokens"),
            "outputTokens": usage.get("outputTokens"),
            "totalTokens": (usage.get("inputTokens") or 0) + (usage.get("outputTokens") or 0),
            "estimatedCostUsd": estimate_cost(usage.get("inputTokens"),
                                              usage.get("outputTokens")),
            "model": usage.get("model"),
            "modelCalls": usage.get("modelCalls"),
            "promptChars": usage.get("promptChars"),
            "pairsSent": usage.get("pairsSent"),

            "receivedAtUtc": received_at,
            "respondedAtUtc": responded_at,
            "processingMs": processing_ms,
            "modelMs": usage.get("modelMs"),
            "overheadMs": max(0, processing_ms - (usage.get("modelMs") or 0)),
        },
    }

    write_event({
        "evaluationId": body["evaluationId"],
        "olosRequestId": body["olosRequestId"],
        "sourceSystemTripId": body["sourceSystemTripId"],
        "callType": call_type,
        "inference": "foundry-model",
        "determination": (detail or {}).get("determination"),
        "meetsMedicalNecessity": body["meetsMedicalNecessity"],
        "clarifyingQuestionReturned": bool(body["clarifyingQuestion"]),
        "questionsEvaluated": body["meta"]["questionsEvaluated"],
        "inputTokens": usage.get("inputTokens"),
        "outputTokens": usage.get("outputTokens"),
        "estimatedCostUsd": body["meta"]["estimatedCostUsd"],
        "modelCalls": usage.get("modelCalls"),
        "knowledgeVersion": KNOWLEDGE_VERSION,
        "receivedAtUtc": received_at,
        "respondedAtUtc": responded_at,
        "processingMs": processing_ms,
        "modelMs": usage.get("modelMs"),
    })

    return body


def model_unavailable(detail: str, hint: str, received_at: str, started: float) -> JSONResponse:
    """An error Transport.net can act on, not a determination it might trust."""
    log.error("model unavailable: %s", detail)
    write_event({
        "callType": "error",
        "error": detail,
        "receivedAtUtc": received_at,
        "respondedAtUtc": utc_now(),
        "processingMs": int((time.perf_counter() - started) * 1000),
    })
    return JSONResponse(status_code=503, content={
        "error": "guidance_unavailable",
        "message": "The guidance service could not evaluate this trip.",
        "detail": detail,
        "hint": hint,
        "action": "Submit the trip unchanged.",
        "clinicalSummary": None,
        "meetsMedicalNecessity": None,
        "clarifyingQuestion": None,
    })


def evaluate_payload(
    trip: Dict[str, Any],
    call_type: str,
    clarification: Optional[Dict[str, str]],
    delay_ms: int,
) -> JSONResponse:
    received_at = utc_now()
    started = time.perf_counter()

    if llm is None:
        return model_unavailable(
            LLM_IMPORT_ERROR or "llm.py is not importable",
            "pip install -r requirements.txt",
            received_at, started)

    try:
        block = llm.evaluate_trip(trip, clarification)
    except Exception as exc:
        return model_unavailable(
            f"{type(exc).__name__}: {exc}"[:600],
            llm.diagnose(exc),
            received_at, started)

    body = envelope(trip, block, call_type, received_at, started, delay_ms)
    return JSONResponse(status_code=200, content=body)


@app.get("/", include_in_schema=False)
def root() -> RedirectResponse:
    return RedirectResponse(url="/ui")


@app.get("/ui", include_in_schema=False)
def ui() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    body = {
        "status": "ok" if llm is not None else "degraded",
        "service": SERVICE_NAME,
        "serviceVersion": SERVICE_VERSION,
        "engineVersion": llm.engine_version() if llm else None,
        "knowledgeVersion": KNOWLEDGE_VERSION,
        "inference": "foundry-model",
        "timeUtc": utc_now(),
    }
    if LLM_IMPORT_ERROR:
        body["modelImportError"] = LLM_IMPORT_ERROR
    return body


@app.get("/v1/engine")
def engine_check() -> JSONResponse:
    """Live connectivity probe. One trivial model call, with the thing to check on failure.

    Worth hitting before a demo: it separates a configuration problem from a
    problem with the evaluation itself.
    """
    if llm is None:
        return JSONResponse(status_code=503, content={
            "reachable": False,
            "error": LLM_IMPORT_ERROR,
            "hint": "pip install anthropic azure-identity",
        })

    settings = llm.settings()
    started = time.perf_counter()
    try:
        reply = llm.ping()
    except Exception as exc:
        return JSONResponse(status_code=503, content={
            "reachable": False,
            "settings": settings,
            "error": f"{type(exc).__name__}: {exc}"[:600],
            "hint": llm.diagnose(exc),
        })
    return JSONResponse(status_code=200, content={
        "reachable": True,
        "settings": settings,
        "reply": reply,
        "latencyMs": int((time.perf_counter() - started) * 1000),
    })


@app.get("/v1/criteria/epcr-fields")
def epcr_fields() -> Dict[str, Any]:
    """What the ePCR assessment reads, and what it is not allowed to see.

    Exposed so the review screen can show the withheld list with its reasons.
    A determination that could see the payer would be a compliance problem, and
    that should be visible rather than buried in a config file.
    """
    if llm is None:
        return {"error": LLM_IMPORT_ERROR}
    spec = llm.get_epcr_spec()
    return {
        "version": spec.get("version"),
        "keyColumn": spec.get("key_column"),
        "send": [{"group": g["group"], "why": g.get("why"), "columns": g["columns"]}
                 for g in spec["send"]],
        "derive": spec.get("derive", []),
        "withhold": spec["withhold"],
        "counts": {
            "sent": sum(len(g["columns"]) for g in spec["send"]),
            "withheld": sum(len(g["columns"]) for g in spec["withhold"]),
        },
    }


@app.get("/v1/criteria/reference")
def criteria_reference() -> Dict[str, Any]:
    """The lookups the review screen needs to label a payload.

    Served from the criteria file rather than duplicated in the page, so there
    is one place where the origin and destination modifiers are defined.
    """
    if llm is None:
        return {"error": LLM_IMPORT_ERROR}
    kb = llm.get_knowledge()
    trees = kb.get("decision_trees") or {}
    return {
        "knowledgeVersion": kb.get("knowledge_version"),
        "levelOfServiceScale": kb.get("level_of_service_scale"),
        "modifierScaleLowestToHighest": trees.get("modifier_scale_lowest_to_highest"),
        "treeSelectionRule": trees.get("selection_rule"),
        "nonSpecificPhrases": kb.get("non_specific_phrases"),
    }


def percentile(values, p):
    if not values:
        return None
    ordered = sorted(values)
    k = (len(ordered) - 1) * (p / 100)
    low, high = int(k), min(int(k) + 1, len(ordered) - 1)
    return int(ordered[low] + (ordered[high] - ordered[low]) * (k - low))


@app.get("/v1/stats")
def stats(limit: int = Query(0, description="Only the most recent N calls. 0 means all.")):
    """Everything the event log knows, aggregated.

    This is the sizing data: how long a determination actually takes, how many
    tokens it costs, and how often a trip needs a second call. The architecture
    slide carries a working figure of two to five seconds for the submission
    timeout, and p95 here is what confirms or breaks it.
    """
    if not EVENT_LOG_PATH.exists():
        return {"calls": 0, "note": "No calls logged yet."}

    rows = []
    for line in EVENT_LOG_PATH.read_text().splitlines():
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            continue
    if limit:
        rows = rows[-limit:]

    ok = [r for r in rows if r.get("callType") != "error"]
    errors = [r for r in rows if r.get("callType") == "error"]

    def nums(key):
        return [r[key] for r in ok if isinstance(r.get(key), (int, float))]

    processing = nums("processingMs")
    model_ms = nums("modelMs")
    in_tok, out_tok = nums("inputTokens"), nums("outputTokens")
    costs = nums("estimatedCostUsd")

    determinations: Dict[str, int] = {}
    for r in ok:
        key = str(r.get("determination") or "unknown")
        determinations[key] = determinations.get(key, 0) + 1

    asked = sum(1 for r in ok if r.get("clarifyingQuestionReturned"))
    retried = sum(1 for r in ok if (r.get("modelCalls") or 1) > 1)

    body: Dict[str, Any] = {
        "calls": len(rows),
        "evaluated": len(ok),
        "errors": len(errors),
        "determinations": determinations,
        "clarifyingQuestionsReturned": asked,
        "responsesRetriedOnValidation": retried,
        "latencyMs": {
            "p50": percentile(processing, 50),
            "p95": percentile(processing, 95),
            "max": max(processing) if processing else None,
            "modelP50": percentile(model_ms, 50),
            "modelP95": percentile(model_ms, 95),
        },
        "tokens": {
            "inputTotal": sum(in_tok),
            "outputTotal": sum(out_tok),
            "inputMean": int(sum(in_tok) / len(in_tok)) if in_tok else None,
            "outputMean": int(sum(out_tok) / len(out_tok)) if out_tok else None,
        },
        "cost": {
            "ratesConfigured": INPUT_RATE is not None and OUTPUT_RATE is not None,
            "inputPerMTok": INPUT_RATE,
            "outputPerMTok": OUTPUT_RATE,
            "totalUsd": round(sum(costs), 4) if costs else None,
            "meanPerCallUsd": round(sum(costs) / len(costs), 6) if costs else None,
        },
        "logFile": str(EVENT_LOG_PATH),
    }

    if not body["cost"]["ratesConfigured"]:
        body["cost"]["note"] = (
            "Set COST_PER_MTOK_INPUT and COST_PER_MTOK_OUTPUT to your contracted "
            "Foundry rates. No default is assumed, because a guessed rate would "
            "end up in a sizing conversation as if it were real.")

    initial = sum(1 for r in ok if r.get("callType") == "initial")
    reevaluations = sum(1 for r in ok if r.get("callType") == "reevaluation")
    records = sum(1 for r in ok if r.get("callType") == "epcr")

    # Order entry and record assessment are two workflows, not two halves of one.
    # Order entry runs at submission; records are scored later, often in a batch
    # of their own. Folding record calls into modelCallsPerTrip would report a
    # per-order cost that no order ever incurs.
    order_rows = [r for r in ok if r.get("callType") in ("initial", "reevaluation")]
    record_rows = [r for r in ok if r.get("callType") == "epcr"]
    order_model_calls = sum(r.get("modelCalls") or 1 for r in order_rows)
    record_model_calls = sum(r.get("modelCalls") or 1 for r in record_rows)

    def _tokens(rows):
        return sum((r.get("inputTokens") or 0) + (r.get("outputTokens") or 0)
                   for r in rows)

    if initial or records:
        body["sizing"] = {
            "trips": initial,
            "reevaluations": reevaluations,
            "recordAssessments": records,
            "requestsPerTrip": round((initial + reevaluations) / initial, 2) if initial else None,
            "modelCallsPerTrip": round(order_model_calls / initial, 2) if initial else None,
            "meanTokensPerTrip": int(_tokens(order_rows) / initial) if initial else None,
            "modelCallsPerRecord": round(record_model_calls / records, 2) if records else None,
            "meanTokensPerRecord": int(_tokens(record_rows) / records) if records else None,
            "note": ("A trip that gets a clarifying question costs two requests. A "
                     "response that fails validation costs an extra model call inside "
                     "one request. Size the quota on modelCallsPerTrip, not on trips. "
                     "Record assessments are counted separately: they are a "
                     "retrospective pass, not part of the order entry cost."),
        }
    return body


@app.post(
    "/v1/medical-necessity/evaluate",
    summary="Evaluate a trip request on submission",
    description=(
        "Returns a clinical summary, a medical necessity flag and a clarifying "
        "question. `clarifyingQuestion` is null when nothing needs asking, which is "
        "the signal to show nothing and let the submission continue.\n\n"
        "Populating `clarifyingQuestion` and `clarifyingAnswer` on the payload routes "
        "to a re-evaluation, as an alternative to the `/reevaluate` endpoint."
    ),
)
def evaluate(
    trip: Dict[str, Any],
    delayMs: Optional[int] = Query(None, description="Artificial delay, for timeout testing."),
) -> JSONResponse:
    delay = DEFAULT_DELAY_MS if delayMs is None else max(0, delayMs)

    supplied_question = trip.get("clarifyingQuestion")
    supplied_answer = trip.get("clarifyingAnswer")
    call_type = "reevaluation" if (supplied_question and supplied_answer) else "initial"

    clarification = None
    if call_type == "reevaluation":
        clarification = {"question": supplied_question, "answer": supplied_answer}

    return evaluate_payload(trip, call_type, clarification, delay)


@app.post(
    "/v1/medical-necessity/evaluate-epcr",
    summary="Assess a completed patient care record",
    description=(
        "Retrospective. The transport has happened; the question is whether the record "
        "a biller would read supports a claim.\n\n"
        "Send `row` as a parsed object, or `csv` as raw text and the service parses it. "
        "With several rows, `tripRequestId` picks one.\n\n"
        "Only the columns listed in `prompts/epcr_fields.json` reach the model. Payment "
        "method and insurance are withheld on purpose."
    ),
)
def evaluate_epcr_endpoint(request: EpcrRequest) -> JSONResponse:
    received_at = utc_now()
    started = time.perf_counter()

    if llm is None:
        return model_unavailable(
            LLM_IMPORT_ERROR or "llm.py is not importable",
            "pip install -r requirements.txt", received_at, started)

    row = request.row
    if row is None:
        if not request.csv:
            return JSONResponse(status_code=422, content={
                "error": "no_record",
                "message": "Send either row or csv.",
                "action": "Submit the trip unchanged."})
        try:
            import io
            import pandas as pd
            frame = pd.read_csv(io.StringIO(request.csv), dtype=str).fillna("")
        except Exception as exc:
            return JSONResponse(status_code=422, content={
                "error": "unparseable_csv",
                "message": "That file could not be read as CSV.",
                "detail": f"{type(exc).__name__}: {exc}"[:300],
                "action": "Submit the trip unchanged."})
        if not len(frame):
            return JSONResponse(status_code=422, content={
                "error": "empty_csv", "message": "The file has no rows.",
                "action": "Submit the trip unchanged."})

        key = llm.get_epcr_spec().get("key_column")
        if request.tripRequestId and key in frame.columns:
            match = frame[frame[key].astype(str).str.strip() == str(request.tripRequestId).strip()]
            if not len(match):
                return JSONResponse(status_code=422, content={
                    "error": "trip_not_in_record",
                    "message": f"No row with {key} = {request.tripRequestId}.",
                    "detail": f"The file carries {len(frame)} row(s).",
                    "action": "Submit the trip unchanged."})
            row = match.iloc[0].to_dict()
        else:
            row = frame.iloc[0].to_dict()

    try:
        block = llm.evaluate_epcr(row)
    except Exception as exc:
        return model_unavailable(f"{type(exc).__name__}: {exc}"[:600],
                                 llm.diagnose(exc), received_at, started)

    processing_ms = int((time.perf_counter() - started) * 1000)
    detail = block.get("detail") or {}
    usage = detail.get("usage") or {}
    selection = detail.get("selection") or {}

    body = {
        "evaluationId": str(uuid.uuid4()),
        "tripRequestId": selection.get("tripRequestId"),
        "assessment": "epcr",
        "clinicalSummary": block.get("clinicalSummary"),
        "meetsMedicalNecessity": block.get("meetsMedicalNecessity"),
        "documentationGaps": block.get("documentationGaps") or [],
        "detail": detail,
        "meta": {
            "service": SERVICE_NAME,
            "serviceVersion": SERVICE_VERSION,
            "engineVersion": llm.engine_version(),
            "knowledgeVersion": KNOWLEDGE_VERSION,
            "fieldsVersion": selection.get("fieldsVersion"),
            "inference": "foundry-model",
            "epcrMatched": selection.get("epcrMatched"),
            "fieldsPopulated": selection.get("populated"),
            "fieldsOffered": selection.get("offered"),
            "fieldsWithheld": selection.get("withheld"),
            "inputTokens": usage.get("inputTokens"),
            "outputTokens": usage.get("outputTokens"),
            "totalTokens": (usage.get("inputTokens") or 0) + (usage.get("outputTokens") or 0),
            "estimatedCostUsd": estimate_cost(usage.get("inputTokens"), usage.get("outputTokens")),
            "modelCalls": usage.get("modelCalls"),
            "receivedAtUtc": received_at,
            "respondedAtUtc": utc_now(),
            "processingMs": processing_ms,
            "modelMs": usage.get("modelMs"),
            "overheadMs": max(0, processing_ms - (usage.get("modelMs") or 0)),
        },
    }

    write_event({
        "evaluationId": body["evaluationId"],
        "sourceSystemTripId": body["tripRequestId"],
        "callType": "epcr",
        "inference": "foundry-model",
        "determination": detail.get("determination"),
        "meetsMedicalNecessity": body["meetsMedicalNecessity"],
        "documentationGaps": len(body["documentationGaps"]),
        "epcrMatched": selection.get("epcrMatched"),
        "fieldsPopulated": selection.get("populated"),
        "inputTokens": usage.get("inputTokens"),
        "outputTokens": usage.get("outputTokens"),
        "estimatedCostUsd": body["meta"]["estimatedCostUsd"],
        "modelCalls": usage.get("modelCalls"),
        "knowledgeVersion": KNOWLEDGE_VERSION,
        "receivedAtUtc": received_at,
        "respondedAtUtc": body["meta"]["respondedAtUtc"],
        "processingMs": processing_ms,
        "modelMs": usage.get("modelMs"),
    })

    return JSONResponse(status_code=200, content=body)


@app.post(
    "/v1/medical-necessity/reevaluate",
    summary="Re-evaluate after the requester answers",
    description=(
        "Called once the requester has answered the clarifying question. Returns the "
        "same shape with an updated summary and flag, and never asks again."
    ),
)
def reevaluate(
    request: ReevaluateRequest,
    delayMs: Optional[int] = Query(None, description="Artificial delay, for timeout testing."),
) -> JSONResponse:
    delay = DEFAULT_DELAY_MS if delayMs is None else max(0, delayMs)
    clarification = {
        "question": request.clarification.question,
        "answer": request.clarification.answer,
    }
    response = evaluate_payload(request.tripRequest, "reevaluation", clarification, delay)
    if response.status_code == 200:
        body = json.loads(response.body)
        body["clarification"] = clarification
        return JSONResponse(status_code=200, content=body)
    return response
