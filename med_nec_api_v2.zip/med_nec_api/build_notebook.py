import json
import sys

CELLS = [
("md", """# Medical necessity guidance — request and response demo

Walks one trip request through the guidance service and shows exactly what comes
back, in the order Transport.net would act on it.

**Start the service first.** From the project folder:

```
uvicorn app:app --reload --port 8000
```

There is no model inference in this build. The Foundry models are not deployed,
so each demo payload resolves to a pre-written response held in `responses/`.
What is real here is everything around the inference step: the contract, the two
call patterns, the timing, the event log and the timeout behaviour."""),

("md", "## 1. Configuration"),
("code", """import json
import time
from pathlib import Path

import httpx
import pandas as pd
from IPython.display import HTML, display

BASE_URL = "http://127.0.0.1:8000"
PROJECT = Path.cwd()
PAYLOAD_DIR = PROJECT / "payloads"
RESPONSE_DIR = PROJECT / "responses"

SUBMISSION_TIMEOUT_S = 3.0

pd.set_option("display.max_colwidth", 90)
pd.set_option("display.width", 200)

client = httpx.Client(base_url=BASE_URL, timeout=30.0)

print("project :", PROJECT)
print("service :", BASE_URL)
print("payloads:", len(list(PAYLOAD_DIR.glob("*.json"))))"""),

("md", """## 2. Is the service up

If this cell fails, the service is not running. Start it with
`uvicorn app:app --reload --port 8000` and run again.

`inference` is the field to watch. While it reads `static-fixture` nothing is
being reasoned about and every answer is pre-written."""),
("code", """health = client.get("/healthz").json()

display(pd.DataFrame([health]).T.rename(columns={0: "value"}))

if health["inference"] == "static-fixture":
    print("\\nNo model inference in this build. Responses are pre-written per payload.")"""),

("md", """## 3. What the service can answer

Three demo payloads, each paired by filename to a stored response. These are the
expected outcomes before anything is sent."""),
("code", """fixtures = client.get("/v1/fixtures").json()["fixtures"]

catalog = pd.DataFrame([
    {
        "fixture": f["fixtureName"],
        "payload file": f["payloadFile"].replace("payloads/", ""),
        "meets on submit": f["initial"]["meetsMedicalNecessity"],
        "asks a question": f["initial"]["clarifyingQuestionReturned"],
        "meets after answer": f["afterClarification"]["meetsMedicalNecessity"],
    }
    for f in fixtures
])

display(catalog)"""),

("md", """## 4. The payload we are sending

Transport.net posts the whole trip request on submission. The clinical content
arrives two ways in the same payload: `clinicalData`, the flattened string, and
`losQuestions`, the structured question array."""),
("code", """PAYLOAD_NAME = "trip_2_general_weakness.json"

trip = json.loads((PAYLOAD_DIR / PAYLOAD_NAME).read_text())
leg = trip["tripLegs"][0]

print("olosRequestId   :", trip["olosRequestId"])
print("requester       :", trip["requesterFacility"])
print("level of service:", leg["levelOfService"])
print("trip reason     :", trip["tripReason"])
print("payload size    :", f"{len(json.dumps(trip)):,} characters")"""),

("md", """### The structured questions

This is what the model reads. Every answered question on the form, for one trip,
evaluated together rather than one at a time."""),
("code", """questions = pd.DataFrame([
    {
        "questionId": q["questionId"],
        "parent": q["parentQuestionId"],
        "question": q["questionText"],
        "answer": q["answer"],
        "free text": q["answerValue"],
    }
    for q in leg["losQuestions"]
])

display(questions)"""),

("md", """### The same content as the flattened string

The field the form writes today. Kept in the payload so the service can read
either source."""),
("code", """print(leg["clinicalData"])"""),

("md", """## 5. Send it

One POST on trip submission. Transport.net waits for this before writing the
trip."""),
("code", """started = time.perf_counter()
response = client.post("/v1/medical-necessity/evaluate", json=trip)
elapsed_ms = int((time.perf_counter() - started) * 1000)

body = response.json()

print("HTTP", response.status_code)
print("round trip   :", elapsed_ms, "ms")
print("service time :", body["meta"]["processingMs"], "ms")
print("answered from:", body["meta"]["fixtureResponseFile"])
print("matched on   :", body["meta"]["fixtureMatchedOn"])"""),

("md", """## 6. What Transport.net acts on

Three fields. The rest of the response is detail for the database.

`clarifyingQuestion` is the switch: null means show the requester nothing and
submit the trip as normal. Populated means open the modal."""),
("code", """def show_three_fields(payload):
    meets = payload["meetsMedicalNecessity"]
    question = payload["clarifyingQuestion"]
    summary = payload["clinicalSummary"]

    flag_text = {True: "Meets criteria", False: "Does not meet criteria", None: "No determination"}[meets]
    flag_bg = {True: "#e8f0e8", False: "#f4ecec", None: "#efefef"}[meets]
    action = "Modal opens, requester is asked one question" if question else "Nothing shown, trip submits as normal"

    rows = [
        ("meetsMedicalNecessity", f"<b>{meets}</b> &nbsp; {flag_text}"),
        ("clarifyingQuestion", f"<i>null</i>" if not question else question),
        ("clinicalSummary", summary or "<i>null</i>"),
    ]
    html = [
        f'<div style="font-family:Calibri,Segoe UI,sans-serif;font-size:14px;'
        f'border:1px solid #999;background:{flag_bg};padding:14px;max-width:900px">'
    ]
    for label, value in rows:
        html.append(
            f'<div style="margin-bottom:10px">'
            f'<div style="font-size:11px;color:#555;text-transform:uppercase;'
            f'letter-spacing:.5px">{label}</div>'
            f'<div style="margin-top:2px">{value}</div></div>'
        )
    html.append(
        f'<div style="border-top:1px solid #bbb;margin-top:6px;padding-top:8px;'
        f'font-size:12px;color:#444">User experience &nbsp;&rarr;&nbsp; {action}</div></div>'
    )
    display(HTML("".join(html)))


show_three_fields(body)"""),

("md", """### What the requester would see

The modal only appears when a question comes back. One question, one free text
box, then the trip submits."""),
("code", """def show_modal(question):
    if not question:
        display(HTML(
            '<div style="font-family:Calibri,Segoe UI,sans-serif;font-size:13px;'
            'color:#555;border:1px dashed #bbb;padding:12px;max-width:760px">'
            'No question returned. The requester sees nothing and the trip submits '
            'as it always has.</div>'
        ))
        return
    display(HTML(
        '<div style="font-family:Calibri,Segoe UI,sans-serif;border:1px solid #888;'
        'max-width:760px;box-shadow:2px 2px 6px rgba(0,0,0,.15)">'
        '<div style="background:#4A6274;color:#fff;padding:10px 14px;font-size:14px;'
        'font-weight:bold">One more question before we submit</div>'
        f'<div style="padding:16px 14px;font-size:14px">{question}'
        '<div style="margin-top:12px;border:1px solid #aaa;background:#fff;'
        'padding:10px;color:#999;font-size:13px">Type your answer here</div>'
        '<div style="margin-top:14px;text-align:right">'
        '<span style="border:1px solid #888;padding:6px 18px;font-size:13px;'
        'background:#eee">Submit trip</span></div></div></div>'
    ))


show_modal(body["clarifyingQuestion"])"""),

("md", """## 7. What is stored but not displayed

Every question and answer pair, with the category, the criterion it rests on,
the citation and a confidence level. This is the part worth logging and
analysing at scale rather than showing to a requester."""),
("code", """findings = pd.DataFrame(body["detail"]["questionFindings"])

if len(findings):
    view = findings[[
        "questionId", "question", "answer", "nonMedNec",
        "category", "criterionId", "confidence",
    ]].copy()
    view["question"] = view["question"].str.slice(0, 60)
    view["answer"] = view["answer"].str.slice(0, 50)
    display(view)
else:
    print("no per question findings on this response")"""),

("md", """### Why the trip landed where it did"""),
("code", """detail = body["detail"]

print("determination :", detail["determination"])
print("basis         :", detail["basis"])
print("gate satisfied:", detail["gateSatisfied"])
print("confidence    :", detail["confidence"])

if detail["exclusionsTriggered"]:
    print()
    print("Non covered situations found")
    display(pd.DataFrame(detail["exclusionsTriggered"]))

if detail["criteriaDocumented"]:
    print()
    print("Criteria documented")
    display(pd.DataFrame(detail["criteriaDocumented"]))"""),

("md", """## 8. The requester answers, and we ask again

The second call in the workflow. The original payload goes back with the
question that was asked and the answer that was typed."""),
("code", """ANSWER = (
    "Patient had a stroke last week with dense left sided weakness and poor trunk "
    "control. She slides out of a chair without support."
)

if body["clarifyingQuestion"]:
    follow = client.post("/v1/medical-necessity/reevaluate", json={
        "tripRequest": trip,
        "clarification": {"question": body["clarifyingQuestion"], "answer": ANSWER},
    }).json()

    print("requester typed:")
    print(" ", ANSWER)
    print()
    print("answered from  :", follow["meta"]["fixtureResponseFile"])
    print()
    show_three_fields(follow)
else:
    follow = None
    print("No question was returned on this trip, so there is no second call.")"""),

("md", """### Before and after"""),
("code", """if follow:
    display(pd.DataFrame([
        {
            "call": "on submission",
            "meets": body["meetsMedicalNecessity"],
            "question returned": bool(body["clarifyingQuestion"]),
            "summary": body["clinicalSummary"][:110] + "...",
        },
        {
            "call": "after the answer",
            "meets": follow["meetsMedicalNecessity"],
            "question returned": bool(follow["clarifyingQuestion"]),
            "summary": follow["clinicalSummary"][:110] + "...",
        },
    ]))"""),

("md", """## 9. All three payloads

The full matrix: the trip that passes silently, the one a clarification rescues,
and the one it does not."""),
("code", """FOLLOWUP_ANSWERS = {
    "trip_2_general_weakness": ANSWER,
    "trip_3_wheelchair_candidate": "Facility prefers stretcher transport.",
}

rows = []
for path in sorted(PAYLOAD_DIR.glob("*.json")):
    sample = json.loads(path.read_text())
    first = client.post("/v1/medical-necessity/evaluate", json=sample).json()
    name = first["meta"]["fixtureName"]

    record = {
        "payload": path.name,
        "meets on submit": first["meetsMedicalNecessity"],
        "question asked": bool(first["clarifyingQuestion"]),
        "meets after answer": None,
        "service ms": first["meta"]["processingMs"],
    }

    if first["clarifyingQuestion"]:
        second = client.post("/v1/medical-necessity/reevaluate", json={
            "tripRequest": sample,
            "clarification": {
                "question": first["clarifyingQuestion"],
                "answer": FOLLOWUP_ANSWERS.get(name, "No further information."),
            },
        }).json()
        record["meets after answer"] = second["meetsMedicalNecessity"]

    rows.append(record)

display(pd.DataFrame(rows))"""),

("md", """### The questions each trip would be asked"""),
("code", """asks = []
for path in sorted(PAYLOAD_DIR.glob("*.json")):
    sample = json.loads(path.read_text())
    result = client.post("/v1/medical-necessity/evaluate", json=sample).json()
    asks.append({
        "payload": path.name.replace(".json", ""),
        "clarifying question": result["clarifyingQuestion"] or "(none, trip submits silently)",
    })

display(pd.DataFrame(asks).style.set_properties(**{"white-space": "pre-wrap", "text-align": "left"}))"""),

("md", """## 10. Latency and the submission timeout

Transport.net holds the submission while this call is in flight, so it needs a
ceiling. Two to five seconds was the working number.

The first call below returns inside the timeout. The second is deliberately
slower than it, and shows the path where Transport.net gives up and submits the
trip unchanged."""),
("code", """fast = client.post("/v1/medical-necessity/evaluate", json=trip, params={"delayMs": 400})
print("inside the timeout :", fast.json()["meta"]["processingMs"], "ms, HTTP", fast.status_code)

try:
    client.post(
        "/v1/medical-necessity/evaluate",
        json=trip,
        params={"delayMs": 5000},
        timeout=SUBMISSION_TIMEOUT_S,
    )
    print("past the timeout   : returned unexpectedly")
except httpx.ReadTimeout:
    print(f"past the timeout   : ReadTimeout after {SUBMISSION_TIMEOUT_S}s")
    print()
    print("Transport.net proceeds with submission, no guidance on this trip.")"""),

("md", """## 11. An unmatched payload

This build answers for three known payloads. Anything else comes back 422 with
all three fields null, rather than a default that would be indistinguishable
from a real determination during a demo."""),
("code", """other = json.loads((PAYLOAD_DIR / "trip_1_meets.json").read_text())
other["olosRequestId"] = "00000000-0000-0000-0000-000000000000"
other["tripLegs"][0]["losQuestions"] = []
other["tripLegs"][0]["clinicalData"] = "Something this build has no fixture for."

unmatched = client.post("/v1/medical-necessity/evaluate", json=other)
payload = unmatched.json()

print("HTTP", unmatched.status_code)
print("determination:", payload["detail"]["determination"])
print()
show_three_fields(payload)"""),

("md", """## 12. The event log

Every call appends a row. This stands in for the `request_event_logs` table on
the Transport.net side, and carries the timing fields needed to size the compute
and set the timeout."""),
("code", """log_path = PROJECT / "request_event_log.jsonl"

if log_path.exists():
    events = pd.DataFrame([json.loads(line) for line in log_path.read_text().splitlines() if line.strip()])
    view = events[[
        "receivedAtUtc", "callType", "fixtureName",
        "meetsMedicalNecessity", "clarifyingQuestionReturned", "processingMs",
    ]]
    display(view.tail(12))
    print()
    print("calls logged:", len(events))
    print("median service time:", int(events["processingMs"].median()), "ms")
else:
    print("no event log yet")"""),

("md", """## 13. What this demo does and does not show

Shown, and real:

- the request and response contract Transport.net will integrate against
- the three fields the UI acts on, and the null question as the signal to stay silent
- both call patterns, on submission and after the clarifying answer
- the per question detail that goes to the database rather than the screen
- timing fields, the event log, and the timeout path

Not shown, because it is not built:

- any model inference. Every response here was written by hand and stored in
  `responses/`, keyed to one payload
- the determinations themselves. Whether a given trip meets criteria is the
  question the Foundry models will answer, and accuracy cannot be measured until
  denial history is joined

When the models are deployed, only the resolution step inside the service
changes. This notebook, the contract and the Transport.net integration stay as
they are, and the files in `responses/` become the first regression tests."""),
]


def to_source(text):
    lines = text.split("\n")
    return [l + "\n" for l in lines[:-1]] + [lines[-1]]


nb = {
    "cells": [],
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.11"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}

for kind, text in CELLS:
    cid = f"cell{len(nb['cells']):02d}"
    if kind == "md":
        nb["cells"].append({"cell_type": "markdown", "id": cid, "metadata": {},
                            "source": to_source(text)})
    else:
        nb["cells"].append({"cell_type": "code", "id": cid, "execution_count": None,
                            "metadata": {}, "outputs": [], "source": to_source(text)})

with open(sys.argv[1], "w") as f:
    json.dump(nb, f, indent=1)

code_cells = [c for c in nb["cells"] if c["cell_type"] == "code"]
flat = "\n\n".join("".join(c["source"]) for c in code_cells)
comments = sum(1 for line in flat.split("\n") if line.strip().startswith("#"))

print("cells:", len(nb["cells"]), "| code:", len(code_cells), "| comments:", comments)
