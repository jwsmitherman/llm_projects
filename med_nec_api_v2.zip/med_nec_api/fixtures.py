"""Loads the payload and response pairs from disk.

Until the Foundry models are deployed there is no inference. Each demo payload in
payloads/ is paired by filename with a pre-written response in responses/, and the
service returns that response verbatim.

    payloads/trip_2_general_weakness.json          what Transport.net sends
    responses/trip_2_general_weakness.initial.json       what comes back
    responses/trip_2_general_weakness.reevaluation.json  what comes back after
                                                         the clarifying answer

Adding a case means dropping three files in with a shared stem. Nothing in this
module or in app.py needs editing.
"""

import json
from pathlib import Path
from typing import Any, Dict

KNOWLEDGE_VERSION = "2026-09-02"
ENGINE_VERSION = "static-fixture-v1"

ROOT = Path(__file__).parent
PAYLOAD_DIR = ROOT / "payloads"
RESPONSE_DIR = ROOT / "responses"

REQUIRED_FIELDS = ("clinicalSummary", "meetsMedicalNecessity", "clarifyingQuestion", "detail")


def _read(path: Path) -> Dict[str, Any]:
    with path.open() as handle:
        return json.load(handle)


def _check_shape(path: Path, block: Dict[str, Any]) -> None:
    missing = [f for f in REQUIRED_FIELDS if f not in block]
    if missing:
        raise ValueError(f"{path.name} is missing required field(s): {', '.join(missing)}")


def load_fixtures() -> Dict[str, Dict[str, Any]]:
    fixtures: Dict[str, Dict[str, Any]] = {}
    if not PAYLOAD_DIR.is_dir():
        raise FileNotFoundError(f"payload directory not found: {PAYLOAD_DIR}")

    for payload_path in sorted(PAYLOAD_DIR.glob("*.json")):
        name = payload_path.stem
        trip = _read(payload_path)
        request_id = trip.get("olosRequestId")
        if not request_id:
            raise ValueError(f"{payload_path.name} has no olosRequestId")

        initial_path = RESPONSE_DIR / f"{name}.initial.json"
        reeval_path = RESPONSE_DIR / f"{name}.reevaluation.json"
        if not initial_path.exists():
            raise FileNotFoundError(
                f"{payload_path.name} has no paired response at responses/{initial_path.name}"
            )
        if not reeval_path.exists():
            raise FileNotFoundError(
                f"{payload_path.name} has no paired response at responses/{reeval_path.name}"
            )

        initial = _read(initial_path)
        reevaluation = _read(reeval_path)
        _check_shape(initial_path, initial)
        _check_shape(reeval_path, reevaluation)

        fixtures[request_id] = {
            "fixture_name": name,
            "payload_file": f"payloads/{payload_path.name}",
            "initial_file": f"responses/{initial_path.name}",
            "reevaluation_file": f"responses/{reeval_path.name}",
            "initial": initial,
            "reevaluation": reevaluation,
        }

    if not fixtures:
        raise ValueError(f"no payloads found in {PAYLOAD_DIR}")
    return fixtures


def load_unmatched() -> Dict[str, Any]:
    path = RESPONSE_DIR / "unmatched.json"
    if not path.exists():
        raise FileNotFoundError(f"missing {path}")
    block = _read(path)
    _check_shape(path, block)
    return {
        "fixture_name": "unmatched",
        "payload_file": None,
        "initial_file": "responses/unmatched.json",
        "reevaluation_file": "responses/unmatched.json",
        "initial": block,
        "reevaluation": block,
    }


FIXTURES = load_fixtures()
UNMATCHED = load_unmatched()
