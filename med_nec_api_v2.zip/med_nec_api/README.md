# Medical necessity guidance service — local demo build

Simulates the endpoint Transport.net will call on trip submission. Takes a trip
request payload and returns the three fields agreed in the MVP workflow meeting:
a clinical summary, a medical necessity flag, and a clarifying question when one
is needed.

**There is no model inference in this build.** The Foundry models are not
deployed, so each of the three demo payloads resolves to one fixed, pre-written
response. Everything around the inference step is real and exercisable: the
request and response contract, the two call patterns, the timing fields, the
event log, and the timeout behaviour.

## Run it

```bash
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```

Then either walk the notebook, which is the one to use in a meeting:

```
med_nec_api_demo.ipynb
```

or run the command line client in a second terminal:

```bash
python send.py --with-followup
```

Interactive docs at http://127.0.0.1:8000/docs

## The demo notebook

`med_nec_api_demo.ipynb` steps through one trip request and shows what comes back
at each point, in the order Transport.net would act on it:

1. confirms the service is up and which engine is answering
2. lists the payloads it can answer and the outcome each produces
3. opens one payload and shows the structured questions the model reads
4. posts it on submission and times the round trip
5. renders the three fields the UI consumes, and a mock of the modal the
   requester would see
6. shows the per question findings that go to the database rather than the screen
7. sends the clarifying answer and shows the determination change
8. runs all three payloads side by side
9. demonstrates the submission timeout and the unmatched payload
10. reads back the event log

It ships with its outputs saved, so it can be read without running anything.
Re-run it against a live service and the outputs refresh.

## Where the canned responses live

Each demo case is three files sharing one stem. The pairing is by filename, so
you can read exactly what comes back for a given payload without running
anything:

```
payloads/trip_2_general_weakness.json              what Transport.net sends
responses/trip_2_general_weakness.initial.json     what comes back
responses/trip_2_general_weakness.reevaluation.json  what comes back after the
                                                     clarifying answer
responses/unmatched.json                           returned when nothing matches
```

Editing a response is editing that JSON file. No Python involved. Adding a fourth
case means dropping in three files with a shared stem and restarting — nothing in
`app.py` or `fixtures.py` changes.

The loader fails on startup rather than at request time if a payload has no paired
response, or if a response is missing one of the four required top-level fields:

```
FileNotFoundError: trip_9_orphan.json has no paired response at
                   responses/trip_9_orphan.initial.json
ValueError: trip_1_meets.initial.json is missing required field(s): clarifyingQuestion
```

Every response also names its own source, so during a demo you can point at the
file that produced what you are looking at:

```json
"meta": {
  "fixturePayloadFile":  "payloads/trip_2_general_weakness.json",
  "fixtureResponseFile": "responses/trip_2_general_weakness.initial.json",
  "fixtureMatchedOn":    "olosRequestId"
}
```

## The three demo payloads

| Payload | Initial result | Clarifying question | After the answer |
|---|---|---|---|
| `trip_1_meets.json` | Meets | None | n/a |
| `trip_2_general_weakness.json` | Does not meet | Why can't the patient sit safely in a wheelchair? | Meets |
| `trip_3_wheelchair_candidate.json` | Does not meet | Is there a care need that makes a wheelchair van unsafe? | Still does not meet |

Together these cover the full matrix: the silent pass, the clarification that
rescues the trip, and the clarification that does not.

- **Trip 1** is ventilator dependent with bed confinement documented on all three
  elements. Nothing is shown to the requester and the trip submits as normal.
- **Trip 2** is Dave's example from the meeting. General weakness is the only
  reason given, which guidance names as insufficient on its own. The requester
  answers with a recent stroke and dense left sided weakness, and the trip flips
  to meets.
- **Trip 3** is Gary's example. The patient can sit safely in a wheelchair in
  motion, is on facility supplied oxygen at baseline, and the urgency is a
  dialysis chair time rather than a clinical reason. The clarifying answer adds
  nothing clinical, so it stays at does not meet.

## Endpoints

### `POST /v1/medical-necessity/evaluate`

Called on trip submission, before the trip is written. Body is the trip request
payload exactly as Transport.net already builds it.

```bash
curl -X POST http://127.0.0.1:8000/v1/medical-necessity/evaluate \
  -H "Content-Type: application/json" \
  -d @payloads/trip_2_general_weakness.json
```

Response:

```json
{
  "evaluationId": "9f2c...",
  "olosRequestId": "b2e71d55-2002-4a8f-8c47-3fe9d1b40c22",
  "callType": "initial",

  "clinicalSummary": "Patient discharged to a residence following a stay for deconditioning...",
  "meetsMedicalNecessity": false,
  "clarifyingQuestion": "General weakness on its own does not establish medical necessity. What about this patient's condition prevents them from sitting safely in a wheelchair while the vehicle is in motion?",

  "detail": { "...": "per question findings, criteria, citations, confidence" },
  "meta":   { "...": "timing, versions, which fixture answered" }
}
```

The three fields the UI acts on are at the top level. `clarifyingQuestion` is
`null` when no question is needed, which is the signal to show nothing and carry
on with submission.

`detail` carries the per question findings: category, criterion, citation,
evidence quote and confidence for every question and answer pair. That is the
part worth logging and analysing at scale, not displaying.

### `POST /v1/medical-necessity/reevaluate`

Called after the requester answers the clarifying question.

```json
{
  "tripRequest": { "...the original payload, unchanged..." },
  "clarification": {
    "question": "General weakness on its own does not establish...",
    "answer": "Patient had a stroke last week with dense left sided weakness."
  }
}
```

Returns the same shape with an updated summary and flag.

**Both integration patterns are supported**, because the meeting did not settle
which one to build. The separate endpoint above is one. The other is to add two
fields to the existing payload, null on the first call:

```json
{ "...trip request...", "clarifyingQuestion": "...", "clarifyingAnswer": "..." }
```

Posted to `/evaluate`, a populated pair routes to the re-evaluation response and
`callType` comes back as `reevaluation`. Pick whichever Transport.net prefers and
the other can be dropped.

### `GET /healthz`

Confirms the service is up and reports which engine is answering. While
`inference` reads `static-fixture`, nothing is being reasoned about.

### `GET /v1/fixtures`

Lists the loaded payloads and the result each one produces, so a demo can state
the expected outcome before posting.

## Latency and the submission timeout

Every response carries `meta.receivedAtUtc`, `meta.respondedAtUtc` and
`meta.processingMs`. Those are the structured timing fields Dave asked for.

The service adds an artificial delay so a call does not return instantly.
Default 350 ms, set with `SIMULATED_LATENCY_MS`, overridden per call with
`?delayMs=`:

```bash
SIMULATED_LATENCY_MS=800 uvicorn app:app --port 8000
curl -X POST "http://127.0.0.1:8000/v1/medical-necessity/evaluate?delayMs=4000" ...
```

To exercise the fallback path Transport.net needs, where the trip proceeds
unchanged because the service did not answer in time:

```bash
python send.py --timeout-demo
```

That posts with a 3 second client timeout against a 5 second server delay.

## Event log

Each call appends a line to `request_event_log.jsonl`: evaluation id, request id,
call type, which fixture answered, the flag, whether a question was returned, both
timestamps and the elapsed milliseconds. It stands in for the
`request_event_logs` table on the Transport.net side.

## How a payload is matched to a response

1. `olosRequestId`, when it matches a known demo payload.
2. A SHA-256 fingerprint of the clinical answers. Edit the requester, the dates or
   the identifiers and the payload still resolves, because only the clinical
   content is fingerprinted.
3. No match returns **HTTP 422** with all three fields `null` and a
   `determination` of `no_fixture`.

The 422 is deliberate. A payload this build has no answer for should be visibly
unanswered rather than quietly given a default, which would be indistinguishable
from a real determination during a demo. Post the real UAT sample and you get a
422, correctly, because it is a ROTOR air transport with no fixture behind it.

## What changes when Foundry is ready

Only the resolution step. Replace `resolve_fixture` in `app.py` with a model call
that compiles the criteria file into the instruction and returns the same three
fields. The contract, the envelope, the event log, the timing fields and both
call patterns stay as they are, so the Transport.net integration does not change.

The files in `responses/` keep their value after that. They are the expected
output for a known input, which makes them the first regression tests against the
live model.

## Files

```
app.py                                        the service
fixtures.py                                   loads and pairs the files below
med_nec_api_demo.ipynb                        the walkthrough notebook
payloads/
  trip_1_meets.json                           incoming trip requests
  trip_2_general_weakness.json
  trip_3_wheelchair_candidate.json
responses/
  trip_1_meets.initial.json                   the paired canned responses
  trip_1_meets.reevaluation.json
  trip_2_general_weakness.initial.json
  trip_2_general_weakness.reevaluation.json
  trip_3_wheelchair_candidate.initial.json
  trip_3_wheelchair_candidate.reevaluation.json
  unmatched.json
send.py                                       command line demo client
build_notebook.py                             regenerates the notebook
requirements.txt
```
