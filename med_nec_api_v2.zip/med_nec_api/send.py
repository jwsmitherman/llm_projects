"""Demo client. Posts each payload and prints what Transport.net would act on.

    python send.py                 all three payloads, initial call only
    python send.py --with-followup all three, plus the clarifying answer round trip
    python send.py --payload payloads/trip_2_general_weakness.json
    python send.py --timeout-demo  one call slower than the submission timeout
"""

import argparse
import json
import sys
from pathlib import Path

import httpx

BASE_URL = "http://127.0.0.1:8000"
SUBMISSION_TIMEOUT_S = 3.0

FOLLOWUP_ANSWERS = {
    "trip_1_meets": None,
    "trip_2_general_weakness": (
        "Patient had a stroke last week with dense left sided weakness and poor trunk "
        "control. She slides out of a chair without support."
    ),
    "trip_3_wheelchair_candidate": "Facility prefers stretcher transport.",
}

RULE = "=" * 78


def show(title, body):
    print(RULE)
    print(title)
    print(RULE)
    meta = body.get("meta", {})
    print(f"  fixture            {meta.get('fixtureName')}  (matched on {meta.get('fixtureMatchedOn')})")
    print(f"  call type          {meta.get('callType') or body.get('callType')}")
    print(f"  questions read     {meta.get('questionsEvaluated')}")
    print(f"  processing         {meta.get('processingMs')} ms")
    print()
    print("  --- the three fields Transport.net consumes ---")
    print(f"  meetsMedicalNecessity : {body.get('meetsMedicalNecessity')}")
    question = body.get("clarifyingQuestion")
    if question:
        print(f"  clarifyingQuestion    : {question}")
        print("                          -> UI shows the modal")
    else:
        print("  clarifyingQuestion    : null")
        print("                          -> UI shows nothing, trip submits as normal")
    summary = body.get("clinicalSummary")
    print("  clinicalSummary       :")
    if summary:
        words, line = summary.split(), "   "
        for word in words:
            if len(line) + len(word) + 1 > 76:
                print(line)
                line = "   "
            line += (" " if line.strip() else "") + word
        if line.strip():
            print(line)
    else:
        print("    null")

    detail = body.get("detail") or {}
    findings = detail.get("questionFindings") or []
    if findings:
        print()
        print("  --- per question, stored not displayed ---")
        for item in findings:
            flag = "FLAG" if item.get("nonMedNec") else "    "
            print(f"  [{flag}] q{item.get('questionId')}  {item.get('category'):<19} "
                  f"{item.get('confidence'):<7} {item.get('criterionId') or '-'}")
    exclusions = detail.get("exclusionsTriggered") or []
    if exclusions:
        print()
        print("  --- non covered situations found ---")
        for item in exclusions:
            print(f"  - {item.get('exclusionId')}  ({item.get('citation')})")
    print()


def post(client, path, body, timeout, params=None):
    return client.post(f"{BASE_URL}{path}", json=body, params=params or {}, timeout=timeout)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload")
    parser.add_argument("--with-followup", action="store_true")
    parser.add_argument("--timeout-demo", action="store_true")
    args = parser.parse_args()

    here = Path(__file__).parent
    paths = [here / args.payload] if args.payload else sorted((here / "payloads").glob("*.json"))

    with httpx.Client() as client:
        try:
            health = client.get(f"{BASE_URL}/healthz", timeout=5.0).json()
        except Exception as exc:
            print(f"Cannot reach {BASE_URL}. Start the service first:\n"
                  f"  uvicorn app:app --reload --port 8000\n\n{exc}")
            return 1
        print(f"service up: {health['service']} {health['serviceVersion']}  "
              f"inference={health['inference']}  knowledge={health['knowledgeVersion']}")
        print()

        if args.timeout_demo:
            trip = json.loads(paths[0].read_text())
            print(f"Posting with a {SUBMISSION_TIMEOUT_S}s client timeout and a 5000 ms server delay.")
            print("Transport.net treats this as a miss and submits the trip unchanged.")
            print()
            try:
                post(client, "/v1/medical-necessity/evaluate", trip,
                     SUBMISSION_TIMEOUT_S, {"delayMs": 5000})
                print("  unexpected: the call returned inside the timeout")
            except httpx.ReadTimeout:
                print(f"  httpx.ReadTimeout after {SUBMISSION_TIMEOUT_S}s, as designed")
            return 0

        for path in paths:
            trip = json.loads(path.read_text())
            response = post(client, "/v1/medical-necessity/evaluate", trip, 30.0)
            body = response.json()
            show(f"{path.name}   HTTP {response.status_code}   INITIAL", body)

            if not args.with_followup:
                continue
            question = body.get("clarifyingQuestion")
            if not question:
                continue
            fixture_name = (body.get("meta") or {}).get("fixtureName")
            answer = FOLLOWUP_ANSWERS.get(fixture_name) or "No further information."
            print(f"  requester types: {answer}")
            print()
            follow = post(client, "/v1/medical-necessity/reevaluate", {
                "tripRequest": trip,
                "clarification": {"question": question, "answer": answer},
            }, 30.0)
            show(f"{path.name}   HTTP {follow.status_code}   AFTER CLARIFICATION", follow.json())

    return 0


if __name__ == "__main__":
    sys.exit(main())
