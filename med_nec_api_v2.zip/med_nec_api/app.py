"""Medical necessity guidance service, local demo build.

Transport.net posts the trip request on submission and receives three things back:
a clinical summary, a flag for whether the trip meets medical necessity, and a
clarifying question when one is needed.

This build contains no model inference. The Foundry models are not deployed yet,
so each of the three demo payloads resolves to one fixed, pre-written response.
Everything around the inference step is real: the contract, the validation, the
timing fields, the event log and the two call patterns.
"""

import hashlib
import json
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from fixtures import ENGINE_VERSION, FIXTURES, KNOWLEDGE_VERSION, UNMATCHED

SERVICE_NAME = "med-nec-guidance"
SERVICE_VERSION = "0.1.0-local"
DEFAULT_DELAY_MS = int(os.environ.get("SIMULATED_LATENCY_MS", "350"))
EVENT_LOG_PATH = Path(os.environ.get("EVENT_LOG_PATH", "request_event_log.jsonl"))

app = FastAPI(
    title="Medical necessity guidance service",
    description=(
        "Local demo build. Returns pre-written responses for three known payloads. "
        "No model inference until the Foundry deployment lands."
    ),
    version=SERVICE_VERSION,
)

FINGERPRINT_INDEX: Dict[str, str] = {}


class Clarification(BaseModel):
    question: str = Field(..., description="The clarifying question that was presented to the requester.")
    answer: str = Field(..., description="Free text the requester typed in response.")


class ReevaluateRequest(BaseModel):
    tripRequest: Dict[str, Any] = Field(..., description="The original trip request payload, unchanged.")
    clarification: Clarification


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def first_leg(trip: Dict[str, Any]) -> Dict[str, Any]:
    legs = trip.get("tripLegs") or []
    return legs[0] if legs else {}


def clinical_fingerprint(trip: Dict[str, Any]) -> str:
    leg = first_leg(trip)
    questions = leg.get("losQuestions") or []
    if questions:
        parts = []
        for q in questions:
            if not isinstance(q, dict):
                continue
            parts.append(
                "|".join(
                    str(q.get(k) or "").strip().lower()
                    for k in ("questionId", "questionText", "answer", "answerValue")
                )
            )
        basis = "\n".join(sorted(parts))
    else:
        basis = " ".join(str(leg.get("clinicalData") or "").split()).lower()
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


def build_fingerprint_index() -> None:
    payload_dir = Path(__file__).parent / "payloads"
    if not payload_dir.is_dir():
        return
    for path in sorted(payload_dir.glob("*.json")):
        try:
            trip = json.loads(path.read_text())
        except Exception:
            continue
        request_id = trip.get("olosRequestId")
        if request_id in FIXTURES:
            FINGERPRINT_INDEX[clinical_fingerprint(trip)] = request_id


def resolve_fixture(trip: Dict[str, Any]) -> tuple[Dict[str, Any], str]:
    request_id = trip.get("olosRequestId")
    if request_id and request_id in FIXTURES:
        return FIXTURES[request_id], "olosRequestId"
    matched = FINGERPRINT_INDEX.get(clinical_fingerprint(trip))
    if matched:
        return FIXTURES[matched], "clinicalFingerprint"
    return UNMATCHED, "none"


def question_count(trip: Dict[str, Any]) -> int:
    leg = first_leg(trip)
    questions = leg.get("losQuestions") or []
    answered = [
        q for q in questions
        if isinstance(q, dict) and str(q.get("answer") or "").strip()
    ]
    return len(answered)


def write_event(event: Dict[str, Any]) -> None:
    try:
        with EVENT_LOG_PATH.open("a") as handle:
            handle.write(json.dumps(event) + "\n")
    except Exception:
        pass


def envelope(
    trip: Dict[str, Any],
    fixture: Dict[str, Any],
    call_type: str,
    match_method: str,
    received_at: str,
    started: float,
    delay_ms: int,
) -> Dict[str, Any]:
    fixture_block = fixture[call_type]
    fixture_name = fixture["fixture_name"]
    response_file = fixture[f"{call_type}_file"]
    leg = first_leg(trip)
    if delay_ms > 0:
        time.sleep(delay_ms / 1000.0)
    processing_ms = int((time.perf_counter() - started) * 1000)
    responded_at = utc_now()

    body = {
        "evaluationId": str(uuid.uuid4()),
        "olosRequestId": trip.get("olosRequestId"),
        "correlationId": trip.get("correlationId"),
        "sourceSystemTripId": trip.get("sourceSystemTripId"),
        "requesterFacilityId": trip.get("requesterFacilityId"),
        "levelOfService": leg.get("levelOfService"),
        "callType": call_type,

        "clinicalSummary": fixture_block.get("clinicalSummary"),
        "meetsMedicalNecessity": fixture_block.get("meetsMedicalNecessity"),
        "clarifyingQuestion": fixture_block.get("clarifyingQuestion"),

        "detail": fixture_block.get("detail"),

        "meta": {
            "service": SERVICE_NAME,
            "serviceVersion": SERVICE_VERSION,
            "engineVersion": ENGINE_VERSION,
            "knowledgeVersion": KNOWLEDGE_VERSION,
            "inference": "static-fixture",
            "fixtureName": fixture_name,
            "fixtureMatchedOn": match_method,
            "fixturePayloadFile": fixture["payload_file"],
            "fixtureResponseFile": response_file,
            "questionsEvaluated": question_count(trip),
            "receivedAtUtc": received_at,
            "respondedAtUtc": responded_at,
            "processingMs": processing_ms,
        },
    }

    write_event({
        "evaluationId": body["evaluationId"],
        "olosRequestId": body["olosRequestId"],
        "callType": call_type,
        "fixtureName": fixture_name,
        "fixtureResponseFile": response_file,
        "fixtureMatchedOn": match_method,
        "meetsMedicalNecessity": body["meetsMedicalNecessity"],
        "clarifyingQuestionReturned": bool(body["clarifyingQuestion"]),
        "receivedAtUtc": received_at,
        "respondedAtUtc": responded_at,
        "processingMs": processing_ms,
    })

    return body


@app.on_event("startup")
def startup() -> None:
    build_fingerprint_index()


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    return {
        "status": "ok",
        "service": SERVICE_NAME,
        "serviceVersion": SERVICE_VERSION,
        "engineVersion": ENGINE_VERSION,
        "knowledgeVersion": KNOWLEDGE_VERSION,
        "inference": "static-fixture",
        "fixturesLoaded": len(FIXTURES),
        "defaultSimulatedLatencyMs": DEFAULT_DELAY_MS,
        "timeUtc": utc_now(),
    }


@app.get("/v1/fixtures")
def list_fixtures() -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    for request_id, fixture in FIXTURES.items():
        initial = fixture["initial"]
        reeval = fixture["reevaluation"]
        rows.append({
            "fixtureName": fixture["fixture_name"],
            "olosRequestId": request_id,
            "payloadFile": fixture["payload_file"],
            "initial": {
                "responseFile": fixture["initial_file"],
                "meetsMedicalNecessity": initial["meetsMedicalNecessity"],
                "clarifyingQuestionReturned": bool(initial["clarifyingQuestion"]),
            },
            "afterClarification": {
                "responseFile": fixture["reevaluation_file"],
                "meetsMedicalNecessity": reeval["meetsMedicalNecessity"],
            },
        })
    return {"count": len(rows), "fixtures": rows}


@app.post("/v1/medical-necessity/evaluate")
def evaluate(
    trip: Dict[str, Any],
    delayMs: Optional[int] = Query(None, description="Override the simulated latency for this call."),
) -> JSONResponse:
    received_at = utc_now()
    started = time.perf_counter()
    delay = DEFAULT_DELAY_MS if delayMs is None else max(0, delayMs)

    fixture, match_method = resolve_fixture(trip)

    supplied_question = trip.get("clarifyingQuestion")
    supplied_answer = trip.get("clarifyingAnswer")
    call_type = "reevaluation" if (supplied_question and supplied_answer) else "initial"

    body = envelope(trip, fixture, call_type, match_method, received_at, started, delay)
    status = 200 if match_method != "none" else 422
    return JSONResponse(status_code=status, content=body)


@app.post("/v1/medical-necessity/reevaluate")
def reevaluate(
    request: ReevaluateRequest,
    delayMs: Optional[int] = Query(None, description="Override the simulated latency for this call."),
) -> JSONResponse:
    received_at = utc_now()
    started = time.perf_counter()
    delay = DEFAULT_DELAY_MS if delayMs is None else max(0, delayMs)

    trip = request.tripRequest
    fixture, match_method = resolve_fixture(trip)

    body = envelope(trip, fixture, "reevaluation", match_method, received_at, started, delay)
    body["clarification"] = {
        "question": request.clarification.question,
        "answer": request.clarification.answer,
    }
    status = 200 if match_method != "none" else 422
    return JSONResponse(status_code=status, content=body)
