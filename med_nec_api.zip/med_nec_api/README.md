# Medical necessity guidance service

The endpoint Transport.net calls on trip submission. Takes a trip request payload
and returns the three fields agreed in the MVP workflow meeting: a clinical
summary, a medical necessity flag, and a clarifying question when one is needed.

**Two engines sit behind one contract.**

| | `USE_MODEL` unset | `USE_MODEL=true` |
|---|---|---|
| Who answers | pre-written files in `responses/` | the Claude deployment in Azure AI Foundry |
| Payloads it handles | the three demo trips only | any trip |
| Cost | none | tokens per call |
| `meta.inference` | `static-fixture` | `foundry-model` |

The envelope, the event log, the timing fields and both call patterns are
identical either way, so the Transport.net integration does not know or care
which engine answered.

## Install

```powershell
py -m venv C:\venvs\mednec
C:\venvs\mednec\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Two Windows notes. Use `py`, not `python`, to create the venv — Windows ships a
stub `python.exe` that only advertises the Microsoft Store and will shadow a real
install. And keep the venv outside OneDrive, as above: it is tens of thousands of
small files, and syncing them both floods OneDrive and intermittently locks files
mid-install. The project folder itself is fine in OneDrive.

## Run it on the model

Settings live in `.env`, already filled in with the DEV resource provisioned under
RITM0669421:

```
CLAUDE_BASE_URL=https://aif-app-tmp-cus-dev.cognitiveservices.azure.com/anthropic
CLAUDE_DEPLOYMENT_NAME=claude-sonnet-5-5
USE_MODEL=true
```

### Why that hostname and not the one in the portal

The Foundry portal shows `aif-app-tmp-cus-dev.services.ai.azure.com`. From a GMR
workstation that hostname is unusable: TCP 443 connects and the TLS handshake is
then reset (WinError 10054). It is reset by hostname, not by address — other
names pointed at the same IP, including `centralus.api.cognitive.microsoft.com`,
handshake normally. Azure cannot make that distinction, because the hostname
travels inside the handshake being rejected, so the decision is being made by
GMR's egress filter. `*.services.ai.azure.com` is almost certainly caught by a
generative-AI URL category rule.

`aif-app-tmp-cus-dev.cognitiveservices.azure.com` is an alias for the same
resource, serving the same deployments, and is not in that category. Confirmed
working on 2026-10-21.

Treat it as a workaround. The App Service subnet will meet the same policy at
deploy time, and a pilot should not rest on an alias that happens not to be
categorised yet. The egress rule to ask for:

> Allow outbound 443 to `*.services.ai.azure.com`, for the developer workstation
> now and the App Service subnet at deploy. `aif-app-tmp-cus-dev` is an Azure AI
> Foundry resource inside GMR's own tenant, provisioned under RITM0669421, not a
> third-party AI service.

`diagnose_tls.py`, `diagnose_sni.py` and `try_alt_endpoints.py` in this folder
reproduce the evidence if it is challenged.

Both `app.py` and `smoke_test.py` read it, so there is nothing to retype per
terminal. Prove the connection first — it separates a configuration problem from
a problem with the evaluation:

```powershell
az login
python smoke_test.py
```

One trivial call, and on failure it names the thing to check: 404 means the
deployment name is wrong, 401 or 403 means the identity has no role on the
resource, a connection error means the URL is wrong or egress is blocked.

Once that prints `Connection works`:

```powershell
python -m uvicorn app:app --reload --port 8000
```

### Settings

| Variable | Default | What it does |
|---|---|---|
| `USE_MODEL` | `false` | call the model instead of reading fixtures |
| `CLAUDE_BASE_URL` | — | must end in `/anthropic` |
| `CLAUDE_DEPLOYMENT_NAME` | — | the deployment name, not the model id |
| `AZURE_CLIENT_ID` | — | **App Service only.** Leave unset locally |
| `FALLBACK_TO_FIXTURE` | `true` | on a model error, answer from the fixture rather than failing |
| `CLAUDE_MAX_TOKENS` | `4000` | |
| `CLAUDE_TEMPERATURE` | `0` | |
| `SIMULATED_LATENCY_MS` | `350` | fixture padding; ignored when `USE_MODEL` is set |

`AZURE_CLIENT_ID` is commented out in `.env` on purpose. Locally the token comes
from your `az login` session; naming a managed identity client id gives
`DefaultAzureCredential` an identity to go looking for that does not exist on a
laptop. It belongs in App Service configuration. There are no keys in `.env`,
which is why it is safe to keep in the repo and in OneDrive — keys are disabled on
the Foundry resource deliberately.

Set `FALLBACK_TO_FIXTURE=false` when measuring accuracy. The safety net is right
for a demo and wrong for a measurement.

### Deployments available

Both live on `aif-app-tmp-cus-dev`, deployed as Data Zone Standard (US).

| Deployment name | Quota |
|---|---|
| `claude-sonnet-5-5` | 80K TPM |
| `claude-opus-5-5` | 40K TPM |

Sonnet is the default. This is classification against a fixed rubric, running
synchronously inside a trip submission where latency is the constraint, not an
open-ended reasoning task. Reach for Opus when Sonnet disagrees with the baseline
on trips whose criteria are clear — swapping is one line in `.env`, so the same
notebook can be run against both and compared.

On sizing: the compiled instruction is about 14,000 characters, so roughly 3,500
input tokens before the trip's answers are added. Call it 4,500 in and 800 out.
Against 80K TPM that is **roughly 15 trips a minute**, and a trip that gets a
clarifying question costs two calls. If peak volume exceeds that, the quota needs
raising before pilot.

## Run it on fixtures

Set `USE_MODEL=false` in `.env`, or delete the file.

Nothing is reasoned about and no tokens are spent. Use this to demo the contract,
or to fall back to if something goes wrong with the model mid-meeting.

## Notebooks

```
med_nec_live_test.ipynb    runs the three trips and checks the result
med_nec_api_demo.ipynb     the walkthrough for a meeting
```

`med_nec_live_test.ipynb` works against either engine. On fixtures it is a
contract test. With the model live it is the accuracy test, comparing every
determination against the files in `responses/` and printing the basis, criteria
and exclusions for each disagreement. Section 3 is the connectivity check to run
before a demo.

It ships with its outputs saved from a fixture run, so it can be read without
running anything. Every output says `static-fixture`, so there is no mistaking it
for a model result.

Or run the command line client in a second terminal:

```bash
python send.py --with-followup
```

Interactive docs at http://127.0.0.1:8000/docs

## The demo notebook

`med_nec_api_demo.ipynb` steps through one trip request and shows what comes back
at each point, in the order Transport.net would act on it:

1. confirms the service is up and which engine is answering
2. lists the payloads it can answer and the outcome each produces
3. opens one payload and shows the structured questions the model reads
4. posts it on submission and times the round trip
5. renders the three fields the UI consumes, and a mock of the modal the
   requester would see
6. shows the per question findings that go to the database rather than the screen
7. sends the clarifying answer and shows the determination change
8. runs all three payloads side by side
9. demonstrates the submission timeout and the unmatched payload
10. reads back the event log

It ships with its outputs saved, so it can be read without running anything.
Re-run it against a live service and the outputs refresh.

## Where the canned responses live

Each demo case is three files sharing one stem. The pairing is by filename, so
you can read exactly what comes back for a given payload without running
anything:

```
payloads/trip_2_general_weakness.json              what Transport.net sends
responses/trip_2_general_weakness.initial.json     what comes back
responses/trip_2_general_weakness.reevaluation.json  what comes back after the
                                                     clarifying answer
responses/unmatched.json                           returned when nothing matches
```

Editing a response is editing that JSON file. No Python involved. Adding a fourth
case means dropping in three files with a shared stem and restarting — nothing in
`app.py` or `fixtures.py` changes.

The loader fails on startup rather than at request time if a payload has no paired
response, or if a response is missing one of the four required top-level fields:

```
FileNotFoundError: trip_9_orphan.json has no paired response at
                   responses/trip_9_orphan.initial.json
ValueError: trip_1_meets.initial.json is missing required field(s): clarifyingQuestion
```

Every response also names its own source, so during a demo you can point at the
file that produced what you are looking at:

```json
"meta": {
  "fixturePayloadFile":  "payloads/trip_2_general_weakness.json",
  "fixtureResponseFile": "responses/trip_2_general_weakness.initial.json",
  "fixtureMatchedOn":    "olosRequestId"
}
```

## The three demo payloads

| Payload | Initial result | Clarifying question | After the answer |
|---|---|---|---|
| `trip_1_meets.json` | Meets | None | n/a |
| `trip_2_general_weakness.json` | Does not meet | Why can't the patient sit safely in a wheelchair? | Meets |
| `trip_3_wheelchair_candidate.json` | Does not meet | Is there a care need that makes a wheelchair van unsafe? | Still does not meet |

Together these cover the full matrix: the silent pass, the clarification that
rescues the trip, and the clarification that does not.

- **Trip 1** is ventilator dependent with bed confinement documented on all three
  elements. Nothing is shown to the requester and the trip submits as normal.
- **Trip 2** is Dave's example from the meeting. General weakness is the only
  reason given, which guidance names as insufficient on its own. The requester
  answers with a recent stroke and dense left sided weakness, and the trip flips
  to meets.
- **Trip 3** is Gary's example. The patient can sit safely in a wheelchair in
  motion, is on facility supplied oxygen at baseline, and the urgency is a
  dialysis chair time rather than a clinical reason. The clarifying answer adds
  nothing clinical, so it stays at does not meet.

## Endpoints

### `POST /v1/medical-necessity/evaluate`

Called on trip submission, before the trip is written. Body is the trip request
payload exactly as Transport.net already builds it.

```bash
curl -X POST http://127.0.0.1:8000/v1/medical-necessity/evaluate \
  -H "Content-Type: application/json" \
  -d @payloads/trip_2_general_weakness.json
```

Response:

```json
{
  "evaluationId": "9f2c...",
  "olosRequestId": "b2e71d55-2002-4a8f-8c47-3fe9d1b40c22",
  "callType": "initial",

  "clinicalSummary": "Patient discharged to a residence following a stay for deconditioning...",
  "meetsMedicalNecessity": false,
  "clarifyingQuestion": "General weakness on its own does not establish medical necessity. What about this patient's condition prevents them from sitting safely in a wheelchair while the vehicle is in motion?",

  "detail": { "...": "per question findings, criteria, citations, confidence" },
  "meta":   { "...": "timing, versions, which fixture answered" }
}
```

The three fields the UI acts on are at the top level. `clarifyingQuestion` is
`null` when no question is needed, which is the signal to show nothing and carry
on with submission.

`detail` carries the per question findings: category, criterion, citation,
evidence quote and confidence for every question and answer pair. That is the
part worth logging and analysing at scale, not displaying.

### `POST /v1/medical-necessity/reevaluate`

Called after the requester answers the clarifying question.

```json
{
  "tripRequest": { "...the original payload, unchanged..." },
  "clarification": {
    "question": "General weakness on its own does not establish...",
    "answer": "Patient had a stroke last week with dense left sided weakness."
  }
}
```

Returns the same shape with an updated summary and flag.

**Both integration patterns are supported**, because the meeting did not settle
which one to build. The separate endpoint above is one. The other is to add two
fields to the existing payload, null on the first call:

```json
{ "...trip request...", "clarifyingQuestion": "...", "clarifyingAnswer": "..." }
```

Posted to `/evaluate`, a populated pair routes to the re-evaluation response and
`callType` comes back as `reevaluation`. Pick whichever Transport.net prefers and
the other can be dropped.

### `GET /healthz`

Confirms the service is up and reports which engine is answering. While
`inference` reads `static-fixture`, nothing is being reasoned about.

### `GET /v1/engine`

Live connectivity probe. Makes one trivial model call and reports the settings it
is running with, the latency, and on failure the specific thing to go and check.
Run this before a demo.

### `GET /v1/fixtures`

Lists the loaded payloads and the result each one produces, so a demo can state
the expected outcome before posting.

## Latency and the submission timeout

Every response carries `meta.receivedAtUtc`, `meta.respondedAtUtc` and
`meta.processingMs`. Those are the structured timing fields Dave asked for.

The service adds an artificial delay so a call does not return instantly.
Default 350 ms, set with `SIMULATED_LATENCY_MS`, overridden per call with
`?delayMs=`:

```bash
SIMULATED_LATENCY_MS=800 uvicorn app:app --port 8000
curl -X POST "http://127.0.0.1:8000/v1/medical-necessity/evaluate?delayMs=4000" ...
```

To exercise the fallback path Transport.net needs, where the trip proceeds
unchanged because the service did not answer in time:

```bash
python send.py --timeout-demo
```

That posts with a 3 second client timeout against a 5 second server delay.

## Event log

Each call appends a line to `request_event_log.jsonl`: evaluation id, request id,
call type, which fixture answered, the flag, whether a question was returned, both
timestamps and the elapsed milliseconds. It stands in for the
`request_event_logs` table on the Transport.net side.

## How a payload is matched to a response

1. `olosRequestId`, when it matches a known demo payload.
2. A SHA-256 fingerprint of the clinical answers. Edit the requester, the dates or
   the identifiers and the payload still resolves, because only the clinical
   content is fingerprinted.
3. No match returns **HTTP 422** with all three fields `null` and a
   `determination` of `no_fixture`.

The 422 is deliberate. A payload this build has no answer for should be visibly
unanswered rather than quietly given a default, which would be indistinguishable
from a real determination during a demo. Post the real UAT sample and you get a
422, correctly, because it is a ROTOR air transport with no fixture behind it.

## How the model call works

`llm.py` compiles `med_nec_knowledge.json` into one instruction at startup, not
per request. Everything in the criteria file goes in: the 27 concepts across the
mobility and monitoring axes, the three bed confinement elements and the rule that
all three are required together, the exclusions, the four-part denial test, the
17 policy rules, and the non-specific phrases that never establish anything on
their own. Roughly 14,000 characters.

There is no retrieval step and no vector index. The criteria set fits in one
instruction, so there is nothing to retrieve and no recall failure mode to design
around. That is why Azure AI Search is not on the architecture diagram.

Each request sends the whole trip's question and answer pairs in one call, so
criteria whose elements are spread across several answers are seen together. Bed
confinement is the clearest case: the three elements rarely come from one answer.

Two behaviours worth knowing:

- A response that fails validation is retried once, with the rejected output
  handed back to the model as an assistant turn and the reason given.
- A payload with no clinical answers short-circuits to `does_not_meet` with no
  model call at all, rather than spending tokens to be told nothing is there.

Every criterion the model records as documented must quote the answer text it
rests on, verbatim. A criterion it cannot quote is not documented. The `evidence`
field in `detail.questionFindings` is how you check that held.

## The fixtures after the model is live

They stop being the answer and become the baseline. Each one is the expected
output for a known input, written from the criteria and the meeting examples
before the model was available. Section 9 of `med_nec_live_test.ipynb` compares
every determination against them.

A disagreement is a finding either way. Either the criteria file needs work, or
the baseline was wrong.

## Files

```
app.py                                        the service, both engines
llm.py                                        the Foundry model call
smoke_test.py                                 standalone connectivity check
.env                                          resource and deployment settings, no keys
fixtures.py                                   loads and pairs the files below
med_nec_knowledge.json                        the criteria, compiled into the instruction
med_nec_live_test.ipynb                       runs the trips and checks the result
med_nec_api_demo.ipynb                        the walkthrough for a meeting
payloads/
  trip_1_meets.json                           incoming trip requests
  trip_2_general_weakness.json
  trip_3_wheelchair_candidate.json
responses/
  trip_1_meets.initial.json                   the baseline for each payload
  trip_1_meets.reevaluation.json
  trip_2_general_weakness.initial.json
  trip_2_general_weakness.reevaluation.json
  trip_3_wheelchair_candidate.initial.json
  trip_3_wheelchair_candidate.reevaluation.json
  unmatched.json
send.py                                       command line demo client
build_notebook.py                             regenerates med_nec_api_demo.ipynb
build_live_notebook.py                        regenerates med_nec_live_test.ipynb
diagnose_tls.py                               DNS, TCP, TLS, HTTPS layer by layer
diagnose_sni.py                               whether the block is by hostname
try_alt_endpoints.py                          finds a hostname that gets through
requirements.txt
```

The three `diagnose_*` and `try_*` scripts are kept deliberately. They are the
evidence behind the hostname choice above, and they will be needed again when
the App Service meets the same egress policy.
