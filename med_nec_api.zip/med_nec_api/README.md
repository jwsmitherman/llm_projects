# Medical necessity guidance service

The endpoint Transport.net calls on trip submission. Takes a trip request payload
and returns the three fields agreed in the MVP workflow meeting: a clinical
summary, a medical necessity flag, and a clarifying question when one is needed.

**Every determination comes from the model.** There are no stored answers. A
payload the model cannot be asked about returns a 503 with `meetsMedicalNecessity:
null` and the reason, because a default would be indistinguishable from a real
determination and this endpoint decides whether a transport is billable.

## Install

```powershell
py -m venv C:\venvs\mednec
C:\venvs\mednec\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Two Windows notes. Use `py`, not `python`, to create the venv — Windows ships a
stub `python.exe` that only advertises the Microsoft Store and will shadow a real
install. And keep the venv outside OneDrive: it is tens of thousands of small
files, and syncing them both floods OneDrive and intermittently locks files
mid-install. The project folder itself is fine in OneDrive.

## Run it

Settings live in `.env`, already filled in with the DEV resource provisioned
under RITM0669421:

```
CLAUDE_BASE_URL=https://aif-app-tmp-cus-dev.cognitiveservices.azure.com/anthropic
CLAUDE_DEPLOYMENT_NAME=claude-sonnet-5-5
```

Prove the connection first — it separates a configuration problem from a problem
with the evaluation:

```powershell
az login
python smoke_test.py
python -m uvicorn app:app --reload --port 8000
```

Then open **http://127.0.0.1:8000/ui**.

### Why that hostname and not the one in the portal

The Foundry portal shows `aif-app-tmp-cus-dev.services.ai.azure.com`. From a GMR
workstation that hostname is unusable: TCP 443 connects and the TLS handshake is
then reset (WinError 10054). It is reset by hostname, not by address — other
names pointed at the same IP, including `centralus.api.cognitive.microsoft.com`,
handshake normally. Azure cannot make that distinction, because the hostname
travels inside the handshake being rejected, so the decision is being made by
GMR's egress filter. `*.services.ai.azure.com` is almost certainly caught by a
generative-AI URL category rule.

`aif-app-tmp-cus-dev.cognitiveservices.azure.com` is an alias for the same
resource, serving the same deployments, and is not in that category.

Treat it as a workaround. The App Service subnet will meet the same policy at
deploy time, and a pilot should not rest on an alias that happens not to be
categorised yet. The egress rule to ask for:

> Allow outbound 443 to `*.services.ai.azure.com`, for the developer workstation
> now and the App Service subnet at deploy. `aif-app-tmp-cus-dev` is an Azure AI
> Foundry resource inside GMR's own tenant, provisioned under RITM0669421, not a
> third-party AI service.

`diagnose_tls.py`, `diagnose_sni.py` and `try_alt_endpoints.py` reproduce the
evidence if it is challenged.

### Settings

| Variable | Default | What it does |
|---|---|---|
| `CLAUDE_BASE_URL` | — | must end in `/anthropic` |
| `CLAUDE_DEPLOYMENT_NAME` | — | the deployment name, not the model id |
| `AZURE_CLIENT_ID` | — | **App Service only.** Leave unset locally |
| `CLAUDE_MAX_TOKENS` | `4000` | |
| `CLAUDE_TEMPERATURE` | `0` | see the note below |
| `SIMULATED_LATENCY_MS` | `0` | artificial delay, for timeout testing |

`AZURE_CLIENT_ID` is commented out in `.env` on purpose. Locally the token comes
from your `az login` session; naming a managed identity client id gives
`DefaultAzureCredential` an identity to go looking for that does not exist on a
laptop. It belongs in App Service configuration. There are no keys in `.env`,
which is why it is safe in the repo — keys are disabled on the Foundry resource
deliberately.

> **On temperature.** `anthropic` 1.15 removed `temperature` from the typed
> signature of `messages.create()`. Determinism matters for a coverage
> determination, so where the SDK no longer accepts it the value is sent in the
> request body instead. If the endpoint rejects that too, the call is retried
> once without it and the setting is disabled for the life of the process.
> `GET /v1/engine` reports which mode is in force as `temperatureMode`.

### Deployments available

Both live on `aif-app-tmp-cus-dev`, deployed as Data Zone Standard (US).

| Deployment name | Quota |
|---|---|
| `claude-sonnet-5-5` | 80K TPM |
| `claude-opus-5-5` | 40K TPM |

Sonnet is the default. This is classification against a fixed rubric, running
synchronously inside a trip submission where latency is the constraint, not an
open-ended reasoning task. Reach for Opus when Sonnet's determinations look wrong
on trips whose criteria are clear — swapping is one line in `.env`.

On sizing: the compiled instruction is about 14,000 characters, so roughly 3,500
input tokens before the trip's answers are added. Call it 4,500 in and 800 out.
Against 80K TPM that is **roughly 15 trips a minute**, and a trip that gets a
clarifying question costs two calls. If peak volume exceeds that, the quota needs
raising before pilot.

## The review screen

```
http://127.0.0.1:8000/ui
```

Served by this service, so it talks to the API on the same origin and needs no
separate server and no CORS allowance.

1. Drop a trip request JSON on the page, or browse for one.
2. See the question and answer pairs the service will actually read, extracted
   the same way the service extracts them: from `losQuestions`, or by parsing
   `clinicalData` when that array is null, which is how the real payloads arrive.
   This is what the determination rests on, so it is worth having on screen.
3. Submit. The determination comes back as one of four states, each with its own
   wording and icon as well as its own colour, so the state never rests on colour
   alone: meets, needs one more detail, does not meet, no determination.
4. When a clarifying question comes back, answer it in place and send. The new
   determination replaces the old one and says what changed:
   `does not meet → meets`.
5. Expand for the per-question findings, the criteria and exclusions with their
   citations and quoted evidence, timing, tokens and the raw response.

The badge top right reports what answered the last call. When the model cannot be
reached it turns red, no verdict is shown at all, and the error names the thing
to go and check. Nothing is ever rendered as a determination that was not one.

Everything is one file, `static/index.html`. No build step, no package manager.

## Running a folder of payloads

The review screen is for looking at one trip closely. For volume — the fifty
payloads the Databricks builder writes, say — use the batch runner:

```powershell
python run_batch.py --dir .\inbox
python run_batch.py --dir .\inbox --answer-questions --workers 3
```

It posts every `*.json` in the folder, prints a line per trip, and writes one
workbook: a `trips` sheet with the determination, summary, basis, criteria,
exclusions, timing and tokens, and a `question findings` sheet with one row per
question and answer pair across every trip. That second sheet is the one for
analysis at scale.

`--answer-questions` also sends a standing clarifying answer wherever a question
came back, which doubles the calls. The standing answer says plainly that no
further clinical detail is available, so it exercises the second call without
inventing clinical fact.

Nothing is cached. Fifty files is fifty model calls. Mind the TPM quota when
raising `--workers`.

## Endpoints

### `POST /v1/medical-necessity/evaluate`

Called on trip submission, before the trip is written. Body is the trip request
payload exactly as Transport.net already builds it.

```bash
curl -X POST http://127.0.0.1:8000/v1/medical-necessity/evaluate \
  -H "Content-Type: application/json" -d @inbox/trip_10097360.json
```

The three fields the UI acts on are at the top level. `clarifyingQuestion` is
`null` when no question is needed, which is the signal to show nothing and carry
on with submission.

`detail` carries the per-question findings: category, criterion, citation,
evidence quote and confidence for every question and answer pair. That is the
part worth logging and analysing at scale, not displaying.

### `POST /v1/medical-necessity/reevaluate`

Called after the requester answers the clarifying question.

```jsonc
{
  "tripRequest": { "...the original payload, unchanged..." },
  "clarification": { "question": "...", "answer": "..." }
}
```

**Both integration patterns are supported**, because the meeting did not settle
which one to build. The separate endpoint above is one. The other is to add two
fields to the existing payload, null on the first call:

```jsonc
{ "...trip request...", "clarifyingQuestion": "...", "clarifyingAnswer": "..." }
```

Posted to `/evaluate`, a populated pair routes to a re-evaluation and `callType`
comes back as `reevaluation`. A re-evaluation never asks again: the requester is
asked once. Pick whichever Transport.net prefers and the other can be dropped.

### `GET /healthz`

Up, version, knowledge version, and whether `llm.py` imported.

### `GET /v1/engine`

Live connectivity probe. One trivial model call, reporting the settings in force,
the latency, and on failure the specific thing to go and check. Run it before a
demo.

## What the service reads

Only `tripLegs[0].losQuestions`, or `tripLegs[0].clinicalData` when that array is
null. Patient name, date of birth, SSN, MRN and insurance are **not read and
should not be sent.**

Real payloads do not always populate `losQuestions` — the UAT sample has it null
and puts everything in the flat `clinicalData` string — so that parse is a normal
path, not a rare fallback. It recovers question and answer pairs from the four
formats Transport.net writes, and anything matching none of them becomes its own
pair rather than being dropped.

## Errors

| Status | Meaning | What the caller does |
|---|---|---|
| 200 | evaluated | act on the three fields |
| 422 | payload could not be parsed | log it, submit the trip unchanged |
| 503 | the model could not be reached | log it, submit the trip unchanged |

A 503 returns the three fields as `null` alongside the reason, a hint naming what
to check, and an explicit `action`. Transport.net holds the submission while this
call is in flight, so a failure has to be something it can act on rather than
something it has to parse.

```json
{
  "error": "guidance_unavailable",
  "message": "The guidance service could not evaluate this trip.",
  "detail": "APIConnectionError: Connection error.",
  "hint": "CLAUDE_BASE_URL is wrong, or egress is blocked. Run diagnose_tls.py.",
  "action": "Submit the trip unchanged.",
  "meetsMedicalNecessity": null
}
```

## How the model call works

`llm.py` compiles `med_nec_knowledge.json` into one instruction at startup, not
per request. Everything in the criteria file goes in: the 27 concepts across the
mobility and monitoring axes, the three bed confinement elements and the rule
that all three are required together, the exclusions, the four-part denial test,
the 17 policy rules, and the non-specific phrases that never establish anything
on their own. Roughly 14,000 characters.

There is no retrieval step and no vector index. The criteria set fits in one
instruction, so there is nothing to retrieve and no recall failure mode to design
around. That is why Azure AI Search is not on the architecture diagram.

Each request sends the whole trip's question and answer pairs in one call, so
criteria whose elements are spread across several answers are seen together. Bed
confinement is the clearest case: the three elements rarely come from one answer.

Two behaviours worth knowing:

- A response that fails validation is retried once, with the rejected output
  handed back to the model as an assistant turn and the reason given.
- A payload with no clinical answers short-circuits with no model call at all,
  rather than spending tokens to be told nothing is there.

Every criterion the model records as documented must quote the answer text it
rests on, verbatim. A criterion it cannot quote is not documented. The `evidence`
field in `detail.questionFindings` is how you check that held.

## Layout

```
app.py                    the service
static/index.html         the review screen at /ui
llm.py                    the model call and the criteria compilation
med_nec_knowledge.json    the criteria
run_batch.py              posts a folder of payloads, writes a workbook
inbox/                    drop payloads here
smoke_test.py             standalone connectivity check
diagnose_tls.py           DNS, TCP, TLS, HTTPS layer by layer
diagnose_sni.py           whether a block is by hostname
try_alt_endpoints.py      finds a hostname that gets through
requirements.txt
.env                      resource and deployment settings, no keys
```

The `diagnose_*` and `try_*` scripts are kept deliberately. They are the evidence
behind the hostname choice above, and they will be needed again when the App
Service meets the same egress policy.

## Where payloads come from

`med_nec_payload_builder.ipynb`, in Databricks. It reads trips from
`` `prod-sandbox`.vivekkumar_patel.gold_tnet_tripmaster ``, parses `ClinicalData`
into the structured `losQuestions` array, strips every patient identifier, and
writes JSON files. Drop those in `inbox/` and run the batch, or open one at a
time in the review screen.
