"""Builds payload and response pairs on the real UAT envelope.

The UAT sample Transport.net supplied differs from the synthetic payloads in two
ways that matter:

  1. losQuestions is null. Every clinical answer is in the flat clinicalData
     string. The structured array is not guaranteed to be populated.
  2. The envelope carries about 90 fields the service never reads, including a
     large additionalFields array.

These payloads keep the real envelope and vary only the clinical content, so the
service is exercised against the shape it will actually receive.

Patient identifiers are stripped. The UAT sample's patientInfo is QA automation
data rather than real PHI, but nothing patient-shaped belongs in a fixture file.

    python build_uat_fixtures.py
"""

import copy
import json
from pathlib import Path

ROOT = Path(__file__).parent
UAT_SOURCE = ROOT / "uat_source" / "UAT_SampleTripRequest_1.json"
PAYLOAD_DIR = ROOT / "payloads"
RESPONSE_DIR = ROOT / "responses"

CITE_CMS = "Medicare Benefit Policy Manual Chapter 10, 10.2.1 and 10.2.3; 42 CFR 410.40"
CITE_BILLING = "Medical Necessity Training Guide, Sep 2025"
CITE_SURVEY = "Clinical intake survey specification, version 1.27.26"
CITE_TRAINING = "Medical Necessity Facility Training, GMR/AMR, 2026-08-13"

SCRUBBED_PATIENT = {
    "firstName": "", "middleName": "", "lastName": "",
    "dateOfBirth": "", "ssn": None, "mrn": "", "mrnSource": "",
    "visitNumber": "", "visitNumberSource": "", "gender": "",
    "address": "", "physicalStreet": "", "physicalCity": "", "physicalState": "",
    "physicalCounty": "", "physicalZipCode": "", "billingAddress": "",
    "mailingAddress": "", "bedAptRoom": "", "phoneNumber": "", "phoneExt": "",
    "guarantor": "", "diagnosis": "", "overMaxWeight": False,
    "patientOver300Lbs": None, "patientWeight": "", "patientHeight": "",
    "heightUnit": "0003", "weightUnit": "0005",
    "dischargingPhysicianNpi": "", "dischargingPhysician": "",
    "dischargingPhysicianPhone": "", "authorizingPhysician": "",
    "receivingPhysician": "", "attendingPhysician": "", "consultingPhysician": "",
    "referringPhysician": "", "admittingPhysician": "",
    "externalPatientId": "", "externalEncounterId": "",
    "ssoContractDetailsId": "", "epiId": "",
    "_note": "Deliberately empty. The service reads only clinical answers.",
}


def flatten(items):
    """Render question and answer pairs the way Transport.net writes clinicalData.

    Each item is the question twice then the answer, or the label once then
    'label: answer'. Mirrors the real UAT sample exactly.
    """
    lines = []
    for question, answer in items:
        lines.append(question)
        lines.append(question)
        lines.append(answer)
    return "\n".join(lines)


# --------------------------------------------------------------------------
# Scenarios. Each is (stem, how the leg differs, the two responses.)
# --------------------------------------------------------------------------

GROUND_SCENARIOS = []


def scenario(stem, request_id, trip_reason, trip_reason_id, los, items,
             medicare_ten, initial, reevaluation, dropoff_type="H"):
    GROUND_SCENARIOS.append({
        "stem": stem,
        "olosRequestId": request_id,
        "tripReason": trip_reason,
        "tripReasonId": trip_reason_id,
        "los": los,
        "items": items,
        "medicareQuestionTen": medicare_ten,
        "dropoffLocTypeCode": dropoff_type,
        "initial": initial,
        "reevaluation": reevaluation,
    })


# -- 1. meets, nothing asked ------------------------------------------------

scenario(
    stem="uat_2_vent_bed_confined",
    request_id="e1a00001-0000-4000-8000-000000000002",
    trip_reason="Discharge to Skilled Nursing Facility",
    trip_reason_id="118",
    los="ALS",
    medicare_ten="DX: Respiratory failure, ventilator dependent",
    items=[
        ("Is this patient being transferred to a higher level of care due to their clinical condition?",
         "No (Discharge, Behavioral Transfer or Other Reason): dc to SNF"),
        ("Is any special handling required during transport?",
         "The patient is bed confined before and after transport. All three criteria must be met "
         "in order to use bed confined. Please specify reason in comments field.: The patient is "
         "unable to get up from bed without assistance, The patient is unable to ambulate, The "
         "patient is unable to sit in a chair or wheelchair: vent dependent, trach in place"),
        ("Does the patient require airway support during transport?",
         "Patient is on a ventilator operated by the transport provider, Requires regular "
         "oropharyngeal suctioning"),
        ("Is this a Time Sensitive transport request?", "No"),
    ],
    initial={
        "clinicalSummary": (
            "Patient is ventilator dependent with a tracheostomy in place and requires regular "
            "oropharyngeal suctioning during transport. Bed confinement is documented on all three "
            "elements: unable to get up from bed without assistance, unable to ambulate, and unable "
            "to sit in a chair or wheelchair."
        ),
        "meetsMedicalNecessity": True,
        "clarifyingQuestion": None,
        "detail": {
            "determination": "meets",
            "basis": (
                "Ventilator operation by the transport provider is a monitoring need that other "
                "means of transport cannot meet. Suctioning is documented alongside it. Bed "
                "confinement is satisfied on all three elements, which supports but is not "
                "relied upon for the determination."
            ),
            "gateSatisfied": True,
            "confidence": "High",
            "criteriaDocumented": [
                {"criterionId": "airway_ventilator", "citation": CITE_TRAINING,
                 "evidence": "Patient is on a ventilator operated by the transport provider",
                 "questionId": None},
                {"criterionId": "suctioning", "citation": CITE_TRAINING,
                 "evidence": "Requires regular oropharyngeal suctioning", "questionId": None},
                {"criterionId": "bed_confinement", "citation": CITE_BILLING,
                 "evidence": "The patient is unable to get up from bed without assistance, The "
                             "patient is unable to ambulate, The patient is unable to sit in a "
                             "chair or wheelchair",
                 "questionId": None},
            ],
            "criteriaMissing": [],
            "exclusionsTriggered": [],
            "questionFindings": [
                {"questionId": None,
                 "question": "Is this patient being transferred to a higher level of care due to their clinical condition?",
                 "answer": "No (Discharge, Behavioral Transfer or Other Reason): dc to SNF",
                 "nonMedNec": True, "category": "administrative",
                 "criterionId": None, "citation": None, "evidence": None,
                 "reason": "Records the transfer reason. States nothing about the patient's condition.",
                 "confidence": "High"},
                {"questionId": None,
                 "question": "Is any special handling required during transport?",
                 "answer": "The patient is bed confined before and after transport... unable to get "
                           "up from bed without assistance, unable to ambulate, unable to sit in a "
                           "chair or wheelchair: vent dependent, trach in place",
                 "nonMedNec": False, "category": "supports_necessity",
                 "criterionId": "bed_confinement", "citation": CITE_BILLING,
                 "evidence": "The patient is unable to get up from bed without assistance, The "
                             "patient is unable to ambulate, The patient is unable to sit in a "
                             "chair or wheelchair",
                 "reason": "All three bed confinement elements are present in one answer.",
                 "confidence": "High"},
                {"questionId": None,
                 "question": "Does the patient require airway support during transport?",
                 "answer": "Patient is on a ventilator operated by the transport provider, Requires "
                           "regular oropharyngeal suctioning",
                 "nonMedNec": False, "category": "supports_necessity",
                 "criterionId": "airway_ventilator", "citation": CITE_TRAINING,
                 "evidence": "Patient is on a ventilator operated by the transport provider",
                 "reason": "Ventilator operation by the transport provider is a qualifying "
                           "monitoring need on its own.",
                 "confidence": "High"},
                {"questionId": None,
                 "question": "Is this a Time Sensitive transport request?",
                 "answer": "No", "nonMedNec": True, "category": "administrative",
                 "criterionId": None, "citation": None, "evidence": None,
                 "reason": "Scheduling information. Not clinical.", "confidence": "High"},
            ],
        },
    },
    reevaluation=None,  # nothing was asked, so re-evaluation returns the same
)

# -- 2. general weakness, rescued by the answer -----------------------------

GW_QUESTION = (
    "General weakness on its own does not establish medical necessity. What about this patient's "
    "condition prevents them from sitting safely in a wheelchair while the vehicle is in motion?"
)

scenario(
    stem="uat_3_general_weakness",
    request_id="e1a00001-0000-4000-8000-000000000003",
    trip_reason="Discharge to Residence",
    trip_reason_id="121",
    los="BLS",
    medicare_ten="DX: Deconditioning",
    dropoff_type="R",
    items=[
        ("Is this patient being transferred to a higher level of care due to their clinical condition?",
         "No (Discharge, Behavioral Transfer or Other Reason): discharge home"),
        ("Is any special handling required during transport?",
         "The patient is unable to sit safely in a wheelchair while the vehicle is in motion"),
        ("Please specify the reason the patient cannot sit safely in a wheelchair",
         "general weakness"),
        ("Does the patient require airway support during transport?", "None - Does not apply"),
        ("Is this a Time Sensitive transport request?", "No"),
    ],
    initial={
        "clinicalSummary": (
            "Patient is being discharged to a residence following a stay for deconditioning. The "
            "requester reports the patient cannot sit safely in a wheelchair while the vehicle is "
            "in motion, with general weakness given as the only reason. No airway, monitoring or "
            "handling need is documented."
        ),
        "meetsMedicalNecessity": False,
        "clarifyingQuestion": GW_QUESTION,
        "detail": {
            "determination": "needs_review",
            "basis": (
                "The only reason offered for the inability to sit in a wheelchair is general "
                "weakness, which guidance names as insufficient on its own. Nothing else "
                "documented supports either axis. A specific underlying condition could change "
                "this, so the trip is not denied outright."
            ),
            "gateSatisfied": False,
            "confidence": "Medium",
            "criteriaDocumented": [],
            "criteriaMissing": ["mobility", "monitoring"],
            "exclusionsTriggered": [
                {"exclusionId": "general_weakness_alone", "citation": CITE_SURVEY,
                 "evidence": "general weakness",
                 "statement": "General weakness alone does not meet medical necessity standards."}
            ],
            "questionFindings": [
                {"questionId": None,
                 "question": "Is this patient being transferred to a higher level of care due to their clinical condition?",
                 "answer": "No (Discharge, Behavioral Transfer or Other Reason): discharge home",
                 "nonMedNec": True, "category": "administrative",
                 "criterionId": None, "citation": None, "evidence": None,
                 "reason": "Records the transfer reason. States nothing about the patient's condition.",
                 "confidence": "High"},
                {"questionId": None,
                 "question": "Is any special handling required during transport?",
                 "answer": "The patient is unable to sit safely in a wheelchair while the vehicle is in motion",
                 "nonMedNec": False, "category": "insufficient_alone",
                 "criterionId": "contraindicated_other_means", "citation": CITE_SURVEY,
                 "evidence": "The patient is unable to sit safely in a wheelchair while the vehicle is in motion",
                 "reason": "Asserts the conclusion rather than the condition behind it. The "
                           "follow-up answer is what carries the weight.",
                 "confidence": "Medium"},
                {"questionId": None,
                 "question": "Please specify the reason the patient cannot sit safely in a wheelchair",
                 "answer": "general weakness",
                 "nonMedNec": True, "category": "non_covered",
                 "criterionId": None, "citation": CITE_SURVEY, "evidence": "general weakness",
                 "reason": "Named in guidance as insufficient on its own to establish necessity.",
                 "confidence": "High"},
                {"questionId": None,
                 "question": "Does the patient require airway support during transport?",
                 "answer": "None - Does not apply", "nonMedNec": True, "category": "administrative",
                 "criterionId": None, "citation": None, "evidence": None,
                 "reason": "Reports no airway need.", "confidence": "High"},
                {"questionId": None,
                 "question": "Is this a Time Sensitive transport request?",
                 "answer": "No", "nonMedNec": True, "category": "administrative",
                 "criterionId": None, "citation": None, "evidence": None,
                 "reason": "Scheduling information. Not clinical.", "confidence": "High"},
            ],
        },
    },
    reevaluation={
        "clinicalSummary": (
            "Patient sustained a stroke in the past week with dense left sided weakness, cannot sit "
            "upright unsupported, and requires a two person assist for all transfers. Transport is "
            "a discharge to a residence."
        ),
        "meetsMedicalNecessity": True,
        "clarifyingQuestion": None,
        "detail": {
            "determination": "meets",
            "basis": (
                "The clarifying answer supplies the specific deficit that was missing. Dense left "
                "sided weakness following a recent stroke, with an inability to sit upright "
                "unsupported, establishes the mobility axis."
            ),
            "gateSatisfied": True,
            "confidence": "High",
            "criteriaDocumented": [
                {"criterionId": "paralysis_weakness", "citation": CITE_CMS,
                 "evidence": "dense left sided weakness", "questionId": None},
                {"criterionId": "contraindicated_other_means", "citation": CITE_SURVEY,
                 "evidence": "Cannot sit upright unsupported and requires two person assist for all transfers",
                 "questionId": None},
            ],
            "criteriaMissing": [],
            "exclusionsTriggered": [],
            "questionFindings": [
                {"questionId": None, "question": GW_QUESTION,
                 "answer": "Patient had a stroke last week with dense left sided weakness. Cannot "
                           "sit upright unsupported and requires two person assist for all transfers.",
                 "nonMedNec": False, "category": "supports_necessity",
                 "criterionId": "paralysis_weakness", "citation": CITE_CMS,
                 "evidence": "dense left sided weakness",
                 "reason": "A named deficit rather than a general descriptor. Establishes the "
                           "mobility axis.",
                 "confidence": "High"},
            ],
        },
    },
)

# -- 3. wheelchair capable, stays denied ------------------------------------

WC_QUESTION = (
    "The answers indicate the patient can sit safely in a wheelchair and the oxygen is patient "
    "supplied. Is there a care need during transport that a wheelchair van could not meet?"
)

scenario(
    stem="uat_4_wheelchair_candidate",
    request_id="e1a00001-0000-4000-8000-000000000004",
    trip_reason="Transport to Scheduled Appointment",
    trip_reason_id="140",
    los="BLS",
    medicare_ten="DX: End stage renal disease",
    items=[
        ("Is this patient being transferred to a higher level of care due to their clinical condition?",
         "No (Discharge, Behavioral Transfer or Other Reason): to dialysis"),
        ("Is any special handling required during transport?",
         "The patient can sit safely in a wheelchair while the vehicle is in motion"),
        ("Does the patient require airway support during transport?",
         "The patient requires continuous oxygen provided by the patient's own equipment at their "
         "baseline rate"),
        ("Is this a Time Sensitive transport request?",
         "Yes - Due to other reasons such as destination closing soon: dialysis chair time at 1400"),
    ],
    initial={
        "clinicalSummary": (
            "Patient is travelling to a scheduled dialysis appointment and can sit safely in a "
            "wheelchair while the vehicle is in motion. Oxygen is continuous at a baseline rate "
            "from the patient's own equipment, with no regulation required. The stated urgency is "
            "a dialysis chair time."
        ),
        "meetsMedicalNecessity": False,
        "clarifyingQuestion": WC_QUESTION,
        "detail": {
            "determination": "does_not_meet",
            "basis": (
                "Three separate exclusions apply and nothing documented supports either axis. The "
                "patient is wheelchair capable, the oxygen requires no regulation during transport, "
                "and the urgency is a scheduling constraint rather than a clinical one."
            ),
            "gateSatisfied": False,
            "confidence": "High",
            "criteriaDocumented": [],
            "criteriaMissing": ["mobility", "monitoring"],
            "exclusionsTriggered": [
                {"exclusionId": "can_sit_safely_in_wheelchair", "citation": CITE_SURVEY,
                 "evidence": "The patient can sit safely in a wheelchair while the vehicle is in motion",
                 "statement": "A patient who can sit safely in a wheelchair while in a moving "
                              "vehicle does not establish medical necessity for ambulance transport."},
                {"exclusionId": "oxygen_without_regulation", "citation": CITE_TRAINING,
                 "evidence": "continuous oxygen provided by the patient's own equipment at their baseline rate",
                 "statement": "A patient on oxygen, without a need for oxygen regulation or another "
                              "listed monitoring need, does not establish medical necessity."},
                {"exclusionId": "non_clinical_urgency", "citation": CITE_SURVEY,
                 "evidence": "dialysis chair time at 1400",
                 "statement": "A time sensitive request driven by destination hours or scheduling "
                              "pressure is not a clinical reason."},
            ],
            "questionFindings": [
                {"questionId": None,
                 "question": "Is this patient being transferred to a higher level of care due to their clinical condition?",
                 "answer": "No (Discharge, Behavioral Transfer or Other Reason): to dialysis",
                 "nonMedNec": True, "category": "administrative",
                 "criterionId": None, "citation": None, "evidence": None,
                 "reason": "Records the transfer reason. States nothing about the patient's condition.",
                 "confidence": "High"},
                {"questionId": None,
                 "question": "Is any special handling required during transport?",
                 "answer": "The patient can sit safely in a wheelchair while the vehicle is in motion",
                 "nonMedNec": True, "category": "non_covered",
                 "criterionId": None, "citation": CITE_SURVEY,
                 "evidence": "The patient can sit safely in a wheelchair while the vehicle is in motion",
                 "reason": "Affirmatively rules out the mobility axis.", "confidence": "High"},
                {"questionId": None,
                 "question": "Does the patient require airway support during transport?",
                 "answer": "The patient requires continuous oxygen provided by the patient's own "
                           "equipment at their baseline rate",
                 "nonMedNec": True, "category": "non_covered",
                 "criterionId": None, "citation": CITE_TRAINING,
                 "evidence": "patient's own equipment at their baseline rate",
                 "reason": "Oxygen at a baseline rate from the patient's own equipment involves no "
                           "regulation by the crew, so it is not a monitoring need.",
                 "confidence": "High"},
                {"questionId": None,
                 "question": "Is this a Time Sensitive transport request?",
                 "answer": "Yes - Due to other reasons such as destination closing soon: dialysis chair time at 1400",
                 "nonMedNec": True, "category": "non_covered",
                 "criterionId": None, "citation": CITE_SURVEY,
                 "evidence": "dialysis chair time at 1400",
                 "reason": "A scheduling constraint, not a clinical one.", "confidence": "High"},
            ],
        },
    },
    reevaluation={
        "clinicalSummary": (
            "Patient is travelling to a scheduled dialysis appointment and can sit safely in a "
            "wheelchair while the vehicle is in motion. Oxygen is continuous at a baseline rate "
            "from the patient's own equipment. The requester confirms the urgency is the dialysis "
            "chair time and offers no additional care need."
        ),
        "meetsMedicalNecessity": False,
        "clarifyingQuestion": None,
        "detail": {
            "determination": "does_not_meet",
            "basis": (
                "The clarifying answer restates the scheduling constraint and adds no clinical "
                "content. The three exclusions from the first pass are unchanged and no criterion "
                "is documented on either axis."
            ),
            "gateSatisfied": False,
            "confidence": "High",
            "criteriaDocumented": [],
            "criteriaMissing": ["mobility", "monitoring"],
            "exclusionsTriggered": [
                {"exclusionId": "can_sit_safely_in_wheelchair", "citation": CITE_SURVEY,
                 "evidence": "The patient can sit safely in a wheelchair while the vehicle is in motion",
                 "statement": "A patient who can sit safely in a wheelchair while in a moving "
                              "vehicle does not establish medical necessity for ambulance transport."},
                {"exclusionId": "non_clinical_urgency", "citation": CITE_SURVEY,
                 "evidence": "Patient needs to arrive by their scheduled dialysis chair time.",
                 "statement": "A time sensitive request driven by destination hours or scheduling "
                              "pressure is not a clinical reason."},
            ],
            "questionFindings": [
                {"questionId": None, "question": WC_QUESTION,
                 "answer": "Patient needs to arrive by their scheduled dialysis chair time.",
                 "nonMedNec": True, "category": "non_covered",
                 "criterionId": None, "citation": CITE_SURVEY,
                 "evidence": "scheduled dialysis chair time",
                 "reason": "Restates the scheduling constraint. No care need is offered.",
                 "confidence": "High"},
            ],
        },
    },
)


# --------------------------------------------------------------------------
# The air transport case: out of scope rather than a determination
# --------------------------------------------------------------------------

ROTOR_RESPONSE = {
    "clinicalSummary": None,
    "meetsMedicalNecessity": None,
    "clarifyingQuestion": None,
    "detail": {
        "determination": "out_of_scope",
        "basis": (
            "Level of service is ROTOR, an air medical transport. The criteria in this service "
            "cover non-emergent ground ambulance transport under Medicare Benefit Policy Manual "
            "Chapter 10. Air transport is governed by separate criteria that are not loaded here, "
            "so no determination is made and the submission should proceed unchanged."
        ),
        "gateSatisfied": None,
        "confidence": "High",
        "criteriaDocumented": [],
        "criteriaMissing": [],
        "exclusionsTriggered": [],
        "questionFindings": [],
    },
}


def main() -> int:
    if not UAT_SOURCE.exists():
        print(f"Put the UAT sample at {UAT_SOURCE} first.")
        return 1

    envelope = json.loads(UAT_SOURCE.read_text())
    PAYLOAD_DIR.mkdir(exist_ok=True)
    RESPONSE_DIR.mkdir(exist_ok=True)
    written = []

    # 1. the UAT sample itself, de-identified
    rotor = copy.deepcopy(envelope)
    rotor["tripLegs"][0]["patientInfo"] = copy.deepcopy(SCRUBBED_PATIENT)
    rotor["tripLegs"][0]["medicareQuestionTen"] = ""
    rotor["requesterName"] = "UAT Automation"
    rotor["requesterFirstName"] = "UAT"
    rotor["requesterLastName"] = "Automation"
    rotor["createdBy"] = "UAT Automation"
    rotor["createdByEmail"] = ""
    rotor["notifyName"] = ""
    rotor["notifyEmail"] = ""
    rotor["notifyPhone"] = ""

    (PAYLOAD_DIR / "uat_1_rotor_air.json").write_text(json.dumps(rotor, indent=4))
    (RESPONSE_DIR / "uat_1_rotor_air.initial.json").write_text(json.dumps(ROTOR_RESPONSE, indent=2))
    (RESPONSE_DIR / "uat_1_rotor_air.reevaluation.json").write_text(json.dumps(ROTOR_RESPONSE, indent=2))
    written.append("uat_1_rotor_air")

    # 2. ground scenarios on the same envelope
    for s in GROUND_SCENARIOS:
        trip = copy.deepcopy(envelope)
        leg = trip["tripLegs"][0]

        trip["olosRequestId"] = s["olosRequestId"]
        trip["tripReason"] = s["tripReason"]
        trip["tripReasonId"] = s["tripReasonId"]
        trip["requesterName"] = "UAT Automation"
        trip["requesterFirstName"] = "UAT"
        trip["requesterLastName"] = "Automation"
        trip["createdBy"] = "UAT Automation"
        trip["createdByEmail"] = ""
        trip["notifyName"] = ""
        trip["notifyEmail"] = ""
        trip["notifyPhone"] = ""

        leg["patientInfo"] = copy.deepcopy(SCRUBBED_PATIENT)
        leg["systemLos"] = s["los"]
        leg["levelOfService"] = s["los"]
        leg["losCategory"] = s["los"]
        leg["losCategoryLabel"] = s["los"]
        leg["losQuestions"] = None          # as the real UAT payload has it
        leg["clinicalData"] = flatten(s["items"])
        leg["medicareQuestionTen"] = s["medicareQuestionTen"]
        leg["dropoffLocTypeCode"] = s["dropoffLocTypeCode"]

        (PAYLOAD_DIR / f"{s['stem']}.json").write_text(json.dumps(trip, indent=4))
        (RESPONSE_DIR / f"{s['stem']}.initial.json").write_text(json.dumps(s["initial"], indent=2))
        reeval = s["reevaluation"] or s["initial"]
        (RESPONSE_DIR / f"{s['stem']}.reevaluation.json").write_text(json.dumps(reeval, indent=2))
        written.append(s["stem"])

    print(f"wrote {len(written)} payload and response sets:")
    for name in written:
        print("   ", name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
