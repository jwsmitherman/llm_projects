"""Posts a folder of trip requests at the service and writes the results to Excel.

    python run_batch.py --dir ./inbox
    python run_batch.py --dir ./inbox --answer-questions
    python run_batch.py --dir ./inbox --limit 10 --workers 4

Built for the output of the Databricks payload builder: drop fifty JSON files in
a folder and get one workbook back. The review screen at /ui is for looking at a
single trip closely; this is for volume.

Nothing is cached. Every file is a real model call, so a run of fifty costs
fifty calls, or a hundred with --answer-questions.
"""

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

import httpx
import pandas as pd

RUN_TS = datetime.now().strftime("%Y%m%d_%H%M%S")

# Sent as the clarifying answer when --answer-questions is set. The point is to
# exercise the second call, not to supply clinical fact, so it says so plainly.
STANDING_ANSWER = (
    "No additional clinical detail is available for this retrospective trip."
)


def post(client, url, body, timeout):
    started = time.perf_counter()
    try:
        r = client.post(url, json=body, timeout=timeout)
        ms = int((time.perf_counter() - started) * 1000)
        try:
            return r.status_code, r.json(), ms, None
        except Exception:
            return r.status_code, None, ms, f"non-JSON response: {r.text[:200]}"
    except Exception as exc:
        ms = int((time.perf_counter() - started) * 1000)
        return None, None, ms, f"{type(exc).__name__}: {exc}"[:300]


def run_one(args, path):
    row = {"file": path.name}
    try:
        trip = json.loads(path.read_text())
    except Exception as exc:
        row["error"] = f"unreadable: {exc}"
        return row

    row["sourceSystemTripId"] = trip.get("sourceSystemTripId")
    row["olosRequestId"] = trip.get("olosRequestId")
    legs = trip.get("tripLegs") or [{}]
    row["levelOfService"] = legs[0].get("levelOfService")

    with httpx.Client(base_url=args.base) as client:
        status, body, ms, err = post(
            client, "/v1/medical-necessity/evaluate", trip, args.timeout)
        row["httpStatus"] = status
        row["initialMs"] = ms

        if err or body is None:
            row["error"] = err or "no body"
            return row
        if status != 200:
            row["error"] = f"{body.get('error')}: {body.get('detail') or body.get('message')}"
            return row

        detail = body.get("detail") or {}
        meta = body.get("meta") or {}
        row.update({
            "meets": body.get("meetsMedicalNecessity"),
            "determination": detail.get("determination"),
            "confidence": detail.get("confidence"),
            "asked": bool(body.get("clarifyingQuestion")),
            "clarifyingQuestion": body.get("clarifyingQuestion"),
            "clinicalSummary": body.get("clinicalSummary"),
            "basis": detail.get("basis"),
            "criteriaDocumented": ", ".join(
                str(c.get("criterionId")) for c in detail.get("criteriaDocumented") or []),
            "exclusionsTriggered": ", ".join(
                str(e.get("exclusionId")) for e in detail.get("exclusionsTriggered") or []),
            "questionsEvaluated": meta.get("questionsEvaluated"),
            "inputTokens": meta.get("inputTokens"),
            "outputTokens": meta.get("outputTokens"),
            "estimatedCostUsd": meta.get("estimatedCostUsd"),
            "modelMs": meta.get("modelMs"),
            "overheadMs": meta.get("overheadMs"),
            "modelCalls": meta.get("modelCalls"),
        })
        row["_findings"] = detail.get("questionFindings") or []

        if args.answer_questions and body.get("clarifyingQuestion"):
            status2, body2, ms2, err2 = post(
                client, "/v1/medical-necessity/reevaluate",
                {"tripRequest": trip,
                 "clarification": {"question": body["clarifyingQuestion"],
                                   "answer": STANDING_ANSWER}},
                args.timeout)
            row["reevalMs"] = ms2
            if err2 or body2 is None or status2 != 200:
                row["reevalError"] = err2 or str(status2)
            else:
                d2 = body2.get("detail") or {}
                m2 = body2.get("meta") or {}
                row["meetsAfterAnswer"] = body2.get("meetsMedicalNecessity")
                row["determinationAfterAnswer"] = d2.get("determination")
                row["summaryAfterAnswer"] = body2.get("clinicalSummary")
                row["inputTokens"] = (row.get("inputTokens") or 0) + (m2.get("inputTokens") or 0)
                row["outputTokens"] = (row.get("outputTokens") or 0) + (m2.get("outputTokens") or 0)
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="inbox", help="folder of trip request JSON files")
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    ap.add_argument("--out", default=None, help="output .xlsx path")
    ap.add_argument("--limit", type=int, default=0, help="stop after N files")
    ap.add_argument("--workers", type=int, default=3, help="parallel calls, mind the TPM quota")
    ap.add_argument("--timeout", type=float, default=180.0)
    ap.add_argument("--answer-questions", action="store_true",
                    help="also send a standing clarifying answer, doubling the calls")
    args = ap.parse_args()

    folder = Path(args.dir)
    if not folder.is_dir():
        print(f"No such folder: {folder.resolve()}")
        return 1

    files = sorted(folder.glob("*.json"))
    if args.limit:
        files = files[:args.limit]
    if not files:
        print(f"No .json files in {folder.resolve()}")
        return 1

    try:
        health = httpx.get(f"{args.base}/healthz", timeout=10).json()
        print(f"service   : {health.get('status')}  engine {health.get('engineVersion')}")
    except Exception as exc:
        print(f"Cannot reach {args.base}: {exc}")
        print("Start it with:  python -m uvicorn app:app --port 8000")
        return 1

    expected = len(files) * (2 if args.answer_questions else 1)
    print(f"files     : {len(files)}")
    print(f"calls     : up to {expected}")
    print(f"workers   : {args.workers}")
    print()

    started = time.perf_counter()
    rows = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for i, row in enumerate(pool.map(lambda p: run_one(args, p), files), 1):
            rows.append(row)
            flag = row.get("error") or row.get("determination") or "?"
            print(f"  [{i}/{len(files)}] {row['file'][:46]:46} {str(flag)[:40]}")

    elapsed = time.perf_counter() - started
    df = pd.DataFrame(rows)

    findings = []
    for row in rows:
        for f in row.get("_findings") or []:
            findings.append({
                "file": row["file"],
                "sourceSystemTripId": row.get("sourceSystemTripId"),
                **{k: f.get(k) for k in
                   ("questionId", "question", "answer", "nonMedNec", "category",
                    "criterionId", "citation", "evidence", "reason", "confidence")},
            })
    df = df.drop(columns=["_findings"], errors="ignore")

    out = Path(args.out) if args.out else folder / f"med_nec_results_{RUN_TS}.xlsx"
    with pd.ExcelWriter(out, engine="openpyxl") as xl:
        df.to_excel(xl, sheet_name="trips", index=False)
        if findings:
            pd.DataFrame(findings).to_excel(xl, sheet_name="question findings", index=False)

    print()
    print(f"elapsed        : {elapsed:.1f}s")
    errors = int(df["error"].notna().sum()) if "error" in df else 0
    print(f"evaluated      : {len(df) - errors} of {len(df)}")
    if errors:
        print(f"errors         : {errors}")
    if "determination" in df:
        for value, count in df["determination"].value_counts(dropna=True).items():
            print(f"  {value:18} {count}")
    if "asked" in df:
        print(f"asked a question: {int(df['asked'].fillna(False).sum())}")
    for col in ("initialMs", "modelMs", "inputTokens", "outputTokens"):
        if col in df and df[col].notna().any():
            print(f"median {col:14}: {int(df[col].median())}")
    if "initialMs" in df and df["initialMs"].notna().any():
        p95 = int(df["initialMs"].dropna().quantile(0.95))
        print(f"p95 initialMs       : {p95}")
        if p95 > 5000:
            print(f"  CHECK  p95 is {p95/1000:.1f}s, above the two to five second working")
            print("         figure for the submission timeout.")
    if "estimatedCostUsd" in df and df["estimatedCostUsd"].notna().any():
        print(f"total cost          : ${df['estimatedCostUsd'].sum():.4f}")
    print()
    print(f"written: {out.resolve()}")
    if findings:
        print(f"         {len(findings)} question findings on the second sheet")
    return 0


if __name__ == "__main__":
    sys.exit(main())
