"""Medical necessity guidance service.

Transport.net posts the trip request on submission and receives three things back:
a clinical summary, a flag for whether the trip meets medical necessity, and a
clarifying question when one is needed.

Two engines sit behind the same contract.

    USE_MODEL unset or false   the three demo payloads resolve to pre-written
                               responses in responses/. No model, no spend.
    USE_MODEL=true             every request goes to the Claude deployment in
                               Azure AI Foundry, authenticated with managed
                               identity. See llm.py.

The envelope, the event log, the timing fields and both call patterns are
identical either way, so the Transport.net integration does not know or care
which engine answered.
"""

import hashlib
import json
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

try:  # a .env next to this file beats retyping settings in every terminal
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env.local", override=False)
    load_dotenv(Path(__file__).parent / ".env", override=False)
except ImportError:
    pass

from fixtures import ENGINE_VERSION, FIXTURES, KNOWLEDGE_VERSION, UNMATCHED

SERVICE_NAME = "med-nec-guidance"
SERVICE_VERSION = "0.2.0-local"

USE_MODEL = os.environ.get("USE_MODEL", "false").strip().lower() in ("1", "true", "yes", "on")
FALLBACK_TO_FIXTURE = os.environ.get("FALLBACK_TO_FIXTURE", "true").strip().lower() in ("1", "true", "yes", "on")

# A fixture returns instantly, which does not resemble a real call, so the demo
# build pads it. A real call has its own latency and gets no padding.
DEFAULT_DELAY_MS = 0 if USE_MODEL else int(os.environ.get("SIMULATED_LATENCY_MS", "350"))

EVENT_LOG_PATH = Path(os.environ.get("EVENT_LOG_PATH", "request_event_log.jsonl"))

llm = None
LLM_IMPORT_ERROR: Optional[str] = None
if USE_MODEL:
    try:
        import llm as llm_module
        llm = llm_module
    except Exception as exc:  # missing sdk, missing knowledge file
        LLM_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"

app = FastAPI(
    title="Medical necessity guidance service",
    description=(
        "Evaluates a non-emergent ground ambulance trip request against CMS medical "
        "necessity criteria. Runs on the Foundry model deployment when USE_MODEL is "
        "set, otherwise on pre-written responses for the three demo payloads."
    ),
    version=SERVICE_VERSION,
)

FINGERPRINT_INDEX: Dict[str, str] = {}

ROOT = Path(__file__).parent
STATIC_DIR = ROOT / "static"
PAYLOAD_DIR = ROOT / "payloads"

# The review screen, and the payloads it offers in the picker. Same origin as the
# API, so the browser needs no CORS allowance.
if STATIC_DIR.is_dir():
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
if PAYLOAD_DIR.is_dir():
    app.mount("/payloads", StaticFiles(directory=PAYLOAD_DIR), name="payloads")


@app.get("/", include_in_schema=False)
def root() -> RedirectResponse:
    return RedirectResponse(url="/ui")


@app.get("/ui", include_in_schema=False)
def ui() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


class Clarification(BaseModel):
    question: str = Field(..., description="The clarifying question that was presented to the requester.")
    answer: str = Field(..., description="Free text the requester typed in response.")


class ReevaluateRequest(BaseModel):
    tripRequest: Dict[str, Any] = Field(..., description="The original trip request payload, unchanged.")
    clarification: Clarification


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def first_leg(trip: Dict[str, Any]) -> Dict[str, Any]:
    legs = trip.get("tripLegs") or []
    return legs[0] if legs else {}


def clinical_fingerprint(trip: Dict[str, Any]) -> str:
    leg = first_leg(trip)
    questions = leg.get("losQuestions") or []
    if questions:
        parts = []
        for q in questions:
            if not isinstance(q, dict):
                continue
            parts.append(
                "|".join(
                    str(q.get(k) or "").strip().lower()
                    for k in ("questionId", "questionText", "answer", "answerValue")
                )
            )
        basis = "\n".join(sorted(parts))
    else:
        basis = " ".join(str(leg.get("clinicalData") or "").split()).lower()
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


def build_fingerprint_index() -> None:
    payload_dir = Path(__file__).parent / "payloads"
    if not payload_dir.is_dir():
        return
    for path in sorted(payload_dir.glob("*.json")):
        try:
            trip = json.loads(path.read_text())
        except Exception:
            continue
        request_id = trip.get("olosRequestId")
        if request_id in FIXTURES:
            FINGERPRINT_INDEX[clinical_fingerprint(trip)] = request_id


def resolve_fixture(trip: Dict[str, Any]) -> Tuple[Dict[str, Any], str]:
    request_id = trip.get("olosRequestId")
    if request_id and request_id in FIXTURES:
        return FIXTURES[request_id], "olosRequestId"
    matched = FINGERPRINT_INDEX.get(clinical_fingerprint(trip))
    if matched:
        return FIXTURES[matched], "clinicalFingerprint"
    return UNMATCHED, "none"


def question_count(trip: Dict[str, Any]) -> int:
    leg = first_leg(trip)
    questions = leg.get("losQuestions") or []
    answered = [
        q for q in questions
        if isinstance(q, dict) and str(q.get("answer") or "").strip()
    ]
    return len(answered)


def write_event(event: Dict[str, Any]) -> None:
    try:
        with EVENT_LOG_PATH.open("a") as handle:
            handle.write(json.dumps(event) + "\n")
    except Exception:
        pass


def resolve(
    trip: Dict[str, Any],
    call_type: str,
    clarification: Optional[Dict[str, str]] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Produce the answer block plus the provenance that goes in meta.

    Returns (block, source). The block always has the four required fields, so
    everything downstream is engine agnostic.
    """
    if USE_MODEL and llm is not None:
        try:
            block = llm.evaluate_trip(trip, clarification)
            return block, {
                "engine": "foundry-model",
                "engineVersion": llm.engine_version(),
                "matchedOn": "model",
                "fixtureName": None,
                "payloadFile": None,
                "responseFile": None,
                "modelError": None,
            }
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            print(f"[med-nec] model call failed: {error}")
            if not FALLBACK_TO_FIXTURE:
                raise
            fixture, match_method = resolve_fixture(trip)
            return fixture[call_type], {
                "engine": "static-fixture-after-model-error",
                "engineVersion": ENGINE_VERSION,
                "matchedOn": match_method,
                "fixtureName": fixture["fixture_name"],
                "payloadFile": fixture["payload_file"],
                "responseFile": fixture[f"{call_type}_file"],
                "modelError": error,
            }

    fixture, match_method = resolve_fixture(trip)
    return fixture[call_type], {
        "engine": "static-fixture",
        "engineVersion": ENGINE_VERSION,
        "matchedOn": match_method,
        "fixtureName": fixture["fixture_name"],
        "payloadFile": fixture["payload_file"],
        "responseFile": fixture[f"{call_type}_file"],
        "modelError": LLM_IMPORT_ERROR,
    }


def envelope(
    trip: Dict[str, Any],
    block: Dict[str, Any],
    source: Dict[str, Any],
    call_type: str,
    received_at: str,
    started: float,
    delay_ms: int,
) -> Dict[str, Any]:
    leg = first_leg(trip)
    if delay_ms > 0:
        time.sleep(delay_ms / 1000.0)
    processing_ms = int((time.perf_counter() - started) * 1000)
    responded_at = utc_now()

    detail = block.get("detail") or {}
    usage = detail.get("usage") or {}

    body = {
        "evaluationId": str(uuid.uuid4()),
        "olosRequestId": trip.get("olosRequestId"),
        "correlationId": trip.get("correlationId"),
        "sourceSystemTripId": trip.get("sourceSystemTripId"),
        "requesterFacilityId": trip.get("requesterFacilityId"),
        "levelOfService": leg.get("levelOfService"),
        "callType": call_type,

        "clinicalSummary": block.get("clinicalSummary"),
        "meetsMedicalNecessity": block.get("meetsMedicalNecessity"),
        "clarifyingQuestion": block.get("clarifyingQuestion"),

        "detail": detail,

        "meta": {
            "service": SERVICE_NAME,
            "serviceVersion": SERVICE_VERSION,
            "engineVersion": source["engineVersion"],
            "knowledgeVersion": KNOWLEDGE_VERSION,
            "inference": source["engine"],
            "fixtureName": source["fixtureName"],
            "fixtureMatchedOn": source["matchedOn"],
            "fixturePayloadFile": source["payloadFile"],
            "fixtureResponseFile": source["responseFile"],
            "modelError": source["modelError"],
            "questionsEvaluated": question_count(trip),
            "inputTokens": usage.get("inputTokens"),
            "outputTokens": usage.get("outputTokens"),
            "receivedAtUtc": received_at,
            "respondedAtUtc": responded_at,
            "processingMs": processing_ms,
        },
    }

    write_event({
        "evaluationId": body["evaluationId"],
        "olosRequestId": body["olosRequestId"],
        "callType": call_type,
        "inference": source["engine"],
        "fixtureName": source["fixtureName"],
        "fixtureResponseFile": source["responseFile"],
        "fixtureMatchedOn": source["matchedOn"],
        "modelError": source["modelError"],
        "meetsMedicalNecessity": body["meetsMedicalNecessity"],
        "clarifyingQuestionReturned": bool(body["clarifyingQuestion"]),
        "inputTokens": usage.get("inputTokens"),
        "outputTokens": usage.get("outputTokens"),
        "receivedAtUtc": received_at,
        "respondedAtUtc": responded_at,
        "processingMs": processing_ms,
    })

    return body


def http_status(source: Dict[str, Any]) -> int:
    """422 only when nothing could answer. A model answer is always 200."""
    if source["engine"].startswith("foundry"):
        return 200
    return 200 if source["matchedOn"] != "none" else 422


@app.on_event("startup")
def startup() -> None:
    build_fingerprint_index()
    if USE_MODEL and llm is None:
        print(f"[med-nec] USE_MODEL is set but llm.py did not import: {LLM_IMPORT_ERROR}")
        print("[med-nec] running on fixtures instead")
    elif USE_MODEL:
        print(f"[med-nec] model engine: {llm.engine_version()}")
        print(f"[med-nec] prompt compiled, {len(llm.build_prompt())} chars")


@app.get("/healthz")
def healthz() -> Dict[str, Any]:
    engine = "foundry-model" if (USE_MODEL and llm is not None) else "static-fixture"
    body = {
        "status": "ok",
        "service": SERVICE_NAME,
        "serviceVersion": SERVICE_VERSION,
        "engineVersion": llm.engine_version() if (USE_MODEL and llm) else ENGINE_VERSION,
        "knowledgeVersion": KNOWLEDGE_VERSION,
        "inference": engine,
        "useModel": USE_MODEL,
        "fallbackToFixture": FALLBACK_TO_FIXTURE,
        "fixturesLoaded": len(FIXTURES),
        "defaultSimulatedLatencyMs": DEFAULT_DELAY_MS,
        "timeUtc": utc_now(),
    }
    if LLM_IMPORT_ERROR:
        body["status"] = "degraded"
        body["modelImportError"] = LLM_IMPORT_ERROR
    return body


@app.get("/v1/engine")
def engine_check() -> JSONResponse:
    """Live connectivity probe. Makes one trivial model call and reports back.

    Hit this before a demo. It separates a configuration problem from a problem
    with the evaluation itself.
    """
    if not USE_MODEL:
        return JSONResponse(status_code=200, content={
            "useModel": False,
            "inference": "static-fixture",
            "message": "USE_MODEL is not set, so no model is called.",
        })
    if llm is None:
        return JSONResponse(status_code=503, content={
            "useModel": True,
            "reachable": False,
            "error": LLM_IMPORT_ERROR,
            "hint": "pip install anthropic azure-identity",
        })

    settings = llm.settings()
    started = time.perf_counter()
    try:
        reply = llm.ping()
    except Exception as exc:
        return JSONResponse(status_code=503, content={
            "useModel": True,
            "reachable": False,
            "settings": settings,
            "error": f"{type(exc).__name__}: {exc}"[:600],
            "hint": llm.diagnose(exc),
        })
    return JSONResponse(status_code=200, content={
        "useModel": True,
        "reachable": True,
        "settings": settings,
        "reply": reply,
        "latencyMs": int((time.perf_counter() - started) * 1000),
    })


@app.get("/v1/fixtures")
def list_fixtures() -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    for request_id, fixture in FIXTURES.items():
        initial = fixture["initial"]
        reeval = fixture["reevaluation"]
        rows.append({
            "fixtureName": fixture["fixture_name"],
            "olosRequestId": request_id,
            "payloadFile": fixture["payload_file"],
            "initial": {
                "responseFile": fixture["initial_file"],
                "meetsMedicalNecessity": initial["meetsMedicalNecessity"],
                "clarifyingQuestionReturned": bool(initial["clarifyingQuestion"]),
            },
            "afterClarification": {
                "responseFile": fixture["reevaluation_file"],
                "meetsMedicalNecessity": reeval["meetsMedicalNecessity"],
            },
        })
    return {
        "count": len(rows),
        "note": (
            "These are the expected outputs for known inputs. With USE_MODEL set they "
            "are no longer returned, but they remain the regression baseline to compare "
            "the model against."
        ),
        "fixtures": rows,
    }


@app.post("/v1/medical-necessity/evaluate")
def evaluate(
    trip: Dict[str, Any],
    delayMs: Optional[int] = Query(None, description="Override the simulated latency for this call."),
) -> JSONResponse:
    received_at = utc_now()
    started = time.perf_counter()
    delay = DEFAULT_DELAY_MS if delayMs is None else max(0, delayMs)

    supplied_question = trip.get("clarifyingQuestion")
    supplied_answer = trip.get("clarifyingAnswer")
    call_type = "reevaluation" if (supplied_question and supplied_answer) else "initial"

    clarification = None
    if call_type == "reevaluation":
        clarification = {"question": supplied_question, "answer": supplied_answer}

    block, source = resolve(trip, call_type, clarification)
    body = envelope(trip, block, source, call_type, received_at, started, delay)
    return JSONResponse(status_code=http_status(source), content=body)


@app.post("/v1/medical-necessity/reevaluate")
def reevaluate(
    request: ReevaluateRequest,
    delayMs: Optional[int] = Query(None, description="Override the simulated latency for this call."),
) -> JSONResponse:
    received_at = utc_now()
    started = time.perf_counter()
    delay = DEFAULT_DELAY_MS if delayMs is None else max(0, delayMs)

    trip = request.tripRequest
    clarification = {
        "question": request.clarification.question,
        "answer": request.clarification.answer,
    }

    block, source = resolve(trip, "reevaluation", clarification)
    body = envelope(trip, block, source, "reevaluation", received_at, started, delay)
    body["clarification"] = clarification
    return JSONResponse(status_code=http_status(source), content=body)
