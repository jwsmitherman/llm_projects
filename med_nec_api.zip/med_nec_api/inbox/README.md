# inbox

Drop trip request JSON files here and run:

```powershell
python run_batch.py --dir .\inbox
```

Every `*.json` in the folder gets posted at the service and the results land in
one workbook alongside them. Nothing else reads this folder, and the name carries
no meaning to the service: `--dir` takes any path, so pointing it straight at the
folder you downloaded from Databricks works just as well.

This exists because the review screen at `/ui` handles one trip at a time, which
is right for looking at a determination closely and wrong for fifty.

Payloads come from `med_nec_payload_builder.ipynb` in Databricks. Real payloads
should not be committed: they carry clinical free text, and while the builder
strips the structured patient fields and holds back anything matching a date of
birth, SSN or MRN pattern, that is a filter rather than a guarantee.
