"""Regenerates med_nec_live_test.ipynb."""

import nbformat as nbf

nb = nbf.v4.new_notebook()
C = []


def md(text):
    C.append(nbf.v4.new_markdown_cell(text.strip()))


def code(text):
    C.append(nbf.v4.new_code_cell(text.strip()))


md("""
# Medical necessity service — live test

Runs the three demo trips through the service and checks what comes back.

Works against either engine. With `USE_MODEL` unset the service answers from the
files in `responses/` and this notebook is a contract test. With `USE_MODEL=true`
the service calls the Claude deployment in Azure AI Foundry and this notebook is
the accuracy test, with the files in `responses/` as the baseline to compare
against.

**Start the service first, in a terminal, from the `med_nec_api` folder:**

```powershell
$env:USE_MODEL = "true"
$env:CLAUDE_BASE_URL = "https://<resource>.services.ai.azure.com/anthropic"
$env:CLAUDE_DEPLOYMENT_NAME = "<deployment-name>"
$env:AZURE_CLIENT_ID = "3a4f14ef-9084-47fb-8ff5-36017fa21f63"
python -m uvicorn app:app --port 8000
```

Leave `USE_MODEL` out and everything below still runs, on the fixture engine.
""")

md("## 1. Settings")

code("""
import json, time
from pathlib import Path
import httpx
import pandas as pd

BASE = "http://127.0.0.1:8000"
TIMEOUT = 120.0

pd.set_option("display.max_colwidth", 90)
pd.set_option("display.width", 200)

ROOT = Path.cwd()
PAYLOADS = ROOT / "payloads"
RESPONSES = ROOT / "responses"

client = httpx.Client(base_url=BASE, timeout=TIMEOUT)
print("target:", BASE)
""")

md("""
## 2. Which engine is answering

Everything below depends on this. `inference` reads `foundry-model` when the model
is answering and `static-fixture` when the pre-written files are.
""")

code("""
health = client.get("/healthz").json()
for key in ["status", "inference", "useModel", "engineVersion",
            "knowledgeVersion", "fixturesLoaded", "fallbackToFixture"]:
    print(f"{key:18}: {health.get(key)}")

if health.get("modelImportError"):
    print("\\nmodel import error:", health["modelImportError"])

LIVE = health.get("inference") == "foundry-model"
print()
print("MODEL" if LIVE else "FIXTURES", "- reading real determinations" if LIVE
      else "- reading pre-written files, no model involved")
""")

md("""
## 3. Connectivity check

One trivial call to the deployment. Run this before a demo. It separates a
configuration problem from a problem with the evaluation itself, and it tells you
exactly which setting is wrong when it fails.
""")

code("""
engine = client.get("/v1/engine").json()
print(json.dumps(engine, indent=2)[:1400])
""")

md("""
## 4. What goes in

The service reads the question and answer pairs from the first trip leg. This is
the structured clinical content the determination rests on — nothing else in the
payload is assessed.
""")

code("""
def load(stem):
    return json.loads((PAYLOADS / f"{stem}.json").read_text())

def pairs_of(trip):
    leg = (trip.get("tripLegs") or [{}])[0]
    rows = []
    for q in leg.get("losQuestions") or []:
        answer = str(q.get("answer") or "").strip()
        if not answer:
            continue
        free = str(q.get("answerValue") or "").strip()
        if free and free.lower() != answer.lower():
            answer = f"{answer}: {free}"
        rows.append({"questionId": q.get("questionId"),
                     "question": str(q.get("questionText") or "").strip()[:70],
                     "answer": answer[:70]})
    return pd.DataFrame(rows)

trip2 = load("trip_2_general_weakness")
print("olosRequestId :", trip2["olosRequestId"])
print("level of service:", trip2["tripLegs"][0].get("levelOfService"))
pairs_of(trip2)
""")

md("""
## 5. One trip, end to end

`evaluate` is what Transport.net calls on submission. Three fields come back at the
top level and those are the only ones the UI acts on.
""")

code("""
started = time.perf_counter()
r = client.post("/v1/medical-necessity/evaluate", json=trip2)
elapsed = int((time.perf_counter() - started) * 1000)
body = r.json()

print("http status  :", r.status_code)
print("round trip   :", elapsed, "ms")
print("server side  :", body["meta"]["processingMs"], "ms")
print("engine       :", body["meta"]["inference"])
print("tokens in/out:", body["meta"]["inputTokens"], "/", body["meta"]["outputTokens"])
print()
print("meetsMedicalNecessity:", body["meetsMedicalNecessity"])
print()
print("clinicalSummary:")
print(" ", body["clinicalSummary"])
print()
print("clarifyingQuestion:")
print(" ", body["clarifyingQuestion"])
""")

md("""
### What the requester would see

`clarifyingQuestion` is `null` when nothing needs asking, which is the signal to
show nothing and let the submission continue.
""")

code("""
q = body["clarifyingQuestion"]
if q:
    print("+" + "-" * 76 + "+")
    print("|  Before this trip can be submitted" + " " * 41 + "|")
    print("+" + "-" * 76 + "+")
    for i in range(0, len(q), 72):
        print("|  " + q[i:i + 72].ljust(73) + "|")
    print("|" + " " * 76 + "|")
    print("|  [                                                      ]  [ Submit ]  |")
    print("+" + "-" * 76 + "+")
else:
    print("No question. Trip submits unchanged, requester sees nothing.")
""")

md("""
## 6. The per question findings

`detail` is what goes to the database rather than the screen. One row per question
and answer pair, each with the criterion it maps to, the citation behind it, and
the verbatim text it rests on.

A criterion the model cannot quote is not documented. That rule is in the
instruction, and the `evidence` column is how you check it held.
""")

code("""
findings = pd.DataFrame(body["detail"].get("questionFindings", []))
if len(findings):
    cols = [c for c in ["questionId", "category", "nonMedNec", "criterionId",
                        "citation", "evidence", "confidence"] if c in findings.columns]
    display(findings[cols])
else:
    print("no questionFindings returned")
""")

code("""
documented = pd.DataFrame(body["detail"].get("criteriaDocumented", []))
print("criteria documented:", len(documented))
display(documented if len(documented) else "none")

exclusions = pd.DataFrame(body["detail"].get("exclusionsTriggered", []))
print("exclusions triggered:", len(exclusions))
display(exclusions if len(exclusions) else "none")

print("determination:", body["detail"].get("determination"))
print("confidence   :", body["detail"].get("confidence"))
print("basis        :", body["detail"].get("basis"))
""")

md("""
## 7. The clarifying answer

The requester types an answer and it goes back for reassessment. Trip 2 is the case
where the answer rescues the trip.
""")

code("""
ANSWERS = {
    "trip_2_general_weakness":
        "Patient had a stroke last week with dense left sided weakness. Cannot sit "
        "upright unsupported and requires two person assist for all transfers.",
    "trip_3_wheelchair_candidate":
        "Patient needs to arrive by their scheduled dialysis chair time.",
    "trip_1_meets": "n/a",
}

answer = ANSWERS["trip_2_general_weakness"]
r2 = client.post("/v1/medical-necessity/reevaluate", json={
    "tripRequest": trip2,
    "clarification": {"question": body["clarifyingQuestion"], "answer": answer},
})
after = r2.json()

print("ANSWERED:", answer)
print()
print(f"{'':14} {'before':<10} {'after':<10}")
print(f"{'meets':14} {str(body['meetsMedicalNecessity']):<10} {str(after['meetsMedicalNecessity']):<10}")
print(f"{'determination':14} {str(body['detail'].get('determination')):<10} {str(after['detail'].get('determination')):<10}")
print(f"{'confidence':14} {str(body['detail'].get('confidence')):<10} {str(after['detail'].get('confidence')):<10}")
print()
print("updated summary:")
print(" ", after["clinicalSummary"])
print()
print("question returned again:", after["clarifyingQuestion"])
""")

md("""
## 8. All three trips

Each trip goes through twice: the initial call, then the clarifying answer. Trip 1
should pass silently, trip 2 should flip to meets, trip 3 should stay as it was
because the answer adds nothing clinical.
""")

code("""
STEMS = ["trip_1_meets", "trip_2_general_weakness", "trip_3_wheelchair_candidate"]
rows, raw = [], {}

for stem in STEMS:
    trip = load(stem)

    t0 = time.perf_counter()
    initial = client.post("/v1/medical-necessity/evaluate", json=trip).json()
    ms_initial = int((time.perf_counter() - t0) * 1000)

    question = initial["clarifyingQuestion"]
    final, ms_final = initial, 0
    if question:
        t0 = time.perf_counter()
        final = client.post("/v1/medical-necessity/reevaluate", json={
            "tripRequest": trip,
            "clarification": {"question": question, "answer": ANSWERS[stem]},
        }).json()
        ms_final = int((time.perf_counter() - t0) * 1000)

    raw[stem] = {"initial": initial, "final": final}
    rows.append({
        "trip": stem.replace("trip_", "").replace("_", " "),
        "meets": initial["meetsMedicalNecessity"],
        "asked": bool(question),
        "after answer": final["meetsMedicalNecessity"] if question else "-",
        "ms 1st": ms_initial,
        "ms 2nd": ms_final or "-",
        "tok in": initial["meta"]["inputTokens"] or "-",
        "tok out": initial["meta"]["outputTokens"] or "-",
        "engine": initial["meta"]["inference"],
    })

summary = pd.DataFrame(rows)
summary
""")

code("""
for stem in STEMS:
    initial = raw[stem]["initial"]
    print("=" * 84)
    print(stem)
    print("=" * 84)
    print("summary :", initial["clinicalSummary"])
    print("meets   :", initial["meetsMedicalNecessity"])
    print("asks    :", initial["clarifyingQuestion"] or "nothing")
    print()
""")

md("""
## 9. Against the baseline

The files in `responses/` are the expected output for each known input. They were
written before the model was available, from the criteria and the meeting examples.

With the model live, every row where `agrees` is False is worth reading. It means
either the criteria file needs work or the baseline was wrong. Both are findings.
""")

code("""
checks = []
for stem in STEMS:
    expected_initial = json.loads((RESPONSES / f"{stem}.initial.json").read_text())
    expected_final = json.loads((RESPONSES / f"{stem}.reevaluation.json").read_text())
    got = raw[stem]

    for label, exp, act in [("initial", expected_initial, got["initial"]),
                            ("after answer", expected_final, got["final"])]:
        exp_meets = exp["meetsMedicalNecessity"]
        act_meets = act["meetsMedicalNecessity"]
        exp_asks = bool(exp["clarifyingQuestion"])
        act_asks = bool(act["clarifyingQuestion"])
        checks.append({
            "trip": stem.replace("trip_", "").replace("_", " "),
            "call": label,
            "expected meets": exp_meets,
            "got meets": act_meets,
            "expected asks": exp_asks,
            "got asks": act_asks,
            "agrees": exp_meets == act_meets and exp_asks == act_asks,
        })

baseline = pd.DataFrame(checks)
print(f"{int(baseline['agrees'].sum())} of {len(baseline)} match the baseline")
baseline
""")

code("""
disagreements = baseline[~baseline["agrees"]].to_dict("records")
if not disagreements:
    print("Every trip matches the baseline.")

for row in disagreements:
    stem = "trip_" + row["trip"].replace(" ", "_")
    key = "initial" if row["call"] == "initial" else "final"
    act = raw[stem][key]
    print("=" * 84)
    print(f"{row['trip']} / {row['call']}")
    print(f"  expected meets={row['expected meets']} asks={row['expected asks']}")
    print(f"  got      meets={row['got meets']} asks={row['got asks']}")
    print()
    print("  basis    :", act["detail"].get("basis"))
    print("  summary  :", act["clinicalSummary"])
    print("  criteria :", [c.get("criterionId") for c in act["detail"].get("criteriaDocumented", [])])
    print("  exclusions:", [e.get("exclusionId") for e in act["detail"].get("exclusionsTriggered", [])])
    print()
""")

md("""
## 10. Latency and cost

What the sizing conversation needs. `processingMs` is server side, so it excludes
the network hop from Transport.net.

A trip that gets a clarifying question costs two calls, not one. Size for that.
""")

code("""
timing = []
for stem in STEMS:
    for label in ["initial", "final"]:
        b = raw[stem][label]
        if label == "final" and b is raw[stem]["initial"]:
            continue
        timing.append({
            "trip": stem.replace("trip_", "").replace("_", " "),
            "call": label,
            "processingMs": b["meta"]["processingMs"],
            "inputTokens": b["meta"]["inputTokens"],
            "outputTokens": b["meta"]["outputTokens"],
        })

t = pd.DataFrame(timing)
display(t)

if t["processingMs"].notna().any():
    print("calls made      :", len(t))
    print("median ms       :", int(t["processingMs"].median()))
    print("slowest ms      :", int(t["processingMs"].max()))
if t["inputTokens"].notna().any():
    print("mean input tok  :", int(t["inputTokens"].dropna().mean()))
    print("mean output tok :", int(t["outputTokens"].dropna().mean()))
    print("calls per trip  :", round(len(t) / len(STEMS), 2))
""")

md("""
## 11. Timeout behaviour

Transport.net holds the submission while the call is in flight and proceeds
unchanged if it does not answer in time. This is that path.
""")

code("""
try:
    httpx.post(f"{BASE}/v1/medical-necessity/evaluate?delayMs=5000",
               json=load("trip_1_meets"), timeout=2.0)
    print("returned in time")
except httpx.TimeoutException:
    print("client timed out at 2s against a 5s response")
    print("Transport.net submits the trip unchanged. No summary, no flag, no question.")
""")

md("""
## 12. Event log

One row per call, standing in for the `request_event_logs` table on the
Transport.net side.
""")

code("""
log_path = ROOT / "request_event_log.jsonl"
if log_path.exists():
    events = pd.DataFrame(json.loads(line) for line in log_path.read_text().splitlines() if line.strip())
    cols = [c for c in ["receivedAtUtc", "callType", "inference", "meetsMedicalNecessity",
                        "clarifyingQuestionReturned", "inputTokens", "outputTokens",
                        "processingMs", "modelError"] if c in events.columns]
    display(events[cols].tail(15))
    print(f"{len(events)} events total")
else:
    print("no event log yet")
""")

md("""
## 13. Where this leaves you

- `meta.inference` on every response says which engine answered, so a demo can
  never silently fall back to a pre-written file without it showing.
- `meta.modelError` is populated when the model was tried and failed. Null means
  it was not tried or it worked.
- Section 9 is the one that matters once the model is live. Disagreement with the
  baseline is the signal to go and look at the criteria file.
- `FALLBACK_TO_FIXTURE=false` turns off the safety net, so a failed model call
  returns an error rather than a pre-written answer. Use that when measuring.
""")

nb["cells"] = C
nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
nb.metadata["language_info"] = {"name": "python", "version": "3.11"}

with open("med_nec_live_test.ipynb", "w") as handle:
    nbf.write(nb, handle)

print(f"written: {len(C)} cells, {sum(1 for c in C if c.cell_type == 'code')} code")
