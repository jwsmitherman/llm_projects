# Medical Necessity POV - Databricks Scripts

A minimal, runnable pipeline to prove out AI-driven medical necessity assessment for non-emergent
interfacility ground transport, using synthetic labeled data plus a RAG + few-shot LLM.

## Approach (why this design)

- RAG with ChromaDB holds the medical necessity rules (CMS criteria, level-of-service definitions,
  market scope-of-practice). The LLM retrieves and cites these, which gives auditability and lets
  the rules be updated without changing code. This is the "intelligence layer" your SMEs would own.
- Few-shot examples in the prompt teach the key judgment (for example, "general weakness" alone is
  insufficient; "post-CVA hemiparesis, cannot bear weight" is sufficient).
- Structured JSON output maps one to one to the MVP UI:
  meets_medical_necessity (block submit y/n), clarifying_prompt_for_nurse (the in-line nudge),
  assessed_level_of_service, cited_rules.
- Synthetic data is generated from labeled clinical archetypes. Ground truth is fixed by the
  archetype, not by the model, so you get a clean golden set to measure against.

## Run order

1. 01_generate_synthetic_data.py  - creates a labeled golden set of orders (JSONL + Delta table).
2. 02_build_rag_chromadb.py       - builds the rules knowledge base in ChromaDB.
3. 03_run_llm_assessment.py       - retrieves rules, runs the LLM, scores each order.
4. 04_evaluate_and_report.py      - metrics, confusion matrix, per-archetype, problem cases.

## Databricks setup (do this first in each notebook)

Run these as the first cell, then comment them out:

    %pip install -q chromadb openai pysqlite3-binary pandas
    dbutils.library.restartPython()

The pysqlite3 shim at the top of scripts 02 and 03 is required because Databricks' system sqlite is
often older than what ChromaDB needs.

## Your OpenAI key

Each script has OPENAI_API_KEY = "sk-REPLACE_ME" near the top. Paste your personal key there for now.
Rotate it and move it to a Databricks secret scope before this goes anywhere near production:

    OPENAI_API_KEY = dbutils.secrets.get(scope="med-nec", key="openai")

## Key knobs

- ROWS_PER_ARCHETYPE (script 01): how many synthetic rows per scenario. Start small.
- CHAT_MODEL: gpt-4o for quality, gpt-4o-mini for cheaper/faster first passes.
- TOP_K (script 03): number of rules retrieved per order.
- MAX_ORDERS (script 03): set to a small int to smoke-test before a full run.

## What to look at in the results

- UNSAFE PASSES: the model approved a trip that does not meet medical necessity. These are the ones
  that still get denied downstream. Minimize this first.
- OVER-BLOCKS: the model blocked a legitimate trip. This is friction on customers. Keep it low.
- Per-archetype accuracy shows exactly which clinical patterns need better rules or examples.

## Important caveats

- The rule text in script 02 is ILLUSTRATIVE and simplified. Validate every rule against actual CMS
  guidance, GMR Rev Cycle policy, and each market's scope of practice before any production use. This
  is exactly the SME step from the workshop (Jen Jones / Michelle's team, Integra).
- ChromaDB is persisted to /local_disk0 which is per-cluster and ephemeral. To keep it, copy the
  folder to /dbfs after building (command noted in script 02).
- Frame this as billing/reimbursement decision support, not clinical guidance. That distinction was
  raised as legally important in the strategy discussions.

## How this becomes the real thing

Swap the synthetic generator (01) for a pull of real Transport.net orders (free text + structured
answers) for a couple of markets (MUSC, Texas Health), keep 02-04 as the assessment harness, and
have the medical necessity team hand-label a few hundred trips to replace the archetype labels as
ground truth.
