# Databricks notebook source
# =============================================================================
# 04_evaluate_and_report.py
# GMR / Transport.net - Medical Necessity POV
#
# Reads assessment results and produces the metrics that matter for a POV:
#   - Overall medical-necessity accuracy and level-of-service accuracy
#   - Confusion matrix on "meets medical necessity"
#   - Per-archetype breakdown (where does the model struggle?)
#   - UNSAFE PASSES (approved a non-necessary trip) and OVER-BLOCKS listed out
#
# UNSAFE PASSES are the number to minimize: they are the trips that would still
# get denied downstream. OVER-BLOCKS are friction on legitimate trips.
#
# RUN ORDER: 01 -> 02 -> 03 -> 04
# =============================================================================

# ---- Databricks: run once if needed ------------------------------------------
# %pip install -q pandas
# -----------------------------------------------------------------------------

import json
from collections import defaultdict

# =============================================================================
# CONFIG  <-- EDIT HERE
# =============================================================================
RESULTS_JSONL = "/dbfs/tmp/med_nec/assessment_results.jsonl"
# =============================================================================

rows = []
with open(RESULTS_JSONL) as f:
    for line in f:
        rows.append(json.loads(line))
n = len(rows)
print(f"Loaded {n} assessment results.\n")


# -----------------------------------------------------------------------------
# OVERALL
# -----------------------------------------------------------------------------
mn_acc  = sum(r["mn_correct"] for r in rows) / n
los_acc = sum(r["los_correct"] for r in rows) / n
print("================ OVERALL ================")
print(f"Medical-necessity accuracy: {mn_acc:.1%}")
print(f"Level-of-service accuracy:  {los_acc:.1%}")

# -----------------------------------------------------------------------------
# CONFUSION MATRIX on meets_medical_necessity (ground truth vs prediction)
#   Positive class = "meets MN" (True)
# -----------------------------------------------------------------------------
tp = sum(1 for r in rows if r["gt_meets_mn"] is True  and r["pred_meets_mn"] is True)
tn = sum(1 for r in rows if r["gt_meets_mn"] is False and r["pred_meets_mn"] is False)
fp = sum(1 for r in rows if r["gt_meets_mn"] is False and r["pred_meets_mn"] is True)   # UNSAFE PASS
fn = sum(1 for r in rows if r["gt_meets_mn"] is True  and r["pred_meets_mn"] is False)  # OVER-BLOCK

precision = tp / (tp + fp) if (tp + fp) else 0.0
recall    = tp / (tp + fn) if (tp + fn) else 0.0
f1        = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0

print("\n=========== CONFUSION MATRIX ===========")
print("(positive class = 'meets medical necessity')")
print(f"                     pred: MEETS   pred: NOT")
print(f"  actual MEETS          {tp:>5}       {fn:>5}   (fn = over-blocks)")
print(f"  actual NOT            {fp:>5}       {tn:>5}   (fp = UNSAFE passes)")
print(f"\n  precision={precision:.2f}  recall={recall:.2f}  f1={f1:.2f}")
print(f"  UNSAFE PASSES (fp): {fp}   <-- minimize; these still get denied downstream")
print(f"  OVER-BLOCKS   (fn): {fn}   <-- friction on legitimate trips")


# -----------------------------------------------------------------------------
# PER-ARCHETYPE BREAKDOWN
# -----------------------------------------------------------------------------
by_arch = defaultdict(lambda: {"n": 0, "mn_ok": 0, "los_ok": 0, "unsafe": 0})
for r in rows:
    a = by_arch[r["archetype_id"]]
    a["n"] += 1
    a["mn_ok"]  += int(r["mn_correct"])
    a["los_ok"] += int(r["los_correct"])
    a["unsafe"] += int(r["unsafe_pass"])

print("\n============ PER-ARCHETYPE =============")
print(f"{'archetype':<24}{'n':>4}{'MN acc':>9}{'LOS acc':>9}{'unsafe':>8}")
for arch, a in sorted(by_arch.items()):
    print(f"{arch:<24}{a['n']:>4}{a['mn_ok']/a['n']:>8.0%}{a['los_ok']/a['n']:>9.0%}{a['unsafe']:>8}")


# -----------------------------------------------------------------------------
# LIST THE PROBLEM CASES
# -----------------------------------------------------------------------------
print("\n============ UNSAFE PASSES =============")
unsafe_rows = [r for r in rows if r["unsafe_pass"]]
if not unsafe_rows:
    print("  none - good.")
for r in unsafe_rows:
    print(f"  [{r['archetype_id']} / {r['market']}] req={r['requested_los']} "
          f"pred_los={r['pred_los']}")
    print(f"     note: {r['free_text'][:100]}")
    print(f"     model: {r['pred_reasoning']}\n")

print("============ OVER-BLOCKS (sample) ======")
overblocks = [r for r in rows if r["gt_meets_mn"] is True and r["pred_meets_mn"] is False]
if not overblocks:
    print("  none.")
for r in overblocks[:10]:
    print(f"  [{r['archetype_id']} / {r['market']}] note: {r['free_text'][:90]}")
    print(f"     model: {r['pred_reasoning']}\n")

print("Done.")
