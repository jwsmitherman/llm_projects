# Databricks notebook source
# =============================================================================
# 01_generate_synthetic_data.py
# GMR / Transport.net - Medical Necessity POV
#
# Generates a LABELED synthetic "golden set" of non-emergent IFT ground
# transport orders. Ground truth (meets medical necessity / correct level of
# service) is fixed by the archetype - NOT by the model - so the set is clean
# to measure against later. The LLM is used ONLY to write the natural-language
# nurse free-text note so the narratives look realistic and varied.
#
# Output: a JSONL file + (optionally) a Delta table you can query.
#
# RUN ORDER: 01 -> 02 -> 03 -> 04
# =============================================================================

# ---- Databricks: run this once in its own cell, then comment it out ----------
# %pip install -q openai
# dbutils.library.restartPython()
# -----------------------------------------------------------------------------

import os
import json
import time
import random
import uuid

from openai import OpenAI

# =============================================================================
# CONFIG  <-- EDIT HERE
# =============================================================================
# !!! Personal key hard-coded per your instruction. Rotate / move to a secret
# !!! scope before this ever leaves your machine or goes near production.
OPENAI_API_KEY = "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"

CHAT_MODEL          = "gpt-4o"          # narrative generation; gpt-4o-mini is fine/cheaper
ROWS_PER_ARCHETYPE  = 6                 # ~6 x #archetypes x market variants -> a few hundred rows
RANDOM_SEED         = 42

# Where to write. /dbfs paths are visible from both Python and Spark on Databricks.
OUTPUT_DIR   = "/dbfs/tmp/med_nec"
JSONL_PATH   = f"{OUTPUT_DIR}/synthetic_orders.jsonl"
WRITE_DELTA  = True                     # set False if not on Databricks / no Spark
DELTA_TABLE  = "med_nec_synthetic_orders"
# =============================================================================

random.seed(RANDOM_SEED)
client = OpenAI(api_key=OPENAI_API_KEY)
os.makedirs(OUTPUT_DIR, exist_ok=True)


# -----------------------------------------------------------------------------
# ARCHETYPES: each is a clinically-anchored scenario with FIXED ground truth.
# los = level of service. Values: WHEELCHAIR, BLS, ALS, CCT, NONE
# `markets` lets one archetype expand into market-specific variants where the
# correct answer legitimately differs (scope of practice).
# -----------------------------------------------------------------------------
ARCHETYPES = [
    {
        "archetype_id": "GEN_WEAKNESS_ONLY",
        "requested_los": "BLS",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": False, "special_positioning_cannot_sit": False,
                             "oxygen_lpm": 0, "requires_cardiac_monitoring": False},
        "gt_meets_mn_for_requested": False,
        "gt_correct_los": "WHEELCHAIR",
        "gt_rationale": "'General weakness' with no documented functional deficit does not establish "
                        "that other means of transport are contraindicated. Underlying cause and a "
                        "specific mobility limitation are required.",
        "narrative_quality": "insufficient",
        "clinical_facts": "Nurse only knows the patient seems weak today; no cause documented, "
                          "patient can likely sit."
    },
    {
        "archetype_id": "POST_CVA_HEMIPARESIS",
        "requested_los": "BLS",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": True, "special_positioning_cannot_sit": True,
                             "oxygen_lpm": 0, "requires_cardiac_monitoring": False},
        "gt_meets_mn_for_requested": True,
        "gt_correct_los": "BLS",
        "gt_rationale": "Post-CVA left hemiparesis with inability to bear weight or sit safely; "
                        "supine transport required. Other means contraindicated -> BLS is appropriate.",
        "narrative_quality": "sufficient",
        "clinical_facts": "Post-CVA with dense left hemiparesis, cannot bear weight, cannot sit "
                          "upright unsupported, must be transported supine on a stretcher."
    },
    {
        "archetype_id": "AMBULATORY_DISCHARGE_HOME",
        "requested_los": "BLS",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": False, "special_positioning_cannot_sit": False,
                             "oxygen_lpm": 0, "requires_cardiac_monitoring": False},
        "gt_meets_mn_for_requested": False,
        "gt_correct_los": "NONE",
        "gt_rationale": "Stable, ambulatory patient discharged home; can be transported by wheelchair "
                        "van or private vehicle. Ambulance is not medically necessary.",
        "narrative_quality": "insufficient",
        "clinical_facts": "Patient is stable, walks with a steady gait, going home after observation; "
                          "no clinical reason ambulance is needed."
    },
    {
        "archetype_id": "BED_CONFINED_STRETCHER",
        "requested_los": "BLS",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": True, "special_positioning_cannot_sit": True,
                             "oxygen_lpm": 2, "requires_cardiac_monitoring": False},
        "gt_meets_mn_for_requested": True,
        "gt_correct_los": "BLS",
        "gt_rationale": "Meets all three bed-confined prongs (cannot get up unassisted, cannot "
                        "ambulate, cannot sit in chair/wheelchair); stretcher required.",
        "narrative_quality": "sufficient",
        "clinical_facts": "Bed-confined: cannot get up from bed without assistance, cannot ambulate, "
                          "cannot sit in a wheelchair; on 2 LPM home oxygen (chronic)."
    },
    {
        "archetype_id": "OXYGEN_CHRONIC_ONLY",
        "requested_los": "BLS",
        "markets": ["New York"],
        "structured_flags": {"bed_confined": False, "special_positioning_cannot_sit": False,
                             "oxygen_lpm": 2, "requires_cardiac_monitoring": False},
        "gt_meets_mn_for_requested": False,
        "gt_correct_los": "WHEELCHAIR",
        "gt_rationale": "In NY, chronic/established home oxygen alone (patient not newly requiring O2) "
                        "does not by itself trigger BLS medical necessity; no other deficit documented.",
        "narrative_quality": "ambiguous",
        "clinical_facts": "Patient on long-standing home oxygen 2 LPM, otherwise able to sit; no new "
                          "respiratory event."
    },
    {
        "archetype_id": "DEEP_SUCTION_SCOPE",
        "requested_los": "ALS",
        "markets": ["Texas", "Tennessee"],   # <-- same clinical fact, different correct LOS
        "structured_flags": {"bed_confined": True, "special_positioning_cannot_sit": True,
                             "oxygen_lpm": 4, "requires_cardiac_monitoring": False,
                             "deep_suctioning": True},
        "gt_meets_mn_for_requested": True,     # overridden per-market below
        "gt_correct_los": "ALS",               # overridden per-market below
        "gt_rationale": "Requires deep tracheal suctioning en route. Scope of practice determines LOS: "
                        "ALS in Texas, CCT in Tennessee.",
        "narrative_quality": "sufficient",
        "clinical_facts": "Tracheostomy patient requiring deep tracheal suctioning during transport; "
                          "bed-confined."
    },
    {
        "archetype_id": "CARDIAC_MONITOR_ALS",
        "requested_los": "ALS",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": True, "special_positioning_cannot_sit": True,
                             "oxygen_lpm": 0, "requires_cardiac_monitoring": True},
        "gt_meets_mn_for_requested": True,
        "gt_correct_los": "ALS",
        "gt_rationale": "Requires continuous cardiac monitoring during transport -> ALS assessment/"
                        "intervention -> ALS is appropriate.",
        "narrative_quality": "sufficient",
        "clinical_facts": "Recent NSTEMI, requires continuous cardiac monitoring en route; cannot sit "
                          "unsupported."
    },
    {
        "archetype_id": "VENT_DEPENDENT_CCT",
        "requested_los": "CCT",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": True, "special_positioning_cannot_sit": True,
                             "oxygen_lpm": 0, "requires_cardiac_monitoring": True,
                             "ventilator": True},
        "gt_meets_mn_for_requested": True,
        "gt_correct_los": "CCT",
        "gt_rationale": "Ventilator-dependent with continuous monitoring; requires critical care "
                        "transport crew and equipment -> CCT.",
        "narrative_quality": "sufficient",
        "clinical_facts": "Ventilator-dependent, sedated, continuous monitoring and vent management "
                          "required throughout transport."
    },
    {
        "archetype_id": "DEMENTIA_FLIGHT_RISK",
        "requested_los": "BLS",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": False, "special_positioning_cannot_sit": False,
                             "oxygen_lpm": 0, "requires_cardiac_monitoring": False,
                             "behavioral_flight_risk": True},
        "gt_meets_mn_for_requested": False,
        "gt_correct_los": "WHEELCHAIR",
        "gt_rationale": "Dementia / flight risk alone does not establish that other transport is "
                        "medically contraindicated. Ambulance not justified without a physical "
                        "functional deficit; document why safer alternatives are unsuitable.",
        "narrative_quality": "insufficient",
        "clinical_facts": "History of dementia, occasionally wanders; physically ambulatory and able "
                          "to sit. Nurse selected ambulance to guarantee transport."
    },
    {
        "archetype_id": "IV_DRIP_TITRATION_ALS",
        "requested_los": "ALS",
        "markets": ["Texas"],
        "structured_flags": {"bed_confined": True, "special_positioning_cannot_sit": True,
                             "oxygen_lpm": 2, "requires_cardiac_monitoring": True,
                             "iv_medication_drip": True},
        "gt_meets_mn_for_requested": True,
        "gt_correct_los": "ALS",
        "gt_rationale": "Requires monitored IV medication en route (non-titrated maintenance) plus "
                        "cardiac monitoring -> ALS.",
        "narrative_quality": "sufficient",
        "clinical_facts": "On a maintenance IV antibiotic drip requiring monitoring during transport; "
                          "cardiac monitoring ordered; cannot sit unsupported."
    },
]


# -----------------------------------------------------------------------------
# Per-market ground-truth overrides (scope-of-practice differences).
# -----------------------------------------------------------------------------
MARKET_OVERRIDES = {
    ("DEEP_SUCTION_SCOPE", "Texas"):     {"gt_correct_los": "ALS", "gt_meets_mn_for_requested": True},
    ("DEEP_SUCTION_SCOPE", "Tennessee"): {"gt_correct_los": "CCT", "gt_meets_mn_for_requested": False,
        "gt_rationale": "In Tennessee, deep tracheal suctioning exceeds ALS scope and is CCT; a "
                        "request for ALS does not meet the required level of service."},
}


NURSE_NOTE_SYSTEM = (
    "You role-play a hospital case manager or transfer-center nurse quickly typing the free-text "
    "clinical justification box on a non-emergency ambulance transport order. Write ONLY the note "
    "text (1-3 sentences), realistic and slightly informal, no labels or quotes. Do not explain "
    "medical necessity rules. Match the requested style exactly."
)

QUALITY_STYLE = {
    "sufficient":   "Include the specific underlying diagnosis and the concrete functional limitation "
                    "that justifies the transport. Be clinically specific.",
    "insufficient": "Be vague and minimal the way a rushed nurse would be. Do NOT include the "
                    "underlying cause or a specific functional deficit. Often just a phrase.",
    "ambiguous":    "Include some detail but leave out the single most important justifying fact, so "
                    "it is unclear whether medical necessity is met.",
}


def generate_nurse_note(archetype, market):
    """Use the LLM to write a realistic free-text note. Ground truth is NOT derived from this."""
    user = (
        f"Requested level of service: {archetype['requested_los']}\n"
        f"Market/state: {market}\n"
        f"Underlying clinical situation (for your reference, do not copy verbatim): "
        f"{archetype['clinical_facts']}\n"
        f"Writing style: {QUALITY_STYLE[archetype['narrative_quality']]}\n"
        "Write the free-text note now."
    )
    for attempt in range(4):
        try:
            resp = client.chat.completions.create(
                model=CHAT_MODEL,
                temperature=0.9,
                max_tokens=120,
                messages=[{"role": "system", "content": NURSE_NOTE_SYSTEM},
                          {"role": "user", "content": user}],
            )
            return resp.choices[0].message.content.strip().strip('"')
        except Exception as e:
            wait = 2 ** attempt
            print(f"  note gen retry {attempt+1} ({e}); sleeping {wait}s")
            time.sleep(wait)
    # Fallback so the pipeline never dies on a single failure
    return archetype["clinical_facts"]


def build_records():
    records = []
    for arch in ARCHETYPES:
        for market in arch["markets"]:
            # apply market override to ground truth if present
            gt = {
                "gt_meets_mn_for_requested": arch["gt_meets_mn_for_requested"],
                "gt_correct_los": arch["gt_correct_los"],
                "gt_rationale": arch["gt_rationale"],
            }
            gt.update(MARKET_OVERRIDES.get((arch["archetype_id"], market), {}))

            for _ in range(ROWS_PER_ARCHETYPE):
                note = generate_nurse_note(arch, market)
                records.append({
                    "order_id": str(uuid.uuid4()),
                    "archetype_id": arch["archetype_id"],
                    "market": market,
                    "emergent": False,                       # scope: non-emergent IFT only
                    "requested_los": arch["requested_los"],
                    "structured_flags": arch["structured_flags"],
                    "free_text": note,
                    "narrative_quality": arch["narrative_quality"],
                    # ---- ground truth labels ----
                    "gt_meets_mn_for_requested": gt["gt_meets_mn_for_requested"],
                    "gt_correct_los": gt["gt_correct_los"],
                    "gt_rationale": gt["gt_rationale"],
                })
                print(f"  [{arch['archetype_id']} / {market}] {note[:70]}...")
    return records


# -----------------------------------------------------------------------------
# MAIN
# -----------------------------------------------------------------------------
print("Generating synthetic labeled orders...")
records = build_records()
print(f"\nGenerated {len(records)} records across {len(ARCHETYPES)} archetypes.")

# Write JSONL (portable, no Spark needed)
with open(JSONL_PATH, "w") as f:
    for r in records:
        f.write(json.dumps(r) + "\n")
print(f"Wrote JSONL -> {JSONL_PATH}")

# Optionally write a Delta table for easy querying/labeling review
if WRITE_DELTA:
    try:
        import pandas as pd
        pdf = pd.DataFrame(records)
        # flatten structured_flags to a JSON string column for Delta friendliness
        pdf["structured_flags"] = pdf["structured_flags"].apply(json.dumps)
        sdf = spark.createDataFrame(pdf)                      # noqa: F821 (spark provided by Databricks)
        sdf.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(DELTA_TABLE)
        print(f"Wrote Delta table -> {DELTA_TABLE}")
    except Exception as e:
        print(f"(Skipped Delta write: {e})")

print("\nDone. Next: run 02_build_rag_chromadb.py")
