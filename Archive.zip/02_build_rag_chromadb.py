# Databricks notebook source
# =============================================================================
# 02_build_rag_chromadb.py
# GMR / Transport.net - Medical Necessity POV
#
# Builds the retrieval knowledge base (the "intelligence layer") in ChromaDB.
# These rule chunks are what the LLM will retrieve and CITE when it assesses an
# order. This is the artifact your SMEs (medical necessity / audit team) would
# eventually own and maintain.
#
# >>> IMPORTANT: The rule text below is ILLUSTRATIVE and simplified. Validate
# >>> every rule against actual CMS guidance, GMR Rev Cycle policy, and each
# >>> market's scope-of-practice before any production use.
#
# RUN ORDER: 01 -> 02 -> 03 -> 04
# =============================================================================

# ---- Databricks: run once in its own cell, then comment out ------------------
# %pip install -q chromadb openai pysqlite3-binary
# dbutils.library.restartPython()
# -----------------------------------------------------------------------------

# ChromaDB needs sqlite >= 3.35; Databricks' system sqlite is often older.
# Swap in the modern pysqlite3 build BEFORE importing chromadb.
try:
    __import__("pysqlite3")
    import sys
    sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
except Exception as _e:
    print(f"(pysqlite3 shim not applied: {_e} - continuing)")

import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions

# =============================================================================
# CONFIG  <-- EDIT HERE
# =============================================================================
OPENAI_API_KEY = "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"
EMBED_MODEL    = "text-embedding-3-small"

# Use fast local SSD on Databricks (sqlite-friendly). This is EPHEMERAL per
# cluster. To persist across clusters, copy CHROMA_DIR to /dbfs after building:
#   dbutils.fs.cp("file:/local_disk0/chroma_mednec", "dbfs:/tmp/chroma_mednec", recurse=True)
CHROMA_DIR      = "/local_disk0/chroma_mednec"
COLLECTION_NAME = "med_nec_rules"
# =============================================================================


# -----------------------------------------------------------------------------
# KNOWLEDGE BASE. Each item: (id, text, metadata).
# metadata.market = "ALL" or a specific state; retrieval can be market-filtered.
# -----------------------------------------------------------------------------
RULES = [
    ("MN_CORE",
     "Core principle: non-emergency ambulance transport is medically necessary only when the "
     "patient's condition is such that transport by any other means (wheelchair van, private "
     "vehicle) is contraindicated because it would endanger the patient's health. The bill is "
     "ultimately supported by documentation of the patient's condition at the time of transport.",
     {"source": "CMS", "topic": "core", "market": "ALL"}),

    ("BED_CONFINED",
     "Bed-confined is defined by three criteria that must ALL be met: (1) unable to get up from bed "
     "without assistance, (2) unable to ambulate, and (3) unable to sit in a chair or wheelchair. "
     "Bed-confinement is one factor in the medical-necessity decision; by itself it is neither "
     "sufficient nor strictly required to establish medical necessity.",
     {"source": "CMS", "topic": "bed_confined", "market": "ALL"}),

    ("INSUFFICIENT_TERMS",
     "Vague justifications do NOT establish medical necessity on their own: 'general weakness', "
     "'weakness', 'fall risk', 'unsteady gait', 'deconditioning', 'per protocol', 'convenience', "
     "or 'unable to arrange other transport'. Each requires the underlying diagnosis/cause AND a "
     "specific functional deficit explaining why other transport is contraindicated. Example: "
     "'general weakness' becomes acceptable when documented as 'post-CVA left hemiparesis, unable "
     "to bear weight or sit upright'.",
     {"source": "GMR", "topic": "insufficient_terms", "market": "ALL"}),

    ("SPECIAL_POSITIONING",
     "The single strongest discriminator between wheelchair transport and BLS ambulance is whether "
     "the patient must be transported lying down (supine) and cannot safely sit. If the patient "
     "requires special positioning / cannot sit in a wheelchair for the duration of transport, "
     "stretcher transport (BLS ambulance) is generally appropriate. If the patient can sit safely, "
     "a wheelchair van is the appropriate lower level of service.",
     {"source": "GMR", "topic": "level_of_service", "market": "ALL"}),

    ("WHEELCHAIR_DEF",
     "WHEELCHAIR (wheelchair van) level of service: patient can sit safely for the trip, does not "
     "require medical monitoring or a stretcher, but cannot use a private vehicle unaided. Not an "
     "ambulance service; typically not billable to Medicare as ambulance.",
     {"source": "GMR", "topic": "level_of_service", "market": "ALL"}),

    ("BLS_DEF",
     "BLS (Basic Life Support) ambulance: medically necessary when the patient must be transported "
     "on a stretcher / supine, or needs basic medical monitoring during transport, and other means "
     "are contraindicated. No ALS-level assessment or intervention required.",
     {"source": "GMR", "topic": "level_of_service", "market": "ALL"}),

    ("ALS_DEF",
     "ALS (Advanced Life Support) ambulance: required when the patient needs an ALS assessment or at "
     "least one ALS-level intervention during transport - e.g., continuous cardiac monitoring, "
     "administration/monitoring of IV medications, advanced airway support - within the crew's scope "
     "of practice for that market.",
     {"source": "GMR", "topic": "level_of_service", "market": "ALL"}),

    ("CCT_DEF",
     "CCT (Critical Care Transport): highest level, interfacility only. Required when the patient "
     "needs care beyond ALS scope - e.g., ventilator management, titrated vasoactive drips, or "
     "interventions requiring a critical-care-trained clinician (often RN/paramedic critical care).",
     {"source": "GMR", "topic": "level_of_service", "market": "ALL"}),

    ("CARDIAC_MONITORING",
     "Continuous cardiac monitoring required during transport is an ALS-level indication. A recent "
     "cardiac event (e.g., NSTEMI) with ordered en-route monitoring supports ALS.",
     {"source": "GMR", "topic": "als_indications", "market": "ALL"}),

    ("IV_MEDICATION",
     "Maintenance IV medication that must be monitored during transport is generally an ALS "
     "indication. Titrated or vasoactive drips requiring critical-care management escalate to CCT.",
     {"source": "GMR", "topic": "als_indications", "market": "ALL"}),

    ("VENTILATOR",
     "Ventilator-dependent patients requiring active ventilator management during transport require "
     "CCT in most markets (critical-care crew and equipment). Some markets permit ALS with "
     "vent-trained crew; confirm market scope.",
     {"source": "GMR", "topic": "cct_indications", "market": "ALL"}),

    ("OXYGEN_RULE",
     "Oxygen use alone does not automatically establish BLS medical necessity. Chronic/established "
     "home oxygen in an otherwise ambulatory patient generally does not justify an ambulance. A NEW "
     "oxygen requirement or acute respiratory instability is more supportive of BLS.",
     {"source": "GMR", "topic": "oxygen", "market": "ALL"}),

    ("OXYGEN_NY",
     "New York specific: oxygen use triggers BLS medical necessity under CMS guidance only when the "
     "patient has NOT previously been on oxygen (i.e., a new requirement). Established chronic oxygen "
     "alone does not qualify.",
     {"source": "market", "topic": "oxygen", "market": "New York"}),

    ("SCOPE_DEEP_SUCTION_TX",
     "Texas scope of practice: deep tracheal suctioning during transport is within ALS paramedic "
     "scope. A tracheostomy patient requiring deep suctioning en route is appropriately transported "
     "at the ALS level in Texas.",
     {"source": "market", "topic": "scope_of_practice", "market": "Texas"}),

    ("SCOPE_DEEP_SUCTION_TN",
     "Tennessee scope of practice: deep tracheal suctioning exceeds ALS paramedic scope and is "
     "considered Critical Care (CCT). The same clinical need that is ALS in Texas is CCT in "
     "Tennessee. A request for ALS in Tennessee for deep suctioning does not meet the required "
     "level of service.",
     {"source": "market", "topic": "scope_of_practice", "market": "Tennessee"}),

    ("BEHAVIORAL_RISK",
     "Dementia, confusion, or flight/elopement risk alone does NOT establish ambulance medical "
     "necessity. There must be a physical functional deficit making other transport contraindicated. "
     "Document specifically why a wheelchair van or private vehicle with an escort is unsafe. Note: "
     "at the time of transport the crew may find the patient alert and oriented, contradicting the "
     "order - a known source of denials.",
     {"source": "GMR", "topic": "behavioral", "market": "ALL"}),

    ("FACILITY_PAY_OVERRIDE",
     "If a requested level of service does not meet medical necessity, the workflow offers two paths: "
     "(1) step down to the appropriate lower level of service (e.g., wheelchair), or (2) proceed with "
     "explicit acknowledgment that the transport may not be reimbursable and becomes "
     "facility-responsible (the hospital agrees to pay). This preserves access while protecting "
     "reimbursement.",
     {"source": "GMR", "topic": "workflow", "market": "ALL"}),

    ("PCS_REQUIREMENT",
     "A Physician Certification Statement (PCS / MNC) documents medical necessity and must be signed "
     "for non-emergency scheduled ambulance transport (required for Medicare; for Medicaid in some "
     "states). It may be signed by a physician or an authorized designee (e.g., NP, PA, RN, "
     "discharge planner) but not a clerk.",
     {"source": "CMS", "topic": "documentation", "market": "ALL"}),

    ("GY_MODIFIER",
     "A GY modifier is appended to a claim line when the service is statutorily excluded or does not "
     "meet medical-necessity criteria, signaling expected non-payment. Rising GY-modifier rates are a "
     "denial-risk signal the front-end assessment is meant to reduce.",
     {"source": "GMR", "topic": "billing", "market": "ALL"}),

    ("EMERGENT_SCOPE",
     "Medical-necessity criteria differ for emergent vs non-emergent transport. This assessment "
     "applies to NON-EMERGENT interfacility ground transport only. If a request is flagged emergent, "
     "it is out of scope for this determination.",
     {"source": "GMR", "topic": "scope", "market": "ALL"}),
]


# -----------------------------------------------------------------------------
# BUILD THE COLLECTION
# -----------------------------------------------------------------------------
openai_ef = embedding_functions.OpenAIEmbeddingFunction(
    api_key=OPENAI_API_KEY,
    model_name=EMBED_MODEL,
)

clientdb = chromadb.PersistentClient(
    path=CHROMA_DIR,
    settings=Settings(anonymized_telemetry=False),
)

# Rebuild cleanly each run so the KB always reflects the code above.
try:
    clientdb.delete_collection(COLLECTION_NAME)
    print(f"Deleted existing collection '{COLLECTION_NAME}'.")
except Exception:
    pass

collection = clientdb.create_collection(name=COLLECTION_NAME, embedding_function=openai_ef)

collection.add(
    ids=[r[0] for r in RULES],
    documents=[r[1] for r in RULES],
    metadatas=[r[2] for r in RULES],
)
print(f"Indexed {len(RULES)} rule chunks into '{COLLECTION_NAME}' at {CHROMA_DIR}.")

# -----------------------------------------------------------------------------
# SANITY CHECK
# -----------------------------------------------------------------------------
print("\nSanity query: 'patient is generally weak, wants BLS ambulance'")
res = collection.query(
    query_texts=["patient is generally weak, requesting BLS ambulance"],
    n_results=3,
)
for rid, doc in zip(res["ids"][0], res["documents"][0]):
    print(f"  -> {rid}: {doc[:90]}...")

print("\nDone. Next: run 03_run_llm_assessment.py")
