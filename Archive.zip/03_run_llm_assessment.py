# Databricks notebook source
# =============================================================================
# 03_run_llm_assessment.py
# GMR / Transport.net - Medical Necessity POV
#
# The core inference step. For each synthetic order:
#   1. Retrieve the most relevant rules from ChromaDB (market-aware).
#   2. Build a prompt = system instructions + few-shot examples + retrieved
#      rules + the order.
#   3. Call the LLM and parse a STRUCTURED JSON assessment.
#   4. Compare to ground truth and persist results.
#
# The JSON output maps directly to the MVP:
#   meets_medical_necessity      -> block submit? (false = block)
#   clarifying_prompt_for_nurse  -> the in-line conversational nudge
#   assessed_level_of_service    -> suggested LOS
#   cited_rules                  -> auditability / explainability
#
# RUN ORDER: 01 -> 02 -> 03 -> 04
# =============================================================================

# ---- Databricks: run once in its own cell, then comment out ------------------
# %pip install -q chromadb openai pysqlite3-binary
# dbutils.library.restartPython()
# -----------------------------------------------------------------------------

try:
    __import__("pysqlite3")
    import sys
    sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
except Exception as _e:
    print(f"(pysqlite3 shim not applied: {_e})")

import json
import time

import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions
from openai import OpenAI

# =============================================================================
# CONFIG  <-- EDIT HERE
# =============================================================================
OPENAI_API_KEY = "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"
CHAT_MODEL     = "gpt-4o"                 # gpt-4o-mini is cheaper/faster for a first pass
EMBED_MODEL    = "text-embedding-3-small"

CHROMA_DIR      = "/local_disk0/chroma_mednec"
COLLECTION_NAME = "med_nec_rules"

INPUT_JSONL   = "/dbfs/tmp/med_nec/synthetic_orders.jsonl"
RESULTS_JSONL = "/dbfs/tmp/med_nec/assessment_results.jsonl"
WRITE_DELTA   = True
RESULTS_TABLE = "med_nec_assessment_results"

TOP_K            = 5      # rules retrieved per order
MAX_ORDERS       = None   # set to an int to test on a subset first
# =============================================================================

client   = OpenAI(api_key=OPENAI_API_KEY)
openai_ef = embedding_functions.OpenAIEmbeddingFunction(api_key=OPENAI_API_KEY, model_name=EMBED_MODEL)
clientdb  = chromadb.PersistentClient(path=CHROMA_DIR, settings=Settings(anonymized_telemetry=False))
collection = clientdb.get_collection(name=COLLECTION_NAME, embedding_function=openai_ef)


# -----------------------------------------------------------------------------
# PROMPT PIECES
# -----------------------------------------------------------------------------
SYSTEM_PROMPT = """You are a medical-necessity assessment assistant for NON-EMERGENT interfacility \
ground ambulance ordering on the Transport.net platform. You are a billing/reimbursement decision \
support tool, NOT a clinical-care advisor: you assess whether the documentation supports medical \
necessity and the correct level of service for reimbursement.

Levels of service (LOS), lowest to highest: WHEELCHAIR, BLS, ALS, CCT. NONE means no medical \
transport is necessary (private vehicle acceptable).

Rules:
- Decide using ONLY the RETRIEVED RULES and the order details provided. Do not invent policy.
- Scope of practice varies BY MARKET; honor the market-specific rules provided.
- If the free text is vague (e.g., 'general weakness') and lacks an underlying cause plus a specific \
functional deficit, treat medical necessity as NOT met and ask for the missing detail.
- 'meets_medical_necessity' means: does the REQUESTED level of service meet medical necessity given \
the documentation? If the correct LOS is lower than requested, meets_medical_necessity is false.
- Always cite the rule IDs you relied on.
- Write 'clarifying_prompt_for_nurse' as a short, friendly, actionable question that would let the \
nurse fix the order in place (or empty string if necessity is clearly met).

Respond with ONLY a JSON object, no prose, matching exactly:
{
  "meets_medical_necessity": boolean,
  "assessed_level_of_service": "WHEELCHAIR|BLS|ALS|CCT|NONE",
  "confidence": number,            // 0.0 - 1.0
  "reasoning": string,             // <= 3 sentences
  "missing_information": [string],
  "clarifying_prompt_for_nurse": string,
  "cited_rules": [string],         // rule IDs
  "insufficient_terms_detected": [string]
}"""

# Few-shot examples steer the 'general weakness' judgment. Kept short.
FEWSHOT = [
    {
        "role": "user",
        "content": (
            "MARKET: Texas\nREQUESTED_LOS: BLS\nEMERGENT: false\n"
            "STRUCTURED_FLAGS: {\"bed_confined\": false, \"special_positioning_cannot_sit\": false, "
            "\"oxygen_lpm\": 0}\nFREE_TEXT: \"Pt weak today, needs ambulance to SNF.\"\n"
            "RETRIEVED_RULES:\n[INSUFFICIENT_TERMS] 'general weakness' etc. require an underlying "
            "cause and specific functional deficit.\n[SPECIAL_POSITIONING] stretcher justified only "
            "if patient cannot sit safely."
        ),
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "meets_medical_necessity": False,
            "assessed_level_of_service": "WHEELCHAIR",
            "confidence": 0.82,
            "reasoning": "Only 'weak' is documented with no underlying cause or functional deficit, "
                         "so BLS ambulance necessity is not established. Patient is not documented as "
                         "unable to sit.",
            "missing_information": ["underlying diagnosis/cause of weakness",
                                    "whether patient can sit safely / bear weight"],
            "clarifying_prompt_for_nurse": "What's causing the weakness, and can the patient sit "
                                           "safely in a wheelchair? For example: 'post-CVA "
                                           "hemiparesis, unable to bear weight.'",
            "cited_rules": ["INSUFFICIENT_TERMS", "SPECIAL_POSITIONING"],
            "insufficient_terms_detected": ["weak"],
        }),
    },
    {
        "role": "user",
        "content": (
            "MARKET: Texas\nREQUESTED_LOS: BLS\nEMERGENT: false\n"
            "STRUCTURED_FLAGS: {\"bed_confined\": true, \"special_positioning_cannot_sit\": true, "
            "\"oxygen_lpm\": 0}\nFREE_TEXT: \"Post-CVA w/ dense L hemiparesis, cannot bear weight or "
            "sit upright, must lie supine.\"\nRETRIEVED_RULES:\n[SPECIAL_POSITIONING] stretcher "
            "justified if patient cannot sit safely.\n[BLS_DEF] BLS when supine/stretcher required."
        ),
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "meets_medical_necessity": True,
            "assessed_level_of_service": "BLS",
            "confidence": 0.93,
            "reasoning": "Documented post-CVA hemiparesis with inability to bear weight or sit and a "
                         "requirement for supine transport supports stretcher-level BLS.",
            "missing_information": [],
            "clarifying_prompt_for_nurse": "",
            "cited_rules": ["SPECIAL_POSITIONING", "BLS_DEF"],
            "insufficient_terms_detected": [],
        }),
    },
]


def retrieve_rules(order):
    """Market-aware retrieval: pull rules tagged ALL or this market."""
    query = (
        f"Requested {order['requested_los']} in {order['market']}. "
        f"Flags: {json.dumps(order['structured_flags'])}. "
        f"Note: {order['free_text']}"
    )
    res = collection.query(
        query_texts=[query],
        n_results=TOP_K,
        where={"market": {"$in": ["ALL", order["market"]]}},
    )
    ids  = res["ids"][0]
    docs = res["documents"][0]
    return ids, docs


def build_user_message(order, rule_ids, rule_docs):
    rules_block = "\n".join(f"[{rid}] {doc}" for rid, doc in zip(rule_ids, rule_docs))
    return (
        f"MARKET: {order['market']}\n"
        f"REQUESTED_LOS: {order['requested_los']}\n"
        f"EMERGENT: {str(order['emergent']).lower()}\n"
        f"STRUCTURED_FLAGS: {json.dumps(order['structured_flags'])}\n"
        f"FREE_TEXT: \"{order['free_text']}\"\n"
        f"RETRIEVED_RULES:\n{rules_block}"
    )


def assess_order(order):
    rule_ids, rule_docs = retrieve_rules(order)
    user_msg = build_user_message(order, rule_ids, rule_docs)
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, *FEWSHOT,
                {"role": "user", "content": user_msg}]

    for attempt in range(4):
        try:
            resp = client.chat.completions.create(
                model=CHAT_MODEL,
                temperature=0.0,
                response_format={"type": "json_object"},
                messages=messages,
            )
            parsed = json.loads(resp.choices[0].message.content)
            parsed["_retrieved_rule_ids"] = rule_ids
            return parsed
        except Exception as e:
            wait = 2 ** attempt
            print(f"  assess retry {attempt+1} ({e}); sleeping {wait}s")
            time.sleep(wait)
    return {"meets_medical_necessity": None, "assessed_level_of_service": None,
            "reasoning": "ASSESSMENT_FAILED", "_retrieved_rule_ids": rule_ids}


# -----------------------------------------------------------------------------
# LOAD ORDERS
# -----------------------------------------------------------------------------
orders = []
with open(INPUT_JSONL) as f:
    for line in f:
        orders.append(json.loads(line))
if MAX_ORDERS:
    orders = orders[:MAX_ORDERS]
print(f"Loaded {len(orders)} orders.")


# -----------------------------------------------------------------------------
# RUN
# -----------------------------------------------------------------------------
results = []
for i, order in enumerate(orders, 1):
    pred = assess_order(order)

    pred_meets = pred.get("meets_medical_necessity")
    pred_los   = pred.get("assessed_level_of_service")
    mn_correct  = (pred_meets == order["gt_meets_mn_for_requested"])
    los_correct = (pred_los == order["gt_correct_los"])
    # "unsafe pass": model approved (meets=True) but ground truth says it does NOT meet MN
    unsafe_pass = (pred_meets is True and order["gt_meets_mn_for_requested"] is False)

    results.append({
        "order_id": order["order_id"],
        "archetype_id": order["archetype_id"],
        "market": order["market"],
        "requested_los": order["requested_los"],
        "free_text": order["free_text"],
        "gt_meets_mn": order["gt_meets_mn_for_requested"],
        "gt_correct_los": order["gt_correct_los"],
        "pred_meets_mn": pred_meets,
        "pred_los": pred_los,
        "pred_confidence": pred.get("confidence"),
        "pred_reasoning": pred.get("reasoning"),
        "clarifying_prompt": pred.get("clarifying_prompt_for_nurse"),
        "cited_rules": pred.get("cited_rules"),
        "retrieved_rules": pred.get("_retrieved_rule_ids"),
        "mn_correct": mn_correct,
        "los_correct": los_correct,
        "unsafe_pass": unsafe_pass,
    })

    flag = "  <-- UNSAFE PASS" if unsafe_pass else ("" if mn_correct else "  <-- MN MISS")
    print(f"[{i}/{len(orders)}] {order['archetype_id']:<22} req={order['requested_los']:<4} "
          f"pred_meets={pred_meets} pred_los={pred_los}{flag}")


# -----------------------------------------------------------------------------
# QUICK METRICS (full report is in script 04)
# -----------------------------------------------------------------------------
n = len(results)
mn_acc  = sum(r["mn_correct"] for r in results) / n
los_acc = sum(r["los_correct"] for r in results) / n
unsafe  = sum(r["unsafe_pass"] for r in results)
print("\n================ SUMMARY ================")
print(f"Orders assessed:            {n}")
print(f"Medical-necessity accuracy: {mn_acc:.1%}")
print(f"Level-of-service accuracy:  {los_acc:.1%}")
print(f"UNSAFE passes (approved a non-necessary trip): {unsafe}  <-- watch this number")
print("=========================================")


# -----------------------------------------------------------------------------
# PERSIST
# -----------------------------------------------------------------------------
with open(RESULTS_JSONL, "w") as f:
    for r in results:
        f.write(json.dumps(r) + "\n")
print(f"Wrote results JSONL -> {RESULTS_JSONL}")

if WRITE_DELTA:
    try:
        import pandas as pd
        pdf = pd.DataFrame(results)
        for col in ["cited_rules", "retrieved_rules"]:
            pdf[col] = pdf[col].apply(lambda x: json.dumps(x) if x is not None else None)
        spark.createDataFrame(pdf).write.mode("overwrite") \
            .option("overwriteSchema", "true").saveAsTable(RESULTS_TABLE)   # noqa: F821
        print(f"Wrote Delta table -> {RESULTS_TABLE}")
    except Exception as e:
        print(f"(Skipped Delta write: {e})")

print("\nDone. Next: run 04_evaluate_and_report.py")
