"""Builds the review workbook from a completed batch run.

The sheets exist because of what was asked for in the 29 October review:

  "is there a way to take this blob and turn it into structured data so that we
   can easily see what the input was? Because you can't at scale look at this."

  "I want to look at this for 1000 calls, but in a spreadsheet or somewhere we
   can quickly go through a whole bunch together over an hour or two."

  "here's the question, here's the answer, whether it met the criteria, the
   evidence, the reason, and then the confidence level."

The 6 November review changed the shape of it:

  Dave: "I think these are independent. I think we should score on each category
   for each trip, because one trip could be that they could have an altered LOC,
   they could be unconscious, and they could also have a mobility restriction."

  Dave: "If there's a way to pull all this together into a way that we can just
   look it up really succinctly for each one, and then look at 51 after the
   other ... we need it in a way that we can hit a whole bunch of these one
   after the other without jumping around."

  Mukund: "if possible, break down the EPCR data into the columns so that we
   have that ready to view, not just as a blob."

So: Review is one row per trip holding everything, and it is the first tab.
Each category is scored on its own rather than one category winning the trip.
The ePCR arrives as columns. The older tabs are unchanged underneath, because
they are still the ones to sort and pivot.

Not changed, on purpose. Dave on the clarifying-question wording: "I'm not
ready to change anything. We should review a whole bunch of these at scale, and
then figure out if a pattern emerges." The prompts are untouched here.
"""

import re
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
from openpyxl.styles import Alignment

# Origin and destination codes read as words, so a reviewer is not decoding
# letters. These are the CMS modifiers.
MODIFIERS = {
    "H": "Hospital", "S": "Skilled nursing facility", "P": "Physician office",
    "R": "Residence", "E": "Residential/domiciliary/custodial facility",
    "N": "Skilled nursing facility", "D": "Diagnostic or therapeutic site",
    "J": "Freestanding ESRD facility", "G": "Hospital-based ESRD facility",
    "X": "Intermediate stop", "I": "Site of transfer",
}

# The three categories Dave kept returning to. Keyword matched here, NOT decided
# by the model, and the column says so in its header.
#
# Terms are matched on word boundaries against text normalised to plain words,
# so "altered_mental" (a criterion id) and "Altered mental status?" (the question
# a nurse sees) both match the same entry. Writing these with underscores and
# matching them raw was the earlier defect: every finding whose only clue was in
# prose fell through to administrative.
CATEGORIES = {
    "mobility": ("bed confined", "bed confinement", "bedbound", "bed bound",
                 "cannot sit", "sit safely", "mobility", "ambulate", "ambulatory",
                 "non ambulatory", "stretcher", "gurney", "contraindicated other means",
                 "weight bearing", "transfer assist", "person assist", "assist",
                 "contracture", "positioning", "wheelchair", "hoyer", "lift",
                 "bariatric", "fall risk", "immobile"),
    "monitoring": ("cardiac", "iv", "intravenous", "oxygen", "o2", "airway",
                   "suction", "ventilator", "vent", "trach", "bipap", "cpap",
                   "medication", "medications", "vitals", "vital signs", "monitor",
                   "monitoring", "monitored", "infusion", "drip", "pump",
                   "restraint", "restraints", "telemetry", "ecg", "ekg", "spo2",
                   "saturation", "titrate", "wound", "drain", "isolation"),
    "mentation": ("altered mental", "altered loc", "mental status", "sedation",
                  "sedated", "confusion", "confused", "unresponsive", "unconscious",
                  "behavioral", "psychiatric", "psych", "consciousness", "gcs",
                  "mentation", "oriented", "orientation", "a o", "dementia",
                  "delirium", "agitated", "agitation", "combative", "sitter",
                  "edo", "emergency detention"),
}

CATEGORY_PATTERNS = {
    name: [re.compile(r"\b" + re.escape(term) + r"\b") for term in terms]
    for name, terms in CATEGORIES.items()
}

CATEGORY_ORDER = ["mobility", "mentation", "monitoring", "administrative"]


def _words(*parts: Any) -> str:
    """Lower case, punctuation to spaces. "A&O x1-2" -> " a o x1 2 "."""
    return " " + re.sub(r"[^a-z0-9]+", " ", " ".join(
        str(p or "") for p in parts).lower()).strip() + " "


def categories_for(criterion_id, question, answer, evidence=None,
                   reason=None) -> List[str]:
    """Every category a finding touches, not just the first one matched.

    Dave, 6 November: "these are independent ... one trip could be that they
    could have an altered LOC, they could be unconscious, and they could also
    have a mobility restriction."

    A finding naming both a stretcher and cardiac monitoring belongs in mobility
    AND monitoring. Returning one primary category lost the second, which is
    what the review found. The model's quoted evidence counts too, because that
    is where the second category usually shows up: the question asks about
    special handling, the quote is what the handling was.
    """
    haystack = _words(criterion_id, question, answer, evidence, reason)
    hits = [name for name, patterns in CATEGORY_PATTERNS.items()
            if any(p.search(haystack) for p in patterns)]
    return hits or ["administrative"]


_NEGATIVE = re.compile(
    r"^(no|none|n a|not applicable|negative|denies|unknown|nil|false|0)\b")


def is_negative(answer: Any) -> bool:
    """Whether an answer says the thing was not the case.

    Deliberately narrow: it reads the start of the answer only, so "No" and
    "No (Discharge, Behavioral Transfer or Other Reason)" both count, while an
    answer that happens to contain the word "no" further in does not.
    """
    text = _words(answer).strip()
    return bool(text) and bool(_NEGATIVE.match(text))


def score_category(findings: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Roll a category's findings up into one score.

    Derived here from what the model already returned per question. The model is
    not asked to score categories, so nothing about the determination changes.

    2  supports    a criterion in this category is documented and cited
    1  insufficient the category is addressed, but not enough on its own
    0  not documented, or asked and answered no

    A category is matched on the words in the question, so a question that names
    the category and is answered "No" lands here too: the EDO question on every
    Texas order mentions detention whatever the answer, and an answer listing
    "Behavioral Transfer" among its options mentions behaviour even when that
    option was not the one chosen. Scoring those 1 would read as "addressed but
    short", which is wrong. Asked and answered no is 0.
    """
    if not findings:
        return {"score": 0, "label": "not documented", "confidence": None,
                "evidence": "", "criteria": ""}

    supporting = [f for f in findings if f.get("nonMedNec") is False
                  and (f.get("criterionId") or f.get("evidence"))]
    if supporting:
        best = supporting
        score, label = 2, "supports"
    elif all(is_negative(f.get("answer")) for f in findings):
        best = findings
        score, label = 0, "asked, answered no"
    else:
        best = findings
        score, label = 1, "insufficient"

    rank = {"High": 3, "Medium": 2, "Low": 1}
    confidence = max((f.get("confidence") for f in best if f.get("confidence")),
                     key=lambda c: rank.get(c, 0), default=None)

    return {
        "score": score,
        "label": label,
        "confidence": confidence,
        "evidence": " | ".join(str(f.get("evidence")) for f in best
                               if f.get("evidence"))[:600],
        "criteria": ", ".join(sorted({str(f.get("criterionId")) for f in best
                                      if f.get("criterionId")})),
    }


def question_of(pair: Dict[str, Any]) -> Any:
    """The question text, whichever key the pair came in under.

    The parser emits "question"; the structured losQuestions path emits
    "questionText". Reading only one of them left every Q column blank for
    production orders, which is the other half of the "question = None" Dave
    saw in the workbook: the first half was the parser, this was the reader.
    """
    return pair.get("question") or pair.get("questionText")


def duplicate_flag(r: Dict[str, Any]) -> str:
    """Whether this trip was submitted more than once, and whether it mattered.

    Josh found these by hand: two payloads under one trip id. Only the latest is
    scored, so the distinction a reviewer needs is whether the earlier
    submission said something different.
    """
    count = r.get("payloadCount") or 1
    if count <= 1:
        return ""
    variants = r.get("payloadVariants") or 1
    if variants > 1:
        return f"YES, {count} submissions, {variants} differ"
    return f"resubmitted {count}x, identical"


# Columns the ePCR extract may carry that no reviewer needs and that would put
# identifiers back into a workbook people email around. The extract is scrubbed
# for identifier patterns inside free text, not column by column, so this is the
# column-level half of that. Substring match, case-insensitive, deny by name.
RECORD_WITHHOLD = (
    "name", "dob", "birth", "ssn", "mrn", "address", "street", "city", "zip",
    "postal", "phone", "email", "insur", "payer", "payor", "payment", "policy",
    "member", "subscriber", "account", "guarantor", "medicaid", "medicare",
    "licen", "crew", "employee", "unit_number", "vehicle",
)

# Shown first, in this order, because this is what decides the verdict. Anything
# else the extract carries follows, so the tab is the whole record rather than a
# curated slice of it.
RECORD_LEAD = [
    "EPCR_Level_Of_Care_Provided", "EPCR_Transport_Method",
    "EPCR_Primary_Impression", "EPCR_Secondary_Impressions",
    "EPCR_Chief_Complaint", "EPCR_Working_Diagnosis",
    "EPCR_Procedures_Performed", "EPCR_Medications_Given",
    "EPCR_Initial_SBP", "EPCR_Initial_DBP", "EPCR_Initial_Heart_Rate",
    "EPCR_Initial_Respiratory_Rate", "EPCR_Initial_SpO2", "EPCR_Initial_GCS",
    "EPCR_Patient_Evaluation_Care", "EPCR_Medical_Surgical_History",
    "EPCR_Current_Medications", "EPCR_Reason_For_Destination",
    "EPCR_Narrative",
]


def record_columns(seen: Dict[str, Any]) -> Dict[str, Any]:
    """The ePCR row broken into its own columns, lead fields first.

    Mukund, 6 November: "if possible, break down the EPCR data into the columns
    so that we have that ready to view, not just as a blob."
    """
    ACRONYMS = {"sbp": "SBP", "dbp": "DBP", "hr": "HR", "spo2": "SpO2",
                "gcs": "GCS", "bp": "BP", "ekg": "ECG", "ecg": "ECG",
                "bls": "BLS", "als": "ALS", "iv": "IV", "los": "LOS",
                "epcr": "ePCR", "id": "id"}

    def label(field: str) -> str:
        words = field.replace("EPCR_", "").replace("TNET_", "").split("_")
        out = [ACRONYMS.get(w.lower(), w.lower()) for w in words if w]
        return " ".join(out)[:1].upper() + " ".join(out)[1:]

    out: Dict[str, Any] = {}
    for field in RECORD_LEAD:
        if field in seen:
            out[label(field)] = seen.get(field)
    # The trip id is already the first column of every tab.
    rest = [f for f in seen
            if f not in RECORD_LEAD
            and "triprequestid" not in f.lower()
            and not any(bad in f.lower() for bad in RECORD_WITHHOLD)]
    for field in sorted(rest):
        out.setdefault(label(field), seen.get(field))
    return out


def agreement(order_meets, record_meets) -> str:
    if order_meets is None or record_meets is None:
        return "no record verdict"
    if order_meets == record_meets:
        return "agree"
    return "order meets, record does not" if order_meets else "record meets, order does not"


def build(results: List[Dict[str, Any]], out_path: Path, scored: bool) -> Path:
    trips, findings, answers, records_rows, deid, review = [], [], [], [], [], []

    for r in results:
        trip_id = r["tripRequestId"]
        order = (r.get("order") or {}).get("body") or {}
        record = (r.get("record") or {}).get("body") or {}
        od = order.get("detail") or {}
        rd = record.get("detail") or {}
        meta = order.get("meta") or {}

        order_meets = order.get("meetsMedicalNecessity")
        record_meets = record.get("meetsMedicalNecessity") if r.get("record") else None

        # Every finding lands in every category it touches, then each category
        # is scored on its own. A finding naming a stretcher and cardiac
        # monitoring counts in mobility and in monitoring.
        by_category: Dict[str, List[Dict[str, Any]]] = {c: [] for c in CATEGORY_ORDER}
        for f in (od.get("questionFindings") or []):
            for name in categories_for(f.get("criterionId"), f.get("question"),
                                       f.get("answer"), f.get("evidence"),
                                       f.get("reason")):
                by_category[name].append(f)
        scores = {c: score_category(by_category[c]) for c in CATEGORY_ORDER}

        category_columns: Dict[str, Any] = {}
        for c in CATEGORY_ORDER:
            category_columns[f"{c.title()}: score"] = scores[c]["score"]
            category_columns[f"{c.title()}: finding"] = scores[c]["label"]
            category_columns[f"{c.title()}: confidence"] = scores[c]["confidence"]
            category_columns[f"{c.title()}: evidence"] = scores[c]["evidence"]
        category_columns["Categories supporting"] = sum(
            1 for c in CATEGORY_ORDER if scores[c]["score"] == 2)
        category_columns["Category score total"] = sum(
            scores[c]["score"] for c in CATEGORY_ORDER)

        trips.append({
            "Trip request id": trip_id,
            "Order submitted": r.get("orderedAt"),
            "Level of service": r.get("levelOfService"),
            "Trip type": r.get("tripType"),
            "Origin": MODIFIERS.get(str(r.get("pickupCode") or "").upper(), ""),
            "Destination": MODIFIERS.get(str(r.get("dropoffCode") or "").upper(), ""),
            "Trip reason": r.get("tripReason"),
            "Answers on the order": len(r.get("pairs") or []),
            "Payloads for this trip": r.get("payloadCount", 1),
            "Duplicate payloads": duplicate_flag(r),
            **category_columns,
            "Order: meets": order_meets,
            "Order: determination": od.get("determination"),
            "Order: confidence": od.get("confidence"),
            "Order: summary": order.get("clinicalSummary"),
            "Order: basis": od.get("basis"),
            "Order: clarifying question": order.get("clarifyingQuestion"),
            "Record: meets": record_meets,
            "Agreement": agreement(order_meets, record_meets),
            "Facility pay reason": r.get("facilityPayReason"),
            "Order ms": (r.get("order") or {}).get("ms"),
            "Record ms": (r.get("record") or {}).get("ms"),
            "Tokens in": meta.get("inputTokens"),
            "Tokens out": meta.get("outputTokens"),
            "Error": r.get("error"),
        })

        for f in (od.get("questionFindings") or []):
            question, answer = f.get("question") or "", f.get("answer") or ""
            hits = categories_for(f.get("criterionId"), question, answer,
                                  f.get("evidence"), f.get("reason"))
            findings.append({
                "Trip request id": trip_id,
                "Level of service": r.get("levelOfService"),
                "Trip type": r.get("tripType"),
                "Categories (derived, not the model)": ", ".join(hits),
                "Question": question,
                "Answer": answer,
                "Supports necessity": f.get("nonMedNec") is False,
                "Bearing": f.get("category"),
                "Criterion": f.get("criterionId"),
                "Evidence quoted": f.get("evidence"),
                "Reason": f.get("reason"),
                "Confidence": f.get("confidence"),
                "Citation": f.get("citation"),
            })

        if r.get("record"):
            sel = rd.get("selection") or {}
            seen = r.get("recordFields") or {}
            records_rows.append({
                "Trip request id": trip_id,
                "Record matched": sel.get("epcrMatched"),
                "Record: meets": record_meets,
                "Record: determination": rd.get("determination"),
                "Record: confidence": rd.get("confidence"),
                "Record: summary": record.get("clinicalSummary"),
                "Record: basis": rd.get("basis"),
                "Record: strongest evidence": rd.get("strongestEvidence"),
                "Documentation gaps": " | ".join(record.get("documentationGaps") or []),
                "Order: meets": order_meets,
                "Agreement": agreement(order_meets, record_meets),
                # The record itself, one field per column, so a reviewer can
                # judge the verdict without opening the source extract.
                **record_columns(seen),
                "Fields read": sel.get("populated"),
                "Fields offered": sel.get("offered"),
                "Fields withheld": sel.get("withheld"),
                "Record ms": (r.get("record") or {}).get("ms"),
                "Record tokens in": (record.get("meta") or {}).get("inputTokens"),
                "Record tokens out": (record.get("meta") or {}).get("outputTokens"),
                "Error": (r.get("record") or {}).get("error"),
            })

        flat = {"Trip request id": trip_id,
                "Order submitted": r.get("orderedAt"),
                "Level of service": r.get("levelOfService"),
                "Trip type": r.get("tripType")}
        for i, pair in enumerate(r.get("pairs") or [], 1):
            flat[f"Q{i}"] = question_of(pair)
            flat[f"A{i}"] = pair.get("answer")
        answers.append(flat)

        rep = r.get("deid") or {}
        deid.append({
            "Trip request id": trip_id,
            "Patient fields cleared": ", ".join(rep.get("patientFieldsCleared") or []),
            "Identifying fields dropped": len(rep.get("droppedTop") or []) + len(rep.get("droppedLeg") or []),
            "Free text masked in": ", ".join(rep.get("maskedIn") or []),
            "Patterns hit": ", ".join(rep.get("patternsHit") or []),
            "UNKNOWN fields (classify these)": ", ".join(
                (rep.get("unknownTop") or []) + (rep.get("unknownLeg") or [])),
            "Held back": "YES" if r.get("leak") else "",
        })

        # One row per trip holding everything about it, so a reviewer works down
        # the list rather than across tabs. Dave, 6 November: "we need it in a way
        # that we can hit a whole bunch of these one after the other without
        # jumping around."
        row: Dict[str, Any] = {
            "Trip request id": trip_id,
            "Order submitted": r.get("orderedAt"),
            "Level of service": r.get("levelOfService"),
            "Trip type": r.get("tripType"),
            "Origin": MODIFIERS.get(str(r.get("pickupCode") or "").upper(), ""),
            "Destination": MODIFIERS.get(str(r.get("dropoffCode") or "").upper(), ""),
            "Trip reason": r.get("tripReason"),
            "Duplicate payloads": duplicate_flag(r),
        }
        for c in CATEGORY_ORDER:
            row[f"{c.title()}: score"] = scores[c]["score"]
            row[f"{c.title()}: finding"] = scores[c]["label"]
        row.update({
            "ORDER: meets": order_meets,
            "ORDER: determination": od.get("determination"),
            "ORDER: confidence": od.get("confidence"),
            "ORDER: summary": order.get("clinicalSummary"),
            "ORDER: basis": od.get("basis"),
            "ORDER: clarifying question": order.get("clarifyingQuestion"),
            "RECORD: meets": record_meets,
            "RECORD: determination": rd.get("determination"),
            "RECORD: summary": record.get("clinicalSummary"),
            "RECORD: strongest evidence": rd.get("strongestEvidence"),
            "RECORD: documentation gaps": " | ".join(record.get("documentationGaps") or []),
            "Agreement": agreement(order_meets, record_meets),
            # Reviewer's own columns. Written empty on purpose: this is where the
            # human verdict goes, next to the model's, for the agreement count.
            "SME: meets (your call)": "",
            "SME: notes": "",
        })
        # The order's own answers, then the record, each in its own column. The
        # widest trip sets the column count; pandas fills the rest.
        for i, pair in enumerate(r.get("pairs") or [], 1):
            row[f"Q{i}"] = question_of(pair)
            row[f"A{i}"] = pair.get("answer")
        if r.get("record"):
            for name, value in record_columns(r.get("recordFields") or {}).items():
                row[f"ePCR {name}"] = value
        review.append(row)

    trips_df = pd.DataFrame(trips)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        # Review first, because it is the tab the reviewer actually works in.
        # The rest stay as they were: the same numbers, split by concern, for
        # anyone who wants to sort or pivot one part of it.
        pd.DataFrame(review).to_excel(writer, sheet_name="Review", index=False)
        trips_df.to_excel(writer, sheet_name="Trips", index=False)
        pd.DataFrame(answers).to_excel(writer, sheet_name="Order answers", index=False)
        if records_rows:
            pd.DataFrame(records_rows).to_excel(writer, sheet_name="ePCR", index=False)
        elif scored:
            # Written empty rather than omitted: a missing tab looks like a bug,
            # a tab saying why is an answer.
            pd.DataFrame([{
                "Trip request id": "",
                "Note": "No patient care record matched any trip in this run. Either "
                        "actual_pcr\\ is empty, or the ePCR extract covers different "
                        "trips than the payload export. The run output says which.",
            }]).to_excel(writer, sheet_name="ePCR", index=False)
        if scored:
            pd.DataFrame(findings).to_excel(writer, sheet_name="Question findings", index=False)
            disagree = trips_df[trips_df["Agreement"].isin(
                ["order meets, record does not", "record meets, order does not"])]
            disagree.to_excel(writer, sheet_name="Disagreements", index=False)
        pd.DataFrame(deid).to_excel(writer, sheet_name="De-identification", index=False)

        for name, sheet in writer.sheets.items():
            # Review scrolls a long way right, so the trip id stays put with the
            # header. Everywhere else the header alone is enough.
            sheet.freeze_panes = "B2" if name == "Review" else "A2"
            sheet.auto_filter.ref = sheet.dimensions
            for column in sheet.columns:
                letter = column[0].column_letter
                header = str(column[0].value or "")
                width = max((len(str(c.value)) for c in column[:60] if c.value), default=10)
                # Score columns stay narrow enough that the four sit together on
                # screen; prose columns are capped and wrapped rather than wide.
                cap = 14 if header.endswith((": score", ": finding")) else 60
                sheet.column_dimensions[letter].width = min(max(width + 2, 12), cap)
                if width > cap:
                    for cell in column[1:]:
                        cell.alignment = Alignment(wrap_text=True, vertical="top")

    return out_path
