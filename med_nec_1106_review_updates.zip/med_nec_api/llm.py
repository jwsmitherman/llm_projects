"""Real model evaluation, replacing the static fixtures.

Drops into the med_nec_api folder next to app.py. Returns the same shape a
fixture block returns, so app.py's envelope needs no change.

    CLAUDE_BASE_URL         https://<resource>.services.ai.azure.com/anthropic
    CLAUDE_DEPLOYMENT_NAME  the deployment name, not the model id
    AZURE_CLIENT_ID         the managed identity client id
"""

import inspect
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:  # use the OS certificate store, so corporate TLS inspection is trusted
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass

from anthropic import Anthropic
from anthropic.resources import messages as anthropic_messages
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

log = logging.getLogger("med-nec.llm")

SCOPE = "https://ai.azure.com/.default"

PROMPTS_DIR = Path(__file__).parent / "prompts"
KNOWLEDGE_PATH = PROMPTS_DIR / "med_nec_knowledge.json"
TEMPLATE_PATH = PROMPTS_DIR / "system_prompt.md"
EPCR_TEMPLATE_PATH = PROMPTS_DIR / "epcr_prompt.md"
EPCR_FIELDS_PATH = PROMPTS_DIR / "epcr_fields.json"

# anthropic 1.15 dropped `temperature` from the typed signature of
# messages.create(). Determinism matters for a coverage determination, so where
# the SDK no longer takes it, send it in the request body instead. If the
# endpoint rejects that, _TEMPERATURE_MODE turns itself off for the process and
# the call is retried once without it.
_SDK_TAKES_TEMPERATURE = "temperature" in inspect.signature(
    anthropic_messages.Messages.create).parameters
_TEMPERATURE_MODE = "typed" if _SDK_TAKES_TEMPERATURE else "body"

MAX_TOKENS = int(os.environ.get("CLAUDE_MAX_TOKENS", "4000"))
TEMPERATURE = float(os.environ.get("CLAUDE_TEMPERATURE", "0"))

_client = None
_prompt_cache: Optional[str] = None
_epcr_prompt_cache: Optional[str] = None
_knowledge_cache: Optional[Dict[str, Any]] = None
_epcr_spec_cache: Optional[Dict[str, Any]] = None


class AnthropicIdentity(Anthropic):
    def __init__(self, *, azure_ad_token_provider, base_url, **kwargs):
        self._token_provider = azure_ad_token_provider
        super().__init__(auth_token="placeholder", api_key=None, base_url=base_url, **kwargs)

    @property
    def auth_token(self):
        return self._token_provider()

    @auth_token.setter
    def auth_token(self, value):
        return


def get_client() -> Anthropic:
    global _client
    if _client is not None:
        return _client
    base_url = os.environ.get("CLAUDE_BASE_URL", "").strip()
    if not base_url:
        raise RuntimeError("CLAUDE_BASE_URL is not set")
    if not base_url.rstrip("/").endswith("/anthropic"):
        raise RuntimeError("CLAUDE_BASE_URL must end in /anthropic")
    client_id = os.environ.get("AZURE_CLIENT_ID", "").strip() or None
    credential = DefaultAzureCredential(managed_identity_client_id=client_id)
    provider = get_bearer_token_provider(credential, SCOPE)
    _client = AnthropicIdentity(azure_ad_token_provider=provider, base_url=base_url)
    return _client


def get_knowledge() -> Dict[str, Any]:
    global _knowledge_cache
    if _knowledge_cache is None:
        with KNOWLEDGE_PATH.open() as handle:
            _knowledge_cache = json.load(handle)
    return _knowledge_cache


def build_prompt() -> str:
    """Compiled once at startup, not per request.

    The wording lives in prompts/system_prompt.md and the criteria in
    prompts/med_nec_knowledge.json. This renders one into the other, so the
    instruction can be changed without touching Python.

    Placeholders are {{name}}. Single braces are left alone, which is what lets
    the JSON schema block sit in the template literally.
    """
    global _prompt_cache
    if _prompt_cache is not None:
        return _prompt_cache

    kb = get_knowledge()
    nl = chr(10)

    blocks = {
        "determination_question": kb["determination_question"],
        "non_emergency_question": kb["non_emergency_question"],
        "evaluation_principle": kb["evaluation_principle"],
        "concepts": nl.join(
            f'  {c["concept"]} | {c["axis"]} axis | {c["status"]} | phrasing: '
            f'{", ".join(c["terms"][:6])}'
            for c in sorted(kb["concepts"], key=lambda x: x["concept"])),
        "presumed_necessary": nl.join(
            f'  {p["id"]} | {p["statement"]}' for p in kb["presumed_necessary"]),
        "bed_confinement": nl.join(
            f'  {e["element"]} | {e["statement"]}'
            for e in kb["bed_confinement"]["elements"]),
        "exclusions": nl.join(
            f'  {e["exclusion_id"]} | {e["statement"]}' for e in kb["exclusions"]),
        "denial_criteria": nl.join(
            f'  - {d}' for d in kb["denial_criteria"]["elements"]),
        "policy_rules": nl.join(
            f'  - {r["statement"]}' for r in kb["policy_rules"]),
        "non_specific_phrases": ", ".join(kb["non_specific_phrases"]),
    }

    if not TEMPLATE_PATH.exists():
        raise FileNotFoundError(f"prompt template not found: {TEMPLATE_PATH}")
    text = TEMPLATE_PATH.read_text(encoding="utf-8")

    for name in blocks:
        text = text.replace("{{" + name + "}}", str(blocks[name]))

    leftover = re.findall(r"\{\{(\w+)\}\}", text)
    if leftover:
        raise ValueError(
            f"{TEMPLATE_PATH.name} has placeholders nothing fills: "
            f"{sorted(set(leftover))}. Known names: {sorted(blocks)}")

    _prompt_cache = text.strip()
    return _prompt_cache


def engine_version() -> str:
    kb = get_knowledge()
    deployment = os.environ.get("CLAUDE_DEPLOYMENT_NAME", "unset")
    return f"foundry/{deployment}/kb-{kb.get('knowledge_version', 'unknown')}"


def settings() -> Dict[str, Any]:
    """What the process is configured with. No secrets here; there are none."""
    base_url = os.environ.get("CLAUDE_BASE_URL", "")
    return {
        "baseUrl": base_url or None,
        "deploymentName": os.environ.get("CLAUDE_DEPLOYMENT_NAME") or None,
        "azureClientId": os.environ.get("AZURE_CLIENT_ID") or None,
        "authMethod": "managed identity / az login, no api key",
        "maxTokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
        "temperatureMode": _TEMPERATURE_MODE,
        "knowledgeVersion": get_knowledge().get("knowledge_version"),
        "promptChars": len(build_prompt()),
    }


def ping() -> str:
    """One trivial call. Proves the endpoint, the token and the deployment name."""
    client = get_client()
    message = client.messages.create(
        model=os.environ["CLAUDE_DEPLOYMENT_NAME"],
        max_tokens=32,
        messages=[{"role": "user", "content": "Reply with exactly: foundry connection ok"}],
    )
    return "".join(b.text for b in message.content if getattr(b, "type", "") == "text").strip()


def diagnose(exc: Exception) -> str:
    """Turn an exception into the thing to go and check."""
    text = f"{type(exc).__name__}: {exc}".lower()

    # Order matters. A credential failure mentions "not found" (az CLI not on
    # path) and would otherwise be reported as a wrong deployment name.
    if "is not set" in text or "must end in" in text:
        return str(exc)
    if ("credential" in text or "defaultazure" in text
            or "az login" in text or "azure cli" in text):
        return ("No token could be acquired. Run az login locally. On the App Service, "
                "check that the managed identity is attached and AZURE_CLIENT_ID is set.")
    if "429" in text or "rate limit" in text or "too many requests" in text:
        return "Rate limited. The deployment quota is too low for this call rate."
    if "401" in text or "403" in text or "forbidden" in text or "unauthorized" in text:
        return ("The identity has no role on the Foundry resource. Locally that means your "
                "az login account, on the App Service the managed identity.")
    if "connect" in text or "resolve" in text or "timeout" in text or "ssl" in text:
        return ("CLAUDE_BASE_URL is wrong, or egress to the Foundry endpoint is blocked. "
                "Run diagnose_tls.py.")
    if "404" in text or "not found" in text or "deployment" in text:
        return ("CLAUDE_DEPLOYMENT_NAME looks wrong. It is the deployment name from the "
                "Foundry portal, not the model id.")
    if "temperature" in text:
        return "The endpoint rejected the temperature setting. It will retry without it."
    return "Check CLAUDE_BASE_URL, CLAUDE_DEPLOYMENT_NAME and that az login is current."


def parse_clinical_data(blob: Any) -> List[Dict[str, Any]]:
    """Recover question and answer pairs from the flattened form text.

    Real payloads do not always populate losQuestions. Production leaves it null
    and puts everything in clinicalData, so this is the live path, not a rare
    fallback, and the pairs it returns are what the model reads.

    Transport.net flattens the form several ways, and one payload mixes them:

        question            question           section label:
        question            question: answer   question?
        answer                                 answer

        question? (Select all that apply)
        One selection required:
        option (hint): free text

    An earlier version handled only the doubled shape, which is what the UAT
    sample used. A production question followed directly by its answer fell
    through to the catch-all and reached the model as "QUESTION: None". That is
    the defect this replaces, and it was visible in the review workbook.

    Anything fitting no shape still becomes its own pair rather than being
    dropped. Losing clinical text silently is worse than an untidy pair.
    """
    # A sub-prompt belongs to the question above it, never to a pair of its own.
    _SUBPROMPT = re.compile(
        r"^\(?(one selection required|select all that apply|select one|"
        r"select any that apply|select all|yes/no|choose one)\)?[:.]?$", re.I)

    def bare(text: str) -> str:
        """The line without a trailing parenthetical hint."""
        return re.sub(r"\s*\([^()]*\)\s*$", "", text).rstrip()

    # A trailing hint marks a prompt even when it is phrased as a statement,
    # which production does: "...related to the terminal illness (Select one)".
    _HINT = re.compile(
        r"\((one selection required|select all that apply|select one|select all|"
        r"select any that apply|yes/no|choose one)\)\s*$", re.I)

    def is_question(text: str) -> bool:
        # "... ? (One selection required)" is a question; the hint is not part of it.
        return bare(text).endswith("?") or bool(_HINT.search(text))

    def is_label(text: str) -> bool:
        """A short line introducing whatever follows it."""
        stripped = bare(text)
        return len(stripped) <= 90 and stripped.endswith(":")

    def is_prompt(text: str) -> bool:
        return not _SUBPROMPT.match(text) and (is_question(text) or is_label(text))

    lines = [ln.strip() for ln in str(blob or "").split("\n")]
    lines = [ln for ln in lines if ln]

    pairs: List[Dict[str, Any]] = []
    pending: Optional[str] = None
    i = 0

    def add(question: Optional[str], answer: str) -> None:
        pairs.append({"questionId": None, "question": question, "answer": answer})

    while i < len(lines):
        line = lines[i]
        nxt = lines[i + 1] if i + 1 < len(lines) else None
        after = lines[i + 2] if i + 2 < len(lines) else None

        if _SUBPROMPT.match(line):
            i += 1
            continue

        # ---- the doubled shapes, which the UAT sample uses throughout ----
        if nxt == line and after is not None and after.startswith(line + ": "):
            add(line, after[len(line) + 2:])
            i += 3
            continue
        if nxt == line and after is not None:
            add(line, after)
            i += 3
            continue
        if nxt == line:
            add(line, "")
            i += 2
            continue
        if nxt is not None and nxt.startswith(line + ": "):
            add(line, nxt[len(line) + 2:])
            i += 2
            continue

        # ---- a prompt, with everything under it as its answer ----
        if is_prompt(line):
            label = bare(line).rstrip(": ") if is_label(line) else line
            question = f"{pending}: {label}" if pending else label
            pending = None

            j = i + 1
            answers: List[str] = []
            while j < len(lines):
                candidate = lines[j]
                if _SUBPROMPT.match(candidate):
                    j += 1
                    continue
                if is_prompt(candidate):
                    break
                # A short line that introduces the next prompt is a section
                # label, not an answer. Only once an answer is already in hand,
                # so a one word answer before the next question is not eaten.
                if (answers and j + 1 < len(lines) and is_prompt(lines[j + 1])
                        and len(candidate) <= 70 and ":" not in candidate
                        and not candidate.endswith(".")):
                    break
                answers.append(candidate)
                j += 1

            if answers:
                add(question, " | ".join(answers))
                i = j
            else:
                # Nothing under it, so it introduces the prompt that follows.
                pending = label
                i += 1
            continue

        # ---- a checkbox option carrying its own free text ----
        if ": " in line and not line.endswith(":"):
            option, _, value = line.partition(": ")
            add(f"{pending}: {option}" if pending else option, value)
            i += 1
            continue

        # A short line whose next line is a prompt is a section label, not an
        # answer. Carried onto that prompt instead of orphaned.
        if (nxt is not None and is_prompt(nxt) and len(line) <= 70
                and not line.endswith(".")):
            pending = line.rstrip(": ")
            i += 1
            continue

        add(pending, line)
        pending = None
        i += 1

    return [p for p in pairs if (p["answer"] or "").strip()]


def get_epcr_spec() -> Dict[str, Any]:
    global _epcr_spec_cache
    if _epcr_spec_cache is None:
        with EPCR_FIELDS_PATH.open() as handle:
            _epcr_spec_cache = json.load(handle)
    return _epcr_spec_cache


def build_epcr_prompt() -> str:
    """The retrospective instruction, rendered from the same criteria."""
    global _epcr_prompt_cache
    if _epcr_prompt_cache is not None:
        return _epcr_prompt_cache

    build_prompt()                      # fills the shared blocks and validates them
    if not EPCR_TEMPLATE_PATH.exists():
        raise FileNotFoundError(f"ePCR prompt template not found: {EPCR_TEMPLATE_PATH}")

    kb = get_knowledge()
    nl = chr(10)
    blocks = {
        "determination_question": kb["determination_question"],
        "non_emergency_question": kb["non_emergency_question"],
        "evaluation_principle": kb["evaluation_principle"],
        "concepts": nl.join(
            f'  {c["concept"]} | {c["axis"]} axis | {c["status"]} | phrasing: '
            f'{", ".join(c["terms"][:6])}'
            for c in sorted(kb["concepts"], key=lambda x: x["concept"])),
        "presumed_necessary": nl.join(
            f'  {p["id"]} | {p["statement"]}' for p in kb["presumed_necessary"]),
        "bed_confinement": nl.join(
            f'  {e["element"]} | {e["statement"]}'
            for e in kb["bed_confinement"]["elements"]),
        "exclusions": nl.join(
            f'  {e["exclusion_id"]} | {e["statement"]}' for e in kb["exclusions"]),
        "denial_criteria": nl.join(f'  - {d}' for d in kb["denial_criteria"]["elements"]),
        "policy_rules": nl.join(f'  - {r["statement"]}' for r in kb["policy_rules"]),
        "non_specific_phrases": ", ".join(kb["non_specific_phrases"]),
    }

    text = EPCR_TEMPLATE_PATH.read_text(encoding="utf-8")
    for name in blocks:
        text = text.replace("{{" + name + "}}", str(blocks[name]))

    leftover = re.findall(r"\{\{(\w+)\}\}", text)
    if leftover:
        raise ValueError(
            f"{EPCR_TEMPLATE_PATH.name} has placeholders nothing fills: "
            f"{sorted(set(leftover))}. Known names: {sorted(blocks)}")

    _epcr_prompt_cache = text.strip()
    return _epcr_prompt_cache


def _minutes_between(start: Any, end: Any) -> Optional[int]:
    for value in (start, end):
        if value in (None, "", "null"):
            return None
    try:
        from datetime import datetime
        fmt = lambda v: datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return int((fmt(end) - fmt(start)).total_seconds() / 60)
    except Exception:
        return None


def select_epcr_fields(row: Dict[str, Any]) -> Dict[str, Any]:
    """Reduce a full ePCR row to what the model is allowed to see.

    The whole row stays on disk. This decides what leaves it. Which columns go
    and which are held back lives in prompts/epcr_fields.json, with a reason on
    every exclusion, so the decision is reviewable without reading code.
    """
    spec = get_epcr_spec()
    blank = {None, "", "null", "NULL", "None", "nan", "NaN"}

    groups = []
    used = 0
    for group in spec["send"]:
        fields = []
        for column in group["columns"]:
            value = row.get(column)
            if value is None or str(value).strip() in blank:
                continue
            fields.append({"field": column, "value": str(value).strip()})
            used += 1
        if fields:
            groups.append({"group": group["group"], "why": group.get("why"),
                           "fields": fields})

    derived = []
    for rule in spec.get("derive", []):
        if len(rule["from"]) == 2:
            minutes = _minutes_between(row.get(rule["from"][0]), row.get(rule["from"][1]))
            if minutes is not None and minutes >= 0:
                derived.append({"field": rule["name"], "value": f"{minutes} minutes"})
    if derived:
        groups.append({"group": "Derived timings", "why": "Computed from the dispatch times.",
                       "fields": derived})
        used += len(derived)

    offered = sum(len(g["columns"]) for g in spec["send"])
    withheld = sum(len(g["columns"]) for g in spec["withhold"])

    flag = spec.get("match_flag_column")
    matched = None
    if flag and flag in row:
        matched = str(row.get(flag)).strip().upper() == str(spec.get("match_flag_means_matched", "T")).upper()

    return {
        "tripRequestId": row.get(spec.get("key_column")),
        "groups": groups,
        "populated": used,
        "offered": offered,
        "withheld": withheld,
        "epcrMatched": matched,
        "fieldsVersion": spec.get("version"),
    }


def build_epcr_message(selected: Dict[str, Any]) -> str:
    lines = [f"Trip request: {selected.get('tripRequestId')}",
             f"Fields carrying a value: {selected['populated']} of {selected['offered']} offered",
             ""]
    for group in selected["groups"]:
        lines.append(f"{group['group'].upper()}")
        for field in group["fields"]:
            lines.append(f"  {field['field']}: {field['value']}")
        lines.append("")
    return chr(10).join(lines).strip()


def validate_epcr(raw: str) -> Tuple[Optional[Dict[str, Any]], str]:
    try:
        obj = json.loads(strip_fences(raw))
    except Exception as exc:
        return None, f"unparseable json: {exc}"
    if not isinstance(obj, dict):
        return None, "response is not an object"

    for field in ("clinicalSummary", "meetsMedicalNecessity"):
        if field not in obj:
            return None, f"missing field: {field}"
    if not isinstance(obj["meetsMedicalNecessity"], bool):
        return None, "meetsMedicalNecessity is not a boolean"

    gaps = obj.get("documentationGaps")
    if not isinstance(gaps, list):
        gaps = [] if gaps in (None, "") else [str(gaps)]

    detail = obj.get("detail")
    if not isinstance(detail, dict):
        detail = {}
    detail.setdefault("determination", "needs_review")
    detail.setdefault("basis", "")
    detail.setdefault("confidence", "Low")
    detail.setdefault("strongestEvidence", None)
    for key in ("criteriaDocumented", "exclusionsTriggered", "fieldFindings"):
        if not isinstance(detail.get(key), list):
            detail[key] = []

    return {
        "clinicalSummary": str(obj["clinicalSummary"] or "").strip() or None,
        "meetsMedicalNecessity": obj["meetsMedicalNecessity"],
        "documentationGaps": [str(g) for g in gaps if str(g).strip()],
        "detail": detail,
    }, ""


def call_epcr_model(client: Anthropic, messages: List[Dict[str, Any]]):
    global _TEMPERATURE_MODE
    kwargs: Dict[str, Any] = {
        "model": os.environ["CLAUDE_DEPLOYMENT_NAME"],
        "max_tokens": MAX_TOKENS,
        "system": build_epcr_prompt(),
        "messages": messages,
    }
    if _TEMPERATURE_MODE == "typed":
        kwargs["temperature"] = TEMPERATURE
    elif _TEMPERATURE_MODE == "body":
        kwargs["extra_body"] = {"temperature": TEMPERATURE}

    started = time.perf_counter()
    try:
        message = client.messages.create(**kwargs)
    except Exception as exc:
        if _TEMPERATURE_MODE == "off" or "temperature" not in str(exc).lower():
            raise
        _TEMPERATURE_MODE = "off"
        kwargs.pop("temperature", None)
        kwargs.pop("extra_body", None)
        started = time.perf_counter()
        message = client.messages.create(**kwargs)
    return message, int((time.perf_counter() - started) * 1000)


def evaluate_epcr(row: Dict[str, Any]) -> Dict[str, Any]:
    """Assess a completed patient care record. Retrospective, not predictive."""
    selected = select_epcr_fields(row)

    if not selected["populated"]:
        return {
            "clinicalSummary": None,
            "meetsMedicalNecessity": False,
            "documentationGaps": [
                "The patient care record carries no clinical content at all."],
            "detail": {
                "determination": "does_not_meet",
                "basis": ("None of the fields this assessment reads carry a value. Where "
                          "MDM_GoldenRecord is not T, no patient care record was matched "
                          "to this trip, which is a record linkage problem rather than a "
                          "clinical one."),
                "confidence": "High",
                "strongestEvidence": None,
                "criteriaDocumented": [],
                "exclusionsTriggered": [],
                "fieldFindings": [],
                "selection": selected,
                "usage": {"inputTokens": 0, "outputTokens": 0, "model": None,
                          "modelMs": 0, "modelCalls": 0},
            },
        }

    client = get_client()
    user_message = build_epcr_message(selected)

    message, model_ms = call_epcr_model(client, [{"role": "user", "content": user_message}])
    model_calls = 1
    raw = "".join(b.text for b in message.content if getattr(b, "type", "") == "text")

    result, error = validate_epcr(raw)
    if result is None:
        retry, retry_ms = call_epcr_model(client, [
            {"role": "user", "content": user_message},
            {"role": "assistant", "content": raw or ""},
            {"role": "user",
             "content": f"That response was rejected ({error}). "
                        f"Return only valid JSON matching the schema."},
        ])
        model_ms += retry_ms
        model_calls += 1
        raw = "".join(b.text for b in retry.content if getattr(b, "type", "") == "text")
        result, error = validate_epcr(raw)
        message = retry

    if result is None:
        raise RuntimeError(f"ePCR response failed validation twice: {error}")

    result["detail"]["selection"] = selected
    result["detail"]["usage"] = {
        "inputTokens": message.usage.input_tokens,
        "outputTokens": message.usage.output_tokens,
        "model": message.model,
        "modelMs": model_ms,
        "modelCalls": model_calls,
        "promptChars": len(build_epcr_prompt()),
        "fieldsSent": selected["populated"],
    }
    return result


def extract_pairs(trip: Dict[str, Any]) -> List[Dict[str, Any]]:
    legs = trip.get("tripLegs") or []
    leg = legs[0] if legs else {}
    pairs: List[Dict[str, Any]] = []

    for q in leg.get("losQuestions") or []:
        if not isinstance(q, dict):
            continue
        answer = str(q.get("answer") or "").strip()
        if not answer:
            continue
        free_text = str(q.get("answerValue") or "").strip()
        combined = answer
        if free_text and free_text.lower() != answer.lower():
            combined = f"{answer}: {free_text}"
        pairs.append({
            "questionId": q.get("questionId"),
            "question": str(q.get("questionText") or "").strip(),
            "answer": combined,
        })

    if pairs:
        return pairs

    return parse_clinical_data(leg.get("clinicalData"))


def build_user_message(trip: Dict[str, Any], pairs: List[Dict[str, Any]],
                       clarification: Optional[Dict[str, str]] = None) -> str:
    legs = trip.get("tripLegs") or []
    leg = legs[0] if legs else {}

    lines = [
        f"Trip request: {trip.get('olosRequestId')}",
        f"Requesting facility: {trip.get('requesterFacility')}",
        f"Level of service requested: {leg.get('levelOfService')}",
        f"Transfer reason: {trip.get('tripReason')}",
        "",
        f"Question and answer pairs ({len(pairs)}):",
    ]
    for i, pair in enumerate(pairs):
        qid = pair["questionId"]
        lines.append(f"{i}. [questionId {qid if qid is not None else 'none'}] "
                     f"QUESTION: {pair['question']}")
        lines.append(f"   ANSWER: {pair['answer']}")

    if clarification:
        lines += [
            "",
            "A clarifying question was already put to the requester and answered.",
            "Take the answer into account and reassess.",
            f"  QUESTION ASKED: {clarification.get('question')}",
            f"  REQUESTER ANSWERED: {clarification.get('answer')}",
            "",
            "Fold the answer into the clinical summary. Return null for clarifyingQuestion;",
            "the requester is only asked once.",
        ]
    return "\n".join(lines)


def strip_fences(raw: str) -> str:
    text = str(raw).strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    start, end = text.find("{"), text.rfind("}")
    return text[start:end + 1] if start != -1 and end > start else text


def validate(raw: str) -> Tuple[Optional[Dict[str, Any]], str]:
    try:
        obj = json.loads(strip_fences(raw))
    except Exception as exc:
        return None, f"unparseable json: {exc}"
    if not isinstance(obj, dict):
        return None, "response is not an object"

    for field in ("clinicalSummary", "meetsMedicalNecessity", "clarifyingQuestion"):
        if field not in obj:
            return None, f"missing field: {field}"
    if not isinstance(obj["meetsMedicalNecessity"], bool):
        return None, "meetsMedicalNecessity is not a boolean"

    detail = obj.get("detail")
    if not isinstance(detail, dict):
        detail = {}
    detail.setdefault("determination", "needs_review")
    detail.setdefault("basis", "")
    detail.setdefault("confidence", "Low")
    for key in ("criteriaDocumented", "exclusionsTriggered", "questionFindings"):
        if not isinstance(detail.get(key), list):
            detail[key] = []

    question = obj["clarifyingQuestion"]
    if isinstance(question, str) and not question.strip():
        question = None

    return {
        "clinicalSummary": str(obj["clinicalSummary"] or "").strip() or None,
        "meetsMedicalNecessity": obj["meetsMedicalNecessity"],
        "clarifyingQuestion": question,
        "detail": detail,
    }, ""


def call_model(client: Anthropic, messages: List[Dict[str, Any]]):
    """One model call, with temperature sent whichever way this SDK allows.

    Falls back to no temperature at all if the endpoint rejects it, once, and
    then stops trying for the life of the process.
    """
    global _TEMPERATURE_MODE

    kwargs: Dict[str, Any] = {
        "model": os.environ["CLAUDE_DEPLOYMENT_NAME"],
        "max_tokens": MAX_TOKENS,
        "system": build_prompt(),
        "messages": messages,
    }
    if _TEMPERATURE_MODE == "typed":
        kwargs["temperature"] = TEMPERATURE
    elif _TEMPERATURE_MODE == "body":
        kwargs["extra_body"] = {"temperature": TEMPERATURE}

    started = time.perf_counter()
    try:
        message = client.messages.create(**kwargs)
    except Exception as exc:
        if _TEMPERATURE_MODE == "off" or "temperature" not in str(exc).lower():
            raise
        log.warning("endpoint rejected temperature, continuing without it: %s",
                    str(exc)[:200])
        _TEMPERATURE_MODE = "off"
        kwargs.pop("temperature", None)
        kwargs.pop("extra_body", None)
        started = time.perf_counter()
        message = client.messages.create(**kwargs)
    return message, int((time.perf_counter() - started) * 1000)


def evaluate_trip(trip: Dict[str, Any],
                  clarification: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Returns the same shape a fixture block returns."""
    pairs = extract_pairs(trip)
    if not pairs:
        return {
            "clinicalSummary": None,
            "meetsMedicalNecessity": False,
            "clarifyingQuestion": None,
            "detail": {
                "determination": "does_not_meet",
                "basis": "The order carried no clinical answers to assess.",
                "confidence": "High",
                "criteriaDocumented": [],
                "exclusionsTriggered": [],
                "questionFindings": [],
                "usage": {"inputTokens": 0, "outputTokens": 0, "model": None,
                          "modelMs": 0, "modelCalls": 0,
                          "promptChars": 0, "pairsSent": 0},
            },
        }

    client = get_client()
    user_message = build_user_message(trip, pairs, clarification)

    message, first_ms = call_model(client, [{"role": "user", "content": user_message}])
    model_ms = first_ms
    model_calls = 1
    raw = "".join(b.text for b in message.content if getattr(b, "type", "") == "text")

    result, error = validate(raw)
    if result is None:
        retry, retry_ms = call_model(client, [
            {"role": "user", "content": user_message},
            {"role": "assistant", "content": raw or ""},
            {"role": "user",
             "content": f"That response was rejected ({error}). "
                        f"Return only valid JSON matching the schema."},
        ])
        model_ms += retry_ms
        model_calls += 1
        raw = "".join(b.text for b in retry.content if getattr(b, "type", "") == "text")
        result, error = validate(raw)
        message = retry

    if result is None:
        raise RuntimeError(f"model response failed validation twice: {error}")

    result["detail"]["usage"] = {
        "inputTokens": message.usage.input_tokens,
        "outputTokens": message.usage.output_tokens,
        "model": message.model,
        "modelMs": model_ms,
        "modelCalls": model_calls,
        "promptChars": len(build_prompt()),
        "pairsSent": len(pairs),
    }
    return result
