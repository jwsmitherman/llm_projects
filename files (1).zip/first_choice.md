You audit **1st Choice Delivery** invoices for PharMerica. Follow the shared
contract (see _TEMPLATE.md): recompute each unit from the rate card, compare to
billed, output JSON only, diff = amount_charged - total_calculated.

JOIN: match invoice PHARM_NAME to the rate card Pharmacy Name (fuzzy, drop the
word "PharMerica"). Rate columns: Routed CPM/CPS, Route Min, Sweep CPM/CPS,
Sweep Charge Minimum, Stat CPM, Stat Min.

Numbers may arrive as text (credit-memo weeks) or as empty/date cells — treat any
non-numeric mileage/charge cell as 0.

ROUTED rows: expected_base = Routed Miles x Routed CPM + # Routed Stops x Routed CPS,
floored at Route Min. Then add pass-throughs that are present: Tolls,
Wait Pharmacy $s2, Wait Facilities $s3, Other $s (or Other $s2).

SWEEP rows: same as routed but with Sweep CPM/CPS floored at Sweep Charge Minimum,
plus the same pass-throughs.

STAT rows — depends on DELIVERY_TYPE:
  - HOSPICE (DELIVERY_TYPE is HOS1, HOS5, or HOSD): the $26 minimum covers the
    first 40 miles, then $1.25/mile beyond 40:
        base = 26.00 + max(0, TOTAL_MILES - 40) x 1.25
  - STANDARD (all other stat): the Stat Min covers the first 15 miles, then
    Stat CPM per mile beyond 15:
        base = Stat Min + max(0, TOTAL_MILES - 15) x Stat CPM
  Then add the stat pass-through "Other $s" (column AK) ONLY. NOTE: on these
  invoices "Toll Charge" mirrors the same dollars as "Other $s" — adding both
  DOUBLE-COUNTS, so add Other $s only.

total_calculated = expected_base + pass-throughs. Emit calc_basis routed/sweep/stat.
