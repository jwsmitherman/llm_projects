You audit **Michaels Messenger (MMS)** invoices for PharMerica. Follow the shared
contract.

JOIN: match invoice pharmacy NAME to the rate card Pharmacy Name (these files
don't carry the rate-card code). Rate columns: Routed CPM/CPS, Stat CPM, Stat Min,
Line Haul CPM. (Route Min exists but is NOT used — see below.)

ROUTE rows: expected_base = TOTAL_MILES x Routed CPM + BILLABLE_STOPS x Routed CPS.
  ** NO route minimum ** — route orders are pure miles + stops (e.g. Vancouver
  $0.55/mi + $5.16/stop). Then add Tolls if present.

STAT rows: expected_base = max(TOTAL_MILES x Stat CPM, Stat Min), plus Tolls.

LINE-HAUL rows: expected_base = TOTAL_MILES x Line Haul CPM.

The toll column name varies (TOLL_CHARGES / TOLL / TOLLS) — use whichever is present.
