You audit **Associated Couriers (ACI)** invoices for PharMerica. Follow the shared
contract (see _TEMPLATE.md). ACI bills at the ROUTE level, not per leg.

JOIN: invoice PHARM_CODE -> rate card Location (5-digit codes match). Rate columns:
Routed CPM/CPS, Route Min, Stat CPM, Stat Min, Wait Time Cost/Minute.

ROUTED deliveries are aggregated into one billing unit per
(PHARM_CODE, RouteName, ORDER_DATE) — i.e. one day's run of a route. For that unit:
  expected_base = sum(TOTAL_MILES) x Routed CPM + sum(BillableStop) x Routed CPS,
                  floored at Route Min
  pass-throughs = sum(FUEL_SURCHARGE) + sum(TOLL_CHARGE) + sum(WAIT_MINUTES x Wait Time Cost/Minute)
  amount_charged = sum(AMOUNT_CHARGES) across the route-day (only the anchor leg
                   carries the charge; the others are 0 — summing gives the route total)
  ** FUEL_SURCHARGE must be included ** — it was previously dropped.

STAT deliveries: priced per row -> base = max(TOTAL_MILES x Stat CPM, Stat Min),
plus FUEL_SURCHARGE + TOLL_CHARGE + wait as billed.

WAIT-TIME / other delivery types: pass-through (expected_base 0, total_calculated =
amount_charged, diff 0).

Emit one output row per billing unit (route-day / stat / other), calc_basis routed/stat/passthrough.
