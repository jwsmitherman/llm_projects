# LLM-backed carrier audit — how it works and how to turn it on

This adds an LLM path to the invoice audit, with **one prompt per carrier** in a
`prompts/` folder. The point: a carrier's rules become a **prompt edit instead of
a code deploy**, so rule tweaks (like everything we changed this month) don't need
a new release.

## Files
```
llm_audit.py              # Azure OpenAI layer (reused from Betty.ai's llm.py) + run_audit()
prompts/_TEMPLATE.md      # the shared I/O contract every carrier prompt follows
prompts/<carrier>.md      # one prompt per carrier slug: aci, dds, first_choice,
                          #   henry_industries, mms, us_pack
carriers/llm_processor.py # LLMCarrierProcessor: same interface as the deterministic
                          #   processors; loads the prompt, calls the model, validates
```

## Turn it on
1. Set the Azure OpenAI key (do NOT hardcode it — see Security):
   `AZURE_OPENAI_API_KEY`, and if different, `AZURE_OPENAI_ENDPOINT` /
   `AZURE_OPENAI_DEPLOYMENT`.
2. Wrap the registry. In `carriers/__init__.py`, after `REGISTRY` is built:
   ```python
   import os
   if os.environ.get("AUDIT_USE_LLM") == "1":
       from .llm_processor import wrap_registry
       REGISTRY = wrap_registry(REGISTRY)
   ```
   Then run with `AUDIT_USE_LLM=1`. With the flag off (or the key unset), behaviour
   is unchanged — the deterministic processors run exactly as today.

## Edit a carrier's rules
Open `prompts/<carrier>.md` and edit the plain-English rules. No code change. The
file is the SYSTEM prompt; the rate rows + invoice rows are sent as CSV at runtime.

## Read this before trusting LLM numbers

**The configured model (gpt-35-turbo) is unreliable at arithmetic.** This whole
system is multi-step math (miles x CPM + stops x CPS, minimums, per-route
aggregation, hospice tiers). GPT-3.5 will make arithmetic errors on exactly this.
Two guardrails are already built in:

- **Code re-checks every row** (`LLMCarrierProcessor._validate`): the model's
  components must sum to its total and its diff must reconcile. Where they don't,
  the row is flagged (`check_ok = False`) and the code's arithmetic — not the
  model's — is written to `total_calculated` and `diff`.
- **Fallback**: if the LLM isn't configured or a batch errors, that carrier runs
  the deterministic processor, so the app never hard-fails.

**Recommended design (hybrid).** The model's real strength here is *deciding which
rate/rule applies* — hospice vs standard, OPPC tier, line-haul detection, matching
a pharmacy, reading a new rate sheet — which is what caused nearly every fix this
month. The *arithmetic* is better left to code. The cleanest long-term shape is:
LLM resolves the rule per pharmacy/delivery-type (a handful of decisions), code
applies it to all rows. That also solves scale — sending a 28,951-row DDS file to
the model row-by-row is slow and costly; resolving ~a dozen rules is not.

**If you keep per-row LLM calculation:** move to a stronger deployment (e.g.
gpt-4o) for numeric reliability, and keep the code validator on. The prompts force
a step-by-step `work` trace, which helps, but does not make GPT-3.5 dependable at
scale.

## Security
The uploaded `llm.py` had a **hardcoded API key**. `llm_audit.py` replaces it with
a placeholder and reads from the environment. Rotate that exposed key, and set the
real one via `AZURE_OPENAI_API_KEY` / Azure App Service application settings — not
in source.
