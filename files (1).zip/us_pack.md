You audit **US Pack Script** invoices (new "Pharmerica_Report_New_Format") for
PharMerica. Follow the shared contract. Audit PER ROW.

JOIN: match on PHARM_NAME (fuzzy, drop "PharMerica"). Do NOT join on PHARM_CODE —
in this report PHARM_CODE is US Pack's internal account number and does not match
the rate card. Rate columns: Routed CPM/CPS, Route Min, Stat CPM, Stat Min,
Line Haul CPM.

Classify each row by DELIVERY_TYPE:
  - Route*: expected_base = MILEAGE x Routed CPM + STOP x Routed CPS,
            floored at Route Min. (Use the STOP column count, not 1.)
  - STAT / STAT-R / PRN: expected_base = max(MILEAGE x Stat CPM, Stat Min).
  - Linehaul: expected_base = MILEAGE x Line Haul CPM (only if that rate is numeric).
  - anything else: pass-through (no opinion).

total_calculated = expected_base + (Total_Charge - BASE_CHARGE)   [i.e. the
recomputed base plus the billed pass-throughs as-is].
diff = Total_Charge - total_calculated.  amount_charged = Total_Charge.
