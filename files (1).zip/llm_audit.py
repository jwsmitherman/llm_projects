"""
llm_audit.py — LLM layer for the carrier invoice audit.

Reuses the Azure OpenAI plumbing from the Betty.ai llm.py (single _chat() choke
point, JSON mode, circuit breaker, Viby seam) and adds the audit-specific call:

    run_audit(carrier_slug, rate_csv, invoice_csv) -> list[dict]

Each carrier's rules live in prompts/<carrier_slug>.md (see that folder). The
prompt is the SYSTEM message; the rate-card rows and invoice rows are handed in
as CSV in the USER message; the model returns JSON rows with the computed total
and diff.

IMPORTANT (read before trusting the output):
  * The configured deployment (gpt-35-turbo) is WEAK at multi-step arithmetic.
    For dollar-accurate audits, run llm_processor in "rule" mode (LLM picks the
    rate/rule, code does the math) or validate every row in code. See LLM_README.
  * Sending tens of thousands of rows row-by-row to the model is slow and
    expensive; llm_processor batches and, for large files, is meant to resolve
    the RULE per pharmacy/type rather than compute every row in the model.
"""
import json
import os
import re
from pathlib import Path

import requests

# --------------------------------------------------------------------------
# Azure OpenAI credentials (same resource as Betty.ai; override via env vars)
# --------------------------------------------------------------------------
AZURE_OPENAI_ENDPOINT = os.environ.get(
    "AZURE_OPENAI_ENDPOINT", "https://bhsgenai.openai.azure.com/")
AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY", "REPLACE_WITH_KEY")
AZURE_OPENAI_DEPLOYMENT = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-35-turbo-bsh")
AZURE_OPENAI_API_VERSION = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")

PROMPTS_DIR = Path(os.environ.get(
    "AUDIT_PROMPTS_DIR", Path(__file__).parent / "prompts"))

AZURE_TIMEOUT_SECONDS = int(os.environ.get("AZURE_OPENAI_TIMEOUT", "60"))
_MAX_FAILURES = 3
_failures = 0


def _note_failure():
    global _failures
    _failures += 1


def _circuit_open():
    return _failures >= _MAX_FAILURES


def is_configured():
    if _circuit_open():
        return False
    blob = AZURE_OPENAI_ENDPOINT + AZURE_OPENAI_API_KEY
    return "REPLACE_WITH" not in blob and bool(AZURE_OPENAI_ENDPOINT)


def _azure_chat(messages, temperature=0.0, max_tokens=1500, json_mode=True):
    url = (f"{AZURE_OPENAI_ENDPOINT.rstrip('/')}/openai/deployments/"
           f"{AZURE_OPENAI_DEPLOYMENT}/chat/completions"
           f"?api-version={AZURE_OPENAI_API_VERSION}")
    headers = {"Content-Type": "application/json", "api-key": AZURE_OPENAI_API_KEY}
    payload = {"messages": messages, "temperature": temperature,
               "max_tokens": max_tokens}
    if json_mode:
        payload["response_format"] = {"type": "json_object"}
    resp = requests.post(url, headers=headers, json=payload, timeout=AZURE_TIMEOUT_SECONDS)
    if json_mode and resp.status_code == 400:          # older builds reject JSON mode
        payload.pop("response_format", None)
        resp = requests.post(url, headers=headers, json=payload, timeout=AZURE_TIMEOUT_SECONDS)
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]


def _chat(messages, **kw):
    """Single choke point (Viby seam preserved from Betty.ai's llm.py)."""
    return _azure_chat(messages, **kw)


def load_prompt(carrier_slug: str) -> str:
    path = PROMPTS_DIR / f"{carrier_slug}.md"
    if not path.exists():
        raise FileNotFoundError(
            f"No prompt for carrier '{carrier_slug}' at {path}. "
            f"Add prompts/{carrier_slug}.md.")
    return path.read_text(encoding="utf-8")


def _extract_json(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.I | re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, flags=re.S)
        if m:
            return json.loads(m.group())
        raise


def run_audit(carrier_slug: str, rate_csv: str, invoice_csv: str,
              max_tokens: int = 3000) -> list:
    """Send one batch of invoice rows (CSV) + the carrier rate rows (CSV) to the
    model using the carrier's prompt. Returns a list of result dicts (the model's
    "rows"). Raises on network/parse errors so the caller can fall back."""
    system = load_prompt(carrier_slug)
    user = (f"RATE_CARD (CSV, {carrier_slug} rows only):\n{rate_csv}\n\n"
            f"INVOICE (CSV):\n{invoice_csv}\n\n"
            "Return ONLY the JSON object described in the instructions.")
    content = _chat(
        [{"role": "system", "content": system},
         {"role": "user", "content": user}],
        temperature=0.0, max_tokens=max_tokens, json_mode=True)
    data = _extract_json(content)
    return data.get("rows", data if isinstance(data, list) else [])
