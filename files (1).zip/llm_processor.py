"""
carriers/llm_processor.py — LLM-backed carrier auditor.

Implements the same interface as the deterministic processors
(`process(xlsx, rate_df) -> CarrierResult`) so it drops straight into the
registry, but computes the audit by sending the carrier's prompt
(prompts/<slug>.md) + rate rows + invoice rows to the LLM (see llm_audit.py).

Design notes (see LLM_README.md for the full rationale):
  * Each carrier's rules live in its prompt file, so a rule change is a prompt
    edit, not a code deploy — which is the main reason to use this path.
  * The configured model (gpt-35-turbo) is unreliable at arithmetic, so every
    row the model returns is re-checked in code (`_validate`): components must
    sum to total_calculated and diff must reconcile, or the row is flagged.
  * If the LLM is not configured or a batch fails, we fall back to the
    deterministic processor for that carrier so the app never hard-fails.
"""
from __future__ import annotations

import io

import pandas as pd

import llm_audit
from .base import CarrierProcessor, CarrierResult

BATCH_ROWS = int(__import__("os").environ.get("AUDIT_LLM_BATCH", "40"))


class LLMCarrierProcessor(CarrierProcessor):
    """Wraps a deterministic processor; audits via the LLM when configured."""

    def __init__(self, fallback: CarrierProcessor):
        self.fallback = fallback
        self.slug = fallback.slug
        self.display_name = f"{fallback.display_name} (LLM)"
        self.courier_filter = getattr(fallback, "courier_filter", "")

    # ---- interface ----
    def process(self, xlsx: pd.ExcelFile, rate_df: pd.DataFrame) -> CarrierResult:
        if not llm_audit.is_configured():
            # No LLM available -> deterministic result, unchanged behaviour.
            return self.fallback.process(xlsx, rate_df)
        try:
            return self._process_llm(xlsx, rate_df)
        except Exception as e:
            print(f"[llm_processor] {self.slug} fell back to deterministic: {e}")
            return self.fallback.process(xlsx, rate_df)

    # ---- llm path ----
    def _process_llm(self, xlsx: pd.ExcelFile, rate_df: pd.DataFrame) -> CarrierResult:
        # 1) carrier rate rows -> CSV
        rate_rows = self.fallback.filter_rate(rate_df) if hasattr(self.fallback, "filter_rate") \
            else rate_df
        rate_csv = rate_rows.to_csv(index=False)

        # 2) invoice rows -> CSV (all sheets concatenated, with a stable row_id)
        frames = []
        for sheet in xlsx.sheet_names:
            df = xlsx.parse(sheet)
            df.insert(0, "__sheet", sheet)
            frames.append(df)
        invoice = pd.concat(frames, ignore_index=True)
        invoice.insert(0, "row_id", range(len(invoice)))

        # 3) batch to the model, collect result rows
        results = []
        for start in range(0, len(invoice), BATCH_ROWS):
            batch = invoice.iloc[start:start + BATCH_ROWS]
            rows = llm_audit.run_audit(self.slug, rate_csv, batch.to_csv(index=False))
            results.extend(rows)

        res = pd.DataFrame(results)
        res = self._validate(res)

        # 4) attach the model's numbers back onto the invoice rows by row_id
        keep = [c for c in ["row_id", "calc_basis", "expected_base", "passthroughs",
                            "total_calculated", "amount_charged", "diff",
                            "check_ok", "work"] if c in res.columns]
        out = invoice.merge(res[keep], on="row_id", how="left") if "row_id" in res.columns \
            else invoice.assign(**{c: None for c in keep})
        return CarrierResult(sheets={"Results": out}, ext="xlsx")

    # ---- code-side arithmetic check (the model can't be trusted to add) ----
    @staticmethod
    def _validate(res: pd.DataFrame) -> pd.DataFrame:
        if res.empty:
            return res
        for c in ["expected_base", "passthroughs", "total_calculated",
                  "amount_charged", "diff"]:
            if c in res.columns:
                res[c] = pd.to_numeric(res[c], errors="coerce")
        base = res.get("expected_base", 0).fillna(0)
        extra = res.get("passthroughs", 0).fillna(0)
        total = res.get("total_calculated", 0).fillna(0)
        amt = res.get("amount_charged", 0).fillna(0)
        diff = res.get("diff", 0).fillna(0)
        # recompute what the model SHOULD have produced and flag disagreements
        sums_ok = (base + extra - total).abs() < 0.01
        diff_ok = (amt - total - diff).abs() < 0.01
        res["check_ok"] = sums_ok & diff_ok
        # trust the code's arithmetic over the model's on the diff
        res["total_calculated"] = (base + extra).round(2)
        res["diff"] = (amt - res["total_calculated"]).round(2)
        return res


def wrap_registry(registry: dict) -> dict:
    """Return a registry of LLM-backed processors given the deterministic one."""
    return {slug: LLMCarrierProcessor(proc) for slug, proc in registry.items()}
