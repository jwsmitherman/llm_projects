# Medical necessity guidance service

Transport.net posts a trip request when a requester submits an order. This
service returns three things: a clinical summary, a medical necessity flag, and
a clarifying question when one is needed.

## What this build does and does not do

**The contract is real. The determination is not.**

Every response comes back with `meetsMedicalNecessity: null`, `clarifyingQuestion:
null` and `meta.stub: true`. Nothing is evaluated. The CMS criteria and the model
call are developed separately and land here later.

That is deliberate, and it is why this exists now: DevOps can create the App
Service and run it through to production, and the UI can be built against a live
endpoint, without either waiting on model accuracy work.

`null` rather than `true` or `false` is also deliberate. This endpoint decides
whether a patient transport is billable. A default of either value would be
indistinguishable from a real determination, and something downstream would
eventually treat it as one. **Null means undetermined: let the trip submit
unchanged.**

## Run it

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
pytest
uvicorn app.main:app --reload --port 8000
```

| | |
|---|---|
| Interactive docs | http://127.0.0.1:8000/docs |
| OpenAPI schema | http://127.0.0.1:8000/openapi.json |
| Health | http://127.0.0.1:8000/health |

## For DevOps

Python 3.11 on App Service Linux. Nothing else: no database, no key vault, no
outbound calls, no secrets. The service has no external dependency it can fail
to reach, which is the point at this stage.

### Startup command

```
startup.sh
```

Set that in **Configuration → General settings → Startup Command**, or paste the
gunicorn line from `startup.sh` directly.

> **One thing worth knowing.** Azure's own Python docs give the startup command
> as `gunicorn -k uvicorn.workers.UvicornWorker ...`. That worker class was
> **removed in uvicorn 0.53** and now lives in the separate `uvicorn-worker`
> package, which is pinned in `requirements.txt`. The old path fails at boot
> with `ModuleNotFoundError` and shows up as a container that never starts.
> `startup.sh` already uses the current path.

### Application settings

| Setting | Value | Notes |
|---|---|---|
| `SCM_DO_BUILD_DURING_DEPLOYMENT` | `true` | Oryx installs `requirements.txt` |
| `ENVIRONMENT` | `dev` / `uat` / `prod` | reported on `/health` |
| `ENGINE` | `stub` | becomes `foundry` when the model lands |
| `BUILD_SOURCEVERSION` | set by the pipeline | ties a running instance to a commit |

### Health check path

```
/health
```

Cheap, depends on nothing external, safe to poll. Returns the version, the
environment, the commit and whether the engine is still a stub.

### Pipeline

`azure-pipelines.yml` builds and tests on every push. The deploy stage is
switched off until three variables at the top of that file are filled in:

```yaml
azureServiceConnection: ''   # ARM service connection name
appServiceName: ''           # the App Service
runDeploy: false             # set true once both exist
```

Deploy runs on `main` only and ends with a smoke test that polls `/health` until
it returns 200, so a broken deploy fails the pipeline rather than sitting there
looking green.

### What this service will need later, not now

Not required to stand the App Service up, listed so the sizing is not a surprise:

- **Outbound 443 to the Azure AI Foundry resource.** The App Service subnet will
  need this, and GMR's egress filter currently resets `*.services.ai.azure.com`
  by hostname. Worth raising early; it blocked local development for a day.
- **Managed identity** with a role on `aif-app-tmp-cus-dev`. No keys; they are
  disabled on that resource on purpose.
- **A longer request timeout.** A model call takes seconds, not milliseconds.
  `startup.sh` already sets gunicorn's timeout to 120s.

## For the UI

Build against `/docs`. The schema is the agreement; the values behind it are not
real yet.

Three fields at the top level are the only ones the UI acts on:

```jsonc
{
  "clinicalSummary": "...",          // two sentences for a biller, or null
  "meetsMedicalNecessity": true,     // or false, or null for undetermined
  "clarifyingQuestion": "..."        // or null, meaning ask nothing
}
```

`detail` carries per-question findings, criteria and citations. That is for
logging and analysis, not for the screen.

### Rendering every state before the model exists

Add `?stubResult=` to either endpoint:

| Value | What comes back | The UI should |
|---|---|---|
| `not_implemented` *(default)* | all three fields null | show nothing, submit normally |
| `meets` | flag true, no question | show nothing, submit normally |
| `does_not_meet` | flag false, no question | show the summary, submit |
| `needs_question` | flag false, question present | show the modal and collect an answer |

```bash
curl -X POST "http://127.0.0.1:8000/v1/medical-necessity/evaluate?stubResult=needs_question" \
  -H "Content-Type: application/json" \
  -d @sample_payloads/trip_request.json
```

Every one of these still returns `meta.stub: true`. If that field is ever false,
the engine is live.

### Both clarification patterns work

The meeting did not settle which one Transport.net will use, so both are here.
Pick one and the other can be deleted.

**A. Separate endpoint**

```jsonc
POST /v1/medical-necessity/reevaluate
{
  "tripRequest": { /* the original payload, unchanged */ },
  "clarification": { "question": "...", "answer": "..." }
}
```

**B. Two extra fields on the same payload**, null on the first call

```jsonc
POST /v1/medical-necessity/evaluate
{ /* trip request */, "clarifyingQuestion": "...", "clarifyingAnswer": "..." }
```

Either way `callType` comes back as `reevaluation`, and **a re-evaluation never
returns another question**. The requester is asked once.

### Correlation

Send `x-correlation-id` on any request and it comes back on the response, along
with `x-processing-ms`. If you do not send one, the service generates it. Every
request logs one line carrying it.

## What the service reads

Only `tripLegs[].losQuestions` — the question and answer pairs. Patient name,
date of birth, SSN, MRN and insurance are **not read and should not be sent.**

This matters beyond tidiness. Minimising what crosses the boundary is the
simplest answer to the data-handling questions at review, and `sample_payloads/`
carries no patient block at all for the same reason. Real payloads must not be
committed to this repo.

Unknown fields are accepted rather than rejected. Transport.net owns that payload
and it will grow; rejecting unknown fields would mean a coordinated release every
time it does. Identifier fields accept integers or strings, because
`requesterFacilityId` is an int while `olosRequestId` is a uuid string, and the
service only echoes them.

## Errors

| Status | Meaning | What the caller does |
|---|---|---|
| 200 | evaluated, possibly as a stub | act on the three fields |
| 422 | payload could not be parsed | log it, submit the trip unchanged |
| 500 | something broke | log it, submit the trip unchanged |

A 500 returns a flat JSON object with an `action` field, never a stack trace.
Transport.net holds the submission while this call is in flight, so an error has
to be something it can act on without parsing.

```json
{
  "error": "internal_error",
  "message": "The guidance service could not complete this request.",
  "action": "Submit the trip unchanged."
}
```

## Layout

```
app/
  main.py              app, middleware, error handling
  config.py            settings from the environment
  models.py            the request and response contract
  routers/
    health.py          /health
    evaluate.py        /v1/medical-necessity/*
tests/                 24 tests, run in the pipeline
sample_payloads/
  trip_request.json    synthetic, no patient block
startup.sh             App Service startup command
azure-pipelines.yml    build, test, deploy
requirements.txt       pinned to tested versions
```

## When the model lands

Only `app/routers/evaluate.py` changes: `stub_body()` is replaced by the call
that compiles the CMS criteria into an instruction and returns a real
determination. `ENGINE` moves from `stub` to `foundry`, which flips `meta.stub`
to false.

The contract, the routes, the timing fields, the correlation header and both
clarification patterns stay exactly as they are. The UI does not change.
