import json
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)
EVALUATE = "/v1/medical-necessity/evaluate"
REEVALUATE = "/v1/medical-necessity/reevaluate"

SAMPLE = json.loads(
    (Path(__file__).parent.parent / "sample_payloads" / "trip_request.json").read_text()
)


def test_accepts_the_sample_payload():
    r = client.post(EVALUATE, json=SAMPLE)
    assert r.status_code == 200


def test_returns_the_three_ui_fields():
    body = client.post(EVALUATE, json=SAMPLE).json()
    for field in ("clinicalSummary", "meetsMedicalNecessity", "clarifyingQuestion"):
        assert field in body


def test_makes_no_determination_by_default():
    """The one that matters. A stub must never look like a real answer."""
    body = client.post(EVALUATE, json=SAMPLE).json()
    assert body["meetsMedicalNecessity"] is None
    assert body["clarifyingQuestion"] is None
    assert body["meta"]["stub"] is True
    assert body["detail"]["determination"] == "not_implemented"


def test_echoes_identifiers():
    body = client.post(EVALUATE, json=SAMPLE).json()
    assert body["olosRequestId"] == SAMPLE["olosRequestId"]
    assert body["correlationId"] == SAMPLE["correlationId"]
    assert body["levelOfService"] == SAMPLE["tripLegs"][0]["levelOfService"]


def test_counts_answered_questions_only():
    body = client.post(EVALUATE, json=SAMPLE).json()
    answered = sum(1 for q in SAMPLE["tripLegs"][0]["losQuestions"] if (q.get("answer") or "").strip())
    assert body["meta"]["questionsReceived"] == answered


def test_unknown_payload_fields_are_accepted():
    """Transport.net owns this payload and it will grow."""
    payload = dict(SAMPLE, someFieldAddedLater={"nested": True})
    assert client.post(EVALUATE, json=payload).status_code == 200


def test_empty_payload_is_accepted():
    r = client.post(EVALUATE, json={})
    assert r.status_code == 200
    assert r.json()["meta"]["questionsReceived"] == 0


def test_stub_result_meets():
    body = client.post(f"{EVALUATE}?stubResult=meets", json=SAMPLE).json()
    assert body["meetsMedicalNecessity"] is True
    assert body["clarifyingQuestion"] is None
    assert body["meta"]["stub"] is True


def test_stub_result_needs_question():
    body = client.post(f"{EVALUATE}?stubResult=needs_question", json=SAMPLE).json()
    assert body["meetsMedicalNecessity"] is False
    assert body["clarifyingQuestion"]
    assert body["meta"]["stub"] is True


def test_every_stub_result_is_still_flagged_as_a_stub():
    for result in ("not_implemented", "meets", "does_not_meet", "needs_question"):
        body = client.post(f"{EVALUATE}?stubResult={result}", json=SAMPLE).json()
        assert body["meta"]["stub"] is True, result


def test_invalid_stub_result_is_rejected():
    assert client.post(f"{EVALUATE}?stubResult=whatever", json=SAMPLE).status_code == 422


def test_call_type_initial_by_default():
    assert client.post(EVALUATE, json=SAMPLE).json()["callType"] == "initial"


def test_inline_clarification_routes_to_reevaluation():
    """The second integration pattern: two extra fields on the same payload."""
    payload = dict(SAMPLE, clarifyingQuestion="Why not a wheelchair?",
                   clarifyingAnswer="Stroke last week, dense left sided weakness.")
    body = client.post(EVALUATE, json=payload).json()
    assert body["callType"] == "reevaluation"
    assert body["clarification"]["answer"].startswith("Stroke last week")


def test_reevaluate_endpoint():
    body = client.post(REEVALUATE, json={
        "tripRequest": SAMPLE,
        "clarification": {"question": "Why not a wheelchair?", "answer": "Dense left sided weakness."},
    }).json()
    assert body["callType"] == "reevaluation"
    assert body["clarification"]["question"] == "Why not a wheelchair?"


def test_reevaluation_never_asks_again():
    """The requester is asked once. Asking twice is a workflow bug."""
    body = client.post(f"{REEVALUATE}?stubResult=needs_question", json={
        "tripRequest": SAMPLE,
        "clarification": {"question": "Why not a wheelchair?", "answer": "Dense left sided weakness."},
    }).json()
    assert body["clarifyingQuestion"] is None


def test_reevaluate_requires_a_clarification():
    assert client.post(REEVALUATE, json={"tripRequest": SAMPLE}).status_code == 422


def test_timing_fields_present():
    meta = client.post(EVALUATE, json=SAMPLE).json()["meta"]
    assert meta["receivedAtUtc"].endswith("Z")
    assert meta["respondedAtUtc"].endswith("Z")
    assert isinstance(meta["processingMs"], int)


def test_evaluation_ids_are_unique():
    a = client.post(EVALUATE, json=SAMPLE).json()["evaluationId"]
    b = client.post(EVALUATE, json=SAMPLE).json()["evaluationId"]
    assert a != b


# --------------------------------------------------------------------------
# Guards for the three ways a non-determination could have looked like a real
# one. Each of these was a real defect found in review, not a hypothetical.
# --------------------------------------------------------------------------


def test_stub_flag_cannot_be_turned_off_by_configuration():
    """meta.stub follows the code that produced the body, not a setting.

    The flag is the only thing telling a consumer the determination is not
    real. If an environment variable could clear it while stub_body still
    produced the answer, a placeholder would arrive labelled as genuine.
    """
    import app.config as config

    assert config.is_stub() is True
    body = client.post(EVALUATE, json=SAMPLE).json()
    assert body["meta"]["stub"] is True
    assert body["meetsMedicalNecessity"] is None


def test_stub_override_is_ignored_outside_a_development_instance(monkeypatch):
    """?stubResult= must not let a caller choose the determination in prod.

    A consumer acting on the flag could approve or block a trip on example data
    the caller picked.
    """
    import app.config as config

    monkeypatch.setattr(config, "ENVIRONMENT", "prod")
    body = client.post(f"{EVALUATE}?stubResult=meets", json=SAMPLE).json()
    assert body["meetsMedicalNecessity"] is None
    assert body["meta"]["stub"] is True

    body = client.post(f"{REEVALUATE}?stubResult=meets", json={
        "tripRequest": SAMPLE,
        "clarification": {"question": "q", "answer": "a"},
    }).json()
    assert body["meetsMedicalNecessity"] is None


def test_stub_override_still_works_on_a_development_instance(monkeypatch):
    import app.config as config

    monkeypatch.setattr(config, "ENVIRONMENT", "dev")
    body = client.post(f"{EVALUATE}?stubResult=meets", json=SAMPLE).json()
    assert body["meetsMedicalNecessity"] is True
    assert body["meta"]["stub"] is True   # still an example, and still says so


def test_question_count_covers_every_leg():
    """tripLegs is a list. Counting only index 0 under-reports a multi-leg trip."""
    import copy

    two_legs = copy.deepcopy(SAMPLE)
    first = two_legs["tripLegs"][0]
    second = copy.deepcopy(first)
    two_legs["tripLegs"].append(second)

    answered_one_leg = sum(
        1 for q in first["losQuestions"] if (q.get("answer") or "").strip())

    body = client.post(EVALUATE, json=two_legs).json()
    assert body["meta"]["questionsReceived"] == answered_one_leg * 2
