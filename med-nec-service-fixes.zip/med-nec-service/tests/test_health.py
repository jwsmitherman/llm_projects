from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health_returns_ok():
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["service"] == "med-nec-guidance"


def test_healthz_alias():
    assert client.get("/healthz").status_code == 200


def test_health_declares_stub_engine():
    """If this fails, something claims to be making real determinations."""
    body = client.get("/health").json()
    assert body["stub"] is True
    assert body["engine"] == "stub"


def test_correlation_id_echoed():
    r = client.get("/health", headers={"x-correlation-id": "abc-123"})
    assert r.headers["x-correlation-id"] == "abc-123"


def test_correlation_id_generated_when_absent():
    assert client.get("/health").headers.get("x-correlation-id")


def test_openapi_builds():
    """The UI codes against this. A broken schema is a broken contract."""
    schema = client.get("/openapi.json").json()
    assert "/v1/medical-necessity/evaluate" in schema["paths"]
    assert "/v1/medical-necessity/reevaluate" in schema["paths"]
