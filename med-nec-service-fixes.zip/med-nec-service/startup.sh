#!/bin/bash
# App Service Linux startup command.
#
# uvicorn.workers.UvicornWorker was REMOVED in uvicorn 0.53. The worker class
# now lives in the separate uvicorn-worker package, which is pinned in
# requirements.txt. Using the old path fails at boot with ModuleNotFoundError.
#
# Set this as the App Service startup command:
#     startup.sh
# or paste the gunicorn line directly into Configuration > General settings.

exec gunicorn app.main:app \
  --bind=0.0.0.0:8000 \
  --worker-class uvicorn_worker.UvicornWorker \
  --workers 2 \
  --timeout 120 \
  --access-logfile '-' \
  --error-logfile '-'
