"""Request and response contract for the medical necessity guidance service.

This is the part the UI codes against. The shapes here are the agreement; the
values behind them are stubbed until the model is wired in.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Annotated, Any, Dict, List, Optional

from pydantic import BaseModel, BeforeValidator, Field


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _coerce_id(value: Any) -> Optional[str]:
    """Identifiers arrive as ints or strings depending on the field.

    requesterFacilityId is an int, olosRequestId is a uuid string, and which is
    which is not ours to decide. The service never interprets these, it only
    echoes them, so accept either and normalise to string rather than making an
    integration fail over a type we do not use.
    """
    if value is None:
        return None
    return str(value)


Identifier = Annotated[Optional[str], BeforeValidator(_coerce_id)]


class Determination(str, Enum):
    MEETS = "meets"
    DOES_NOT_MEET = "does_not_meet"
    NEEDS_REVIEW = "needs_review"
    NOT_IMPLEMENTED = "not_implemented"


class Confidence(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class StubResult(str, Enum):
    """Lets the UI exercise every render path before the model exists."""
    NOT_IMPLEMENTED = "not_implemented"
    MEETS = "meets"
    DOES_NOT_MEET = "does_not_meet"
    NEEDS_QUESTION = "needs_question"


# --------------------------------------------------------------------------
# inbound
# --------------------------------------------------------------------------

class LosQuestion(BaseModel):
    questionId: Optional[int] = Field(None, description="Transport.net question identifier.")
    questionText: Optional[str] = Field(None, description="The question as the requester saw it.")
    answer: Optional[str] = Field(None, description="The selected answer.")
    answerValue: Optional[str] = Field(None, description="Free text, when the answer allows it.")

    model_config = {"extra": "allow"}


class TripLeg(BaseModel):
    legId: Identifier = None
    levelOfService: Optional[str] = Field(None, description="BLS, ALS, wheelchair van, and so on.")
    originFacilityId: Identifier = None
    destinationFacilityId: Identifier = None
    losQuestions: List[LosQuestion] = Field(default_factory=list)
    clinicalData: Optional[str] = Field(None, description="Flattened form text, when questions are absent.")

    model_config = {"extra": "allow"}


class TripRequest(BaseModel):
    """Posted on trip submission. Extra fields are kept, not rejected.

    Transport.net owns this payload and it will grow. Rejecting unknown fields
    would mean a coordinated release every time it does, so this accepts them.
    """
    olosRequestId: Identifier = None
    correlationId: Identifier = None
    sourceSystemTripId: Identifier = None
    requesterFacilityId: Identifier = None
    requesterFacility: Optional[str] = None
    tripReason: Optional[str] = None
    tripLegs: List[TripLeg] = Field(default_factory=list)

    clarifyingQuestion: Optional[str] = Field(
        None, description="Set on a second call, carrying the question already asked.")
    clarifyingAnswer: Optional[str] = Field(
        None, description="Set on a second call, carrying what the requester typed.")

    model_config = {"extra": "allow"}


class Clarification(BaseModel):
    question: str
    answer: str


class ReevaluateRequest(BaseModel):
    tripRequest: TripRequest
    clarification: Clarification


# --------------------------------------------------------------------------
# outbound
# --------------------------------------------------------------------------

class CriterionFinding(BaseModel):
    criterionId: Optional[str] = None
    citation: Optional[str] = Field(None, description="Where in CMS guidance this comes from.")
    evidence: Optional[str] = Field(None, description="Verbatim answer text the criterion rests on.")
    questionId: Optional[int] = None


class QuestionFinding(BaseModel):
    questionId: Optional[int] = None
    question: Optional[str] = None
    answer: Optional[str] = None
    nonMedNec: Optional[bool] = None
    category: Optional[str] = None
    criterionId: Optional[str] = None
    citation: Optional[str] = None
    evidence: Optional[str] = None
    reason: Optional[str] = None
    confidence: Optional[Confidence] = None


class EvaluationDetail(BaseModel):
    """Logged and analysed, not shown to the requester."""
    determination: Determination = Determination.NOT_IMPLEMENTED
    basis: Optional[str] = None
    confidence: Optional[Confidence] = None
    criteriaDocumented: List[CriterionFinding] = Field(default_factory=list)
    exclusionsTriggered: List[Dict[str, Any]] = Field(default_factory=list)
    questionFindings: List[QuestionFinding] = Field(default_factory=list)


class ResponseMeta(BaseModel):
    service: str
    serviceVersion: str
    engine: str = Field(..., description="'stub' until the model deployment is wired in.")
    stub: bool = Field(..., description="True means no determination was made. Never persist as clinical.")
    knowledgeVersion: Optional[str] = None
    questionsReceived: int = 0
    receivedAtUtc: str
    respondedAtUtc: str
    processingMs: int


class EvaluationResponse(BaseModel):
    """The three top level fields are the only ones the UI acts on."""
    evaluationId: str
    olosRequestId: Identifier = None
    correlationId: Identifier = None
    sourceSystemTripId: Identifier = None
    levelOfService: Optional[str] = None
    callType: str = Field(..., description="'initial' or 'reevaluation'.")

    clinicalSummary: Optional[str] = Field(
        None, description="Two sentences for a biller. Null when nothing was determined.")
    meetsMedicalNecessity: Optional[bool] = Field(
        None, description="Null means undetermined. Treat null as 'do not block the submission'.")
    clarifyingQuestion: Optional[str] = Field(
        None, description="Null means ask nothing and let the trip submit.")

    detail: EvaluationDetail
    meta: ResponseMeta
    clarification: Optional[Clarification] = None


class HealthResponse(BaseModel):
    status: str
    service: str
    serviceVersion: str
    engine: str
    stub: bool
    environment: Optional[str] = None
    commit: Optional[str] = None
    timeUtc: str
