"""Settings, read from the environment.

App Service supplies these through Application Settings. Nothing here is a
secret and nothing here needs a key vault yet; when the model is wired in it
authenticates with the App Service managed identity.
"""

import os

SERVICE_NAME = "med-nec-guidance"
SERVICE_VERSION = "0.1.0"

# Set by the pipeline so a running instance can be traced to a commit.
BUILD_COMMIT = os.environ.get("BUILD_SOURCEVERSION") or os.environ.get("GIT_COMMIT")
ENVIRONMENT = os.environ.get("ENVIRONMENT", "dev")

# Not configurable, and not an oversight. There is no real engine in this
# release: every response body comes from stub_body(). meta.stub is the only
# thing telling a consumer that a determination is not real, so it must follow
# the code that produced the answer, never a setting. Read from the environment,
# an operator could set ENGINE=foundry in Application Settings and turn a stub
# body into one labelled stub=false, on an endpoint that decides billability.
#
# When the model is wired in, do not flip this constant. Have the real branch
# report stub=false for itself, so the flag cannot outrun the implementation.
ENGINE = "stub"

KNOWLEDGE_VERSION = os.environ.get("KNOWLEDGE_VERSION")


def is_stub() -> bool:
    return ENGINE == "stub"


def stub_override_allowed() -> bool:
    """Whether ?stubResult= may choose the shape of the example returned.

    A UI development aid, and dangerous anywhere else: a caller who can pick the
    determination can pick the one that gets a trip approved. Off unless the
    environment says this instance exists for development.
    """
    return ENVIRONMENT.strip().lower() in ("dev", "local", "development")
