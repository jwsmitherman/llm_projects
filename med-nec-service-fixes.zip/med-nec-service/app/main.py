"""Medical necessity guidance service.

Transport.net posts a trip request on submission and gets back a clinical
summary, a medical necessity flag and a clarifying question when one is needed.

The contract is settled and this service implements it. The determination
behind it is not wired in yet, so every response carries meta.stub = true.
"""

import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app import config
from app.routers import evaluate, health

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
log = logging.getLogger("med-nec")


@asynccontextmanager
async def lifespan(_: FastAPI):
    log.info(
        "%s %s starting, environment=%s engine=%s stub=%s commit=%s",
        config.SERVICE_NAME, config.SERVICE_VERSION, config.ENVIRONMENT,
        config.ENGINE, config.is_stub(), config.BUILD_COMMIT or "unknown",
    )
    yield
    log.info("%s shutting down", config.SERVICE_NAME)


app = FastAPI(
    lifespan=lifespan,
    title="Medical necessity guidance service",
    version=config.SERVICE_VERSION,
    description=(
        "Evaluates a non-emergent ground ambulance trip request against CMS medical "
        "necessity criteria at order entry.\n\n"
        "**This build makes no determination.** The request and response contract is "
        "real and is what the UI should be built against, but `meetsMedicalNecessity` "
        "comes back null and `meta.stub` is true on every response. Use the "
        "`stubResult` query parameter to render the other states."
    ),
    contact={"name": "Josh Smitherman"},
)

app.include_router(health.router)
app.include_router(evaluate.router)


@app.middleware("http")
async def correlate_and_time(request: Request, call_next):
    """One log line per request, with a correlation id the caller can supply."""
    correlation_id = request.headers.get("x-correlation-id") or str(uuid.uuid4())
    started = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = int((time.perf_counter() - started) * 1000)
    response.headers["x-correlation-id"] = correlation_id
    response.headers["x-processing-ms"] = str(elapsed_ms)
    log.info(
        "%s %s -> %s in %dms correlation=%s",
        request.method, request.url.path, response.status_code, elapsed_ms, correlation_id,
    )
    return response


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception) -> JSONResponse:
    """Never leak a stack trace to the caller.

    Transport.net holds the trip submission while this call is in flight, so an
    error here must be something it can act on rather than something it has to
    parse. It proceeds with the submission unchanged.
    """
    log.exception("unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_error",
            "message": "The guidance service could not complete this request.",
            "action": "Submit the trip unchanged.",
        },
    )
