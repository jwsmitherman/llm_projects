"""Health and readiness.

App Service pings the health check path to decide whether an instance is in
rotation, so this stays cheap and depends on nothing external.
"""

from fastapi import APIRouter

from app import config
from app.models import HealthResponse, utc_now

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse, summary="Liveness and build info")
@router.get("/healthz", response_model=HealthResponse, include_in_schema=False)
def health() -> HealthResponse:
    return HealthResponse(
        status="ok",
        service=config.SERVICE_NAME,
        serviceVersion=config.SERVICE_VERSION,
        engine=config.ENGINE,
        stub=config.is_stub(),
        environment=config.ENVIRONMENT,
        commit=config.BUILD_COMMIT,
        timeUtc=utc_now(),
    )
