"""Medical necessity evaluation.

The contract is real and settled. The determination behind it is not: every
response carries meta.stub = true and meetsMedicalNecessity = null until the
Foundry model is wired in.

A null flag is deliberate rather than a default of true or false. Either of
those would be indistinguishable from a real determination, and this endpoint
decides whether a patient transport is billable. Null means undetermined, and
the caller should let the trip submit unchanged.

The UI still needs to build every render path, so ?stubResult= returns a shaped
example of each. Those responses also carry meta.stub = true.
"""

import time
import uuid
from typing import Optional

from fastapi import APIRouter, Query

from app import config
from app.models import (
    Clarification,
    Confidence,
    Determination,
    EvaluationDetail,
    EvaluationResponse,
    ReevaluateRequest,
    ResponseMeta,
    StubResult,
    TripRequest,
    utc_now,
)

router = APIRouter(prefix="/v1/medical-necessity", tags=["medical necessity"])

EXAMPLE_SUMMARY = (
    "Example only, no determination was made. Patient discharged to a residence "
    "following a stay for deconditioning, with general weakness recorded as the "
    "reason for ambulance transport."
)
EXAMPLE_QUESTION = (
    "Example only, no determination was made. What about this patient's condition "
    "prevents them from sitting safely in a wheelchair while the vehicle is in motion?"
)


def question_count(trip: TripRequest) -> int:
    # Every leg, not just the first. tripLegs is a list and the inbound model
    # accepts several, so counting index 0 alone under-reports a multi-leg trip.
    if not trip.tripLegs:
        return 0
    return sum(
        1
        for leg in trip.tripLegs
        for q in (leg.losQuestions or [])
        if (q.answer or "").strip()
    )


def stub_body(result: StubResult) -> tuple[Optional[str], Optional[bool], Optional[str], EvaluationDetail]:
    """Shaped examples so the UI can build every path. Never a determination."""
    if result is StubResult.MEETS:
        return (
            EXAMPLE_SUMMARY,
            True,
            None,
            EvaluationDetail(
                determination=Determination.MEETS,
                basis="Example only. No criteria were evaluated.",
                confidence=Confidence.HIGH,
            ),
        )
    if result is StubResult.DOES_NOT_MEET:
        return (
            EXAMPLE_SUMMARY,
            False,
            None,
            EvaluationDetail(
                determination=Determination.DOES_NOT_MEET,
                basis="Example only. No criteria were evaluated.",
                confidence=Confidence.MEDIUM,
            ),
        )
    if result is StubResult.NEEDS_QUESTION:
        return (
            EXAMPLE_SUMMARY,
            False,
            EXAMPLE_QUESTION,
            EvaluationDetail(
                determination=Determination.NEEDS_REVIEW,
                basis="Example only. No criteria were evaluated.",
                confidence=Confidence.LOW,
            ),
        )
    return (
        None,
        None,
        None,
        EvaluationDetail(
            determination=Determination.NOT_IMPLEMENTED,
            basis=(
                "The guidance engine is not wired in. No determination was made. "
                "Submit the trip unchanged."
            ),
        ),
    )


def build(
    trip: TripRequest,
    call_type: str,
    received_at: str,
    started: float,
    stub_result: StubResult,
    clarification: Optional[Clarification] = None,
) -> EvaluationResponse:
    # The shape switch is a development aid. Outside a dev instance it is
    # ignored rather than rejected, so a stray query string cannot get a
    # caller-chosen medical necessity flag back from a deployed endpoint.
    if not config.stub_override_allowed():
        stub_result = StubResult.NOT_IMPLEMENTED

    summary, meets, question, detail = stub_body(stub_result)

    # True because stub_body produced the answer above, not because a setting
    # says so. The real engine, when it exists, reports for itself.
    produced_by_stub = True

    # The requester is asked once. A second call never asks again.
    if call_type == "reevaluation":
        question = None

    leg = trip.tripLegs[0] if trip.tripLegs else None

    return EvaluationResponse(
        evaluationId=str(uuid.uuid4()),
        olosRequestId=trip.olosRequestId,
        correlationId=trip.correlationId,
        sourceSystemTripId=trip.sourceSystemTripId,
        levelOfService=leg.levelOfService if leg else None,
        callType=call_type,
        clinicalSummary=summary,
        meetsMedicalNecessity=meets,
        clarifyingQuestion=question,
        detail=detail,
        clarification=clarification,
        meta=ResponseMeta(
            service=config.SERVICE_NAME,
            serviceVersion=config.SERVICE_VERSION,
            engine=config.ENGINE,
            stub=produced_by_stub,
            knowledgeVersion=config.KNOWLEDGE_VERSION,
            questionsReceived=question_count(trip),
            receivedAtUtc=received_at,
            respondedAtUtc=utc_now(),
            processingMs=int((time.perf_counter() - started) * 1000),
        ),
    )


@router.post(
    "/evaluate",
    response_model=EvaluationResponse,
    summary="Evaluate a trip request on submission",
    description=(
        "Called when the requester submits a trip. Returns a clinical summary, a "
        "medical necessity flag and a clarifying question.\n\n"
        "**No determination is made yet.** `meetsMedicalNecessity` comes back null "
        "and `meta.stub` is true. Treat null as 'do not block the submission'.\n\n"
        "Use `?stubResult=` to exercise the other render paths while building the UI. "
        "It is honoured only on a development instance and ignored everywhere else, "
        "so a deployed endpoint cannot be asked for a chosen determination."
    ),
)
def evaluate(
    trip: TripRequest,
    stubResult: StubResult = Query(
        StubResult.NOT_IMPLEMENTED,
        description=(
            "Shape of the example to return. Development instances only; "
            "ignored on any other environment.")),
) -> EvaluationResponse:
    received_at = utc_now()
    started = time.perf_counter()

    call_type = "reevaluation" if (trip.clarifyingQuestion and trip.clarifyingAnswer) else "initial"
    clarification = None
    if call_type == "reevaluation":
        clarification = Clarification(question=trip.clarifyingQuestion, answer=trip.clarifyingAnswer)

    return build(trip, call_type, received_at, started, stubResult, clarification)


@router.post(
    "/reevaluate",
    response_model=EvaluationResponse,
    summary="Re-evaluate after the requester answers",
    description=(
        "Called once the requester has answered the clarifying question. Returns the "
        "same shape with an updated summary and flag, and never asks again.\n\n"
        "Both integration patterns are supported. This endpoint is one; the other is "
        "to post the original payload back to `/evaluate` with `clarifyingQuestion` "
        "and `clarifyingAnswer` populated. Pick one and the other can be dropped."
    ),
)
def reevaluate(
    request: ReevaluateRequest,
    stubResult: StubResult = Query(
        StubResult.NOT_IMPLEMENTED,
        description=(
            "Shape of the example to return. Development instances only; "
            "ignored on any other environment.")),
) -> EvaluationResponse:
    received_at = utc_now()
    started = time.perf_counter()
    return build(
        request.tripRequest, "reevaluation", received_at, started,
        stubResult, request.clarification,
    )
