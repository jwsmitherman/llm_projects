"""Strip identifiers from a Transport.net trip request before it leaves for the model.

Design note, because this is the part that matters most.

The rule here is ALLOW, not DENY. A deny list is only as good as the author's
imagination, and nobody on this project has seen a production payload until now;
a field we have never met is exactly the field likely to carry a name. So every
field is dropped unless it is named below, and any field we do not recognise at
all is reported as UNKNOWN so a person decides, rather than being passed through
on the assumption that it looked harmless.

What the service actually reads is a short list: the clinical question and answer
pairs, the level of service, the origin and destination codes, and the trip
reason. Everything else exists to make the payload realistic and is not needed to
reach a determination.
"""

import json
import re
from typing import Any, Dict, List, Tuple

# ---------------------------------------------------------------- what we keep

# Top level. These reach the model or are needed to trace a row back to a trip.
KEEP_TOP = {
    "olosRequestId", "correlationId", "sourceSystemTripId", "requestDateTime",
    "tripReason", "tripReasonId", "contractId", "isRoundTrip",
    "msgActionType", "msgObjType", "configVersionId",
    "tripComment", "tripReasonQuestions",
    "requestType", "requestTypeId", "requestConfigType", "requestorType",
    "isTransferFacility", "isApprovalRequired", "roundTripType",
}

# Recognised, not identifying, and nothing the model needs. Dropped without
# comment so the UNKNOWN list stays short enough to actually read.
KNOWN_NONCLINICAL_TOP = {
    "allowPastTrips", "eligibilityCheckOnly", "idenCovid", "skipEligibility",
    "skipQueues", "requestQuickOrder", "returnTripPickupTime", "waitTimeMins",
    "userSelectedProviders", "isSigningRequired", "isUserTypeSigningReq",
    "isCallerFacilitySearchable", "isNotifyFacilitySearchable", "isReqFacilitySearchable",
}
KNOWN_NONCLINICAL_LEG = {
    "expiredSecs", "idenStandBy", "idenStandByActivated", "slaId",
    "sourceSystemTripLegId", "tripConcierge",
    # Authorisation and insurance. Not clinical, and payer-identifying.
    "insuranceInfo", "preauthNumber", "preCheckAuth", "preCheckBroker",
    "preCheckMatrixId", "referenceNumber",
}

# Trip leg. The clinical content plus the context Dave asked to see on screen.
KEEP_LEG = {
    "clinicalData", "losQuestions", "medicareQuestionTen", "additionalFields",
    "levelOfService", "losCategory", "losCategoryLabel", "systemLos",
    "losReason", "losOverride", "losOverrideReason",
    "pickupLocTypeCode", "dropoffLocTypeCode",
    "pickupFacilityTypeId", "dropoffFacilityTypeId",
    "facilityPayReason", "facilityPayReasonId", "facPayOverrideReason",
    "apptTime", "msgReceived", "slaTypeId", "SLA",
    "tripLegId", "legNumber", "isTransfer",
    # Free text. Kept because it is often where the "why" lives, which is the
    # thing Dave keeps saying the check boxes lost. Scrubbed like clinicalData.
    "specialNeeds", "transRequestComment",
    # Context the model can reason about without identifying anyone.
    "transportDistance", "transportDuration", "transportDurationTraffic", "tripMiles",
    "idenOneWay", "idenReccur", "idenNow", "idenWillCall", "isApptTime",
    "medicareQuestionNums", "facilityPayOverride",
}

# Free text fields anywhere in the payload. Kept, but never passed through
# unscrubbed: a box a human can type into is a box a name can end up in.
FREE_TEXT_LEG = ("clinicalData", "specialNeeds", "transRequestComment", "losReason",
                 "losOverrideReason", "facPayOverrideReason")
FREE_TEXT_TOP = ("tripComment",)

# patientInfo is blanked except for these. The units are structural, the payload
# is malformed without them. The rest is clinical content, not identity, and
# dropping it was costing the model the two things a human reads first: what is
# wrong with the patient, and how much they weigh.
#
# diagnosis is typed by a human, so it is scrubbed like any other free text.
# Weight and height decide whether a bariatric unit and extra crew are needed,
# which is a mobility question the check boxes do not always answer.
KEEP_PATIENT = {
    "heightUnit", "weightUnit",
    "diagnosis", "patientWeight", "patientHeight",
    "overMaxWeight", "patientOver300Lbs",
}

FREE_TEXT_PATIENT = ("diagnosis",)

# additionalFields is the rest of the form: an array of {name, label, section,
# dataType, value, selectedLabel}. It used to be dropped whole, which is what
# Mukund meant by "the question and answer is not complete because we are not
# giving all the information in the form" - the drop-downs, the toggles and the
# clinical notes all live here, and none of them were reaching the model.
#
# Allow-listed by name, like everything else. An unrecognised name is dropped
# and surfaced, so a new field added to the form shows up for classification
# instead of silently going to the model or silently disappearing.
KEEP_ADDITIONAL = {
    # Level of service and the reason for the trip.
    "svcLineReq", "locReq", "transferReason", "ptTransBy", "transArrangement",
    "chiefComplaint", "chiefComplaintDesc", "losClinicalNotes",
    # Patient condition and what the transport needs.
    "ptIntubated", "numOfDrips", "specialEquip", "clinicalNotes", "ptCovid",
    "addlRiderWeight", "multipleUnits",
    # Origin and destination facts that bear on mobility and on coverage.
    "pUpPtResidence", "destPtResidence", "destPtResidenceKeys",
    "pUpResidenceStairs", "destResidenceStairs",
    # inpatStay, not admitDate: "transport following inpatient stay?" is what
    # the Part A question turns on, and a bare admit date is both a HIPAA
    # identifier and something the residual scan would hold the trip back over.
    "inpatStay",
    # Air service context. Not med nec itself, but it is why some ground
    # transports exist, and the model is told to weigh the reason for transport.
    "svcWeatherDecline", "svcOtherRespond",
}

KNOWN_IDENTIFYING_ADDITIONAL = {
    "destPtReceivingName", "destPtReceivingNum", "groundContact",
    "addlRiderName", "addlRiderDob", "admitDate",
}

# Which of the kept ones a human types into.
FREE_TEXT_ADDITIONAL = {
    "chiefComplaintDesc", "losClinicalNotes", "clinicalNotes", "specialEquip",
    "numOfDrips", "ptCovid", "transferReason",
}

# Fields we know exist and know to be identifying. Named so an unknown field is
# genuinely unknown rather than merely unlisted.
KNOWN_IDENTIFYING_TOP = {
    "requesterName", "requesterFirstName", "requesterLastName", "requesterId",
    "requesterPhone", "requesterFacility", "requesterFacilityId", "requesterOffset",
    "createdBy", "createdByEmail", "approvedBy", "approvedByOffset", "dateApprovedBy",
    "notifyName", "notifyEmail", "notifyPhone", "notifyPhoneExt", "notifyFacilityId",
    "preferredNotifyMethod", "callerFacilityId", "department", "reqEntity", "reqRole",
    "reqPrimPhone", "reqPrimPhType", "reqSecPhone", "reqSecPhType",
    "signedBy", "signedByName", "signedByCredentials", "signedByEmailAddress",
    "signedByLicenseNo", "signedByOffset", "signedByPhoneNumber",
    "signedByPhoneNumberExt", "signedByProfession", "dateSignedBy",
    "pcsId", "contractName", "draftSystemId", "systemId",
}

KNOWN_IDENTIFYING_LEG_PREFIX = ("pickup", "dropoff")
KNOWN_IDENTIFYING_LEG = {
    "additionalPassengers", "additionalInsurances", "attachments",
    "authorizedBy", "addlAuthorizedBy", "addlAuthNumber", "addlAuthNumberNpi",
    "cadId", "cadUserId",
    "displayPickupTime", "displayApptTime",
}

# Free text patterns. The structured fields are handled by the allow list; these
# catch what a requester typed into a box.
PATTERNS: List[Tuple[str, "re.Pattern[str]"]] = [
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("DOB", re.compile(r"\b\d{1,2}/\d{1,2}/(?:19|20)\d{2}\b")),
    ("DATE", re.compile(r"\b(?:19|20)\d{2}-\d{1,2}-\d{1,2}\b")),
    ("MRN", re.compile(r"\b(?:mrn|medical record(?:\s*(?:no|number|#))?)\s*[:#]?\s*[A-Za-z0-9-]+",
                       re.IGNORECASE)),
    ("ACCOUNT", re.compile(r"\b(?:acct|account|visit|encounter)\s*(?:no|number|#)?\s*[:#]\s*[A-Za-z0-9-]+",
                           re.IGNORECASE)),
    ("PHONE", re.compile(r"\(?\b\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.]+\b")),
]


def _scrub_text(text: str, extra_names: List[str]) -> Tuple[str, List[str]]:
    """Mask patterns and any known name, returning the text and what was hit."""
    if not isinstance(text, str) or not text.strip():
        return text, []

    hits: List[str] = []

    # The patient's own name, taken from patientInfo before it is blanked. A
    # requester who typed the name into a free text box is the case a pattern
    # cannot catch, and this is the one chance to catch it by knowing the answer.
    for name in extra_names:
        name = (name or "").strip()
        if len(name) < 3:
            continue
        pattern = re.compile(r"\b" + re.escape(name) + r"\b", re.IGNORECASE)
        if pattern.search(text):
            text = pattern.sub("[NAME]", text)
            hits.append("NAME")

    for label, pattern in PATTERNS:
        if pattern.search(text):
            text = pattern.sub(f"[{label}]", text)
            hits.append(label)

    return text, hits


def deidentify(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Return a cleaned copy plus a report of what was dropped, masked, unknown."""
    report: Dict[str, Any] = {
        "droppedTop": [], "droppedLeg": [], "unknownTop": [], "unknownLeg": [],
        "maskedIn": [], "patternsHit": [], "patientFieldsCleared": [],
    }

    # Names first: needed to scrub free text, and gone from the output after.
    names: List[str] = []
    legs_in = payload.get("tripLegs") or []
    for leg in legs_in:
        info = (leg or {}).get("patientInfo") or {}
        for key in ("firstName", "lastName", "middleName"):
            value = info.get(key)
            if isinstance(value, str) and value.strip():
                names.append(value.strip())
        for key in info:
            if key not in KEEP_PATIENT and info.get(key) not in ("", None, False):
                report["patientFieldsCleared"].append(key)

    clean: Dict[str, Any] = {}
    for key, value in payload.items():
        if key == "tripLegs":
            continue
        if key in KEEP_TOP:
            clean[key] = value
        elif key in KNOWN_IDENTIFYING_TOP or key in KNOWN_NONCLINICAL_TOP:
            report["droppedTop"].append(key)
        else:
            # Not recognised. Dropped, and surfaced for a person to classify.
            report["unknownTop"].append(key)

    clean_legs = []
    for leg in legs_in:
        leg = leg or {}
        clean_leg: Dict[str, Any] = {}
        for key, value in leg.items():
            if key == "patientInfo":
                continue
            if key in KEEP_LEG:
                clean_leg[key] = value
            elif (key in KNOWN_IDENTIFYING_LEG or key in KNOWN_NONCLINICAL_LEG
                  or key.startswith(KNOWN_IDENTIFYING_LEG_PREFIX)):
                report["droppedLeg"].append(key)
            else:
                report["unknownLeg"].append(key)

        # Scrub every free-text field the model will read, not only clinicalData.
        for field in FREE_TEXT_LEG:
            blob = clean_leg.get(field)
            if isinstance(blob, str) and blob.strip():
                scrubbed, hits = _scrub_text(blob, names)
                if hits:
                    clean_leg[field] = scrubbed
                    report["maskedIn"].append(field)
                    report["patternsHit"].extend(hits)

        # additionalFields, entry by entry. Kept entries are reduced to the
        # fields the model reads; everything else about the entry goes.
        extra = clean_leg.get("additionalFields")
        if isinstance(extra, list):
            kept = []
            for entry in extra:
                if not isinstance(entry, dict):
                    continue
                name = str(entry.get("name") or "").strip()
                if name in KNOWN_IDENTIFYING_ADDITIONAL:
                    report["droppedLeg"].append(f"additionalFields.{name}")
                    continue
                if name not in KEEP_ADDITIONAL:
                    report["unknownLeg"].append(f"additionalFields.{name or '(unnamed)'}")
                    continue
                value, selected = entry.get("value"), entry.get("selectedLabel")
                if name in FREE_TEXT_ADDITIONAL:
                    for field, raw in (("value", value), ("selectedLabel", selected)):
                        if isinstance(raw, str) and raw.strip():
                            scrubbed, hits = _scrub_text(raw, names)
                            if hits:
                                report["maskedIn"].append(f"additionalFields.{name}")
                                report["patternsHit"].extend(hits)
                                if field == "value":
                                    value = scrubbed
                                else:
                                    selected = scrubbed
                kept.append({"name": name, "label": entry.get("label"),
                             "section": entry.get("section"),
                             "dataType": entry.get("dataType"),
                             "value": value, "selectedLabel": selected})
            clean_leg["additionalFields"] = kept
        elif extra is not None:
            clean_leg.pop("additionalFields", None)
            report["droppedLeg"].append("additionalFields")

        questions = clean_leg.get("losQuestions")
        if isinstance(questions, list):
            for entry in questions:
                if not isinstance(entry, dict):
                    continue
                for field in ("answer", "questionText", "answerValue"):
                    value = entry.get(field)
                    if isinstance(value, str):
                        scrubbed, hits = _scrub_text(value, names)
                        if hits:
                            entry[field] = scrubbed
                            report["maskedIn"].append(f"losQuestions.{field}")
                            report["patternsHit"].extend(hits)

        info = leg.get("patientInfo") or {}
        blank_patient = {k: info.get(k) for k in KEEP_PATIENT}
        # The clinical fields we now keep are typed by a human, so they get the
        # same scrub as clinicalData rather than riding through on the allow list.
        for field in FREE_TEXT_PATIENT:
            raw = blank_patient.get(field)
            if isinstance(raw, str) and raw.strip():
                scrubbed, hits = _scrub_text(raw, names)
                if hits:
                    blank_patient[field] = scrubbed
                    report["maskedIn"].append(f"patientInfo.{field}")
                    report["patternsHit"].extend(hits)
        clean_leg["patientInfo"] = blank_patient
        clean_legs.append(clean_leg)

    for field in FREE_TEXT_TOP:
        blob = clean.get(field)
        if isinstance(blob, str) and blob.strip():
            scrubbed, hits = _scrub_text(blob, names)
            if hits:
                clean[field] = scrubbed
                report["maskedIn"].append(field)
                report["patternsHit"].extend(hits)

    clean["tripLegs"] = clean_legs

    for key in ("droppedTop", "droppedLeg", "unknownTop", "unknownLeg",
                "maskedIn", "patternsHit", "patientFieldsCleared"):
        report[key] = sorted(set(report[key]))

    return {"payload": clean, "report": report}


def residual_scan(payload: Dict[str, Any]) -> List[str]:
    """Last look at the cleaned payload. Anything here is a leak, not a warning."""
    text = json.dumps(payload)
    found = []
    for label, pattern in PATTERNS:
        for match in pattern.findall(text):
            if isinstance(match, str) and match.startswith("["):
                continue
            found.append(f"{label}: {str(match)[:40]}")
    return sorted(set(found))
