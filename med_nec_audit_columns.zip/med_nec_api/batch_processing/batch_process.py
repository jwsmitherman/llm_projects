"""Batch medical necessity review.

Same engine as the review screen, run over a file instead of one trip at a time.
The service does the thinking; this process reads the export, de-identifies every
payload, posts it, and writes the workbook.

Two commands, in two windows. From med_nec_api:

    python -m uvicorn app:app --port 8000      leave running
    batch_processing\\run_batch.cmd            this

Drop the export from the Transport.net query into actual_payloads\\ and run with no
arguments. Workbooks land in batch_results\\.
"""

import argparse
import io
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import httpx
import pandas as pd

import deidentify
import workbook

# The service's own parser, imported rather than reimplemented. Production
# payloads leave losQuestions null and put everything in the clinicalData
# string, so the batch has to recover pairs exactly as the model sees them.
sys.path.insert(0, str(Path(__file__).parent.parent))
from llm import parse_clinical_data  # noqa: E402

HERE = Path(__file__).parent
PAYLOAD_DIR = HERE / "actual_payloads"
RECORD_DIR = HERE / "actual_pcr"
RESULTS_DIR = HERE / "batch_results"


def find_input(given: Optional[str]) -> Path:
    if given:
        path = Path(given)
        if not path.is_file():
            print(f"No such file: {path.resolve()}")
            sys.exit(1)
        return path

    candidates = [p for p in PAYLOAD_DIR.glob("*")
                  if p.suffix.lower() in (".csv", ".xlsx", ".xlsm", ".xls")
                  and not p.name.startswith("~$")]
    if not candidates:
        print(f"Nothing to run. Put the export in {PAYLOAD_DIR.resolve()}")
        print("Expected a .csv or .xlsx with a RequestPayload and TripRequestId column.")
        sys.exit(1)
    if len(candidates) > 1:
        newest = max(candidates, key=lambda p: p.stat().st_mtime)
        print(f"note   {len(candidates)} files in actual_payloads\\, using the newest: {newest.name}")
        print("       Pass --input to pick a different one.")
        return newest
    return candidates[0]


def _safe_name(value: Any, width: int = 48) -> str:
    """A column name fit to print.

    Never print a column name whole. When an export has no header row the first
    data row becomes the header, and in this project that first cell is a
    production payload: printing it puts a patient name, date of birth and MRN
    into the terminal scrollback. Truncated and stripped of newlines.
    """
    text = " ".join(str(value).split())
    return text[:width] + ("..." if len(text) > width else "")


def _looks_headerless(columns) -> bool:
    """A header row of real column names is short and has no JSON in it."""
    for name in columns:
        text = str(name).strip()
        if text.startswith(("{", "[")) or len(text) > 120:
            return True
    return False


def load_rows(path: Path, payload_col: str, trip_col: str,
              ts_col: Optional[str], limit: int) -> pd.DataFrame:
    read = pd.read_excel if path.suffix.lower() in (".xlsx", ".xlsm", ".xls") else pd.read_csv
    frame = read(path, dtype=str)

    # An export saved without its header line puts the first trip in the header.
    # Recoverable, and worth recovering: the alternative is asking for the file
    # again over a missing line.
    if _looks_headerless(frame.columns):
        names = [payload_col, trip_col] + ([ts_col] if ts_col else [])
        frame = read(path, dtype=str, header=None)
        if len(frame.columns) < 2:
            print(f"FAIL   {path.name} has {len(frame.columns)} column(s); "
                  "expected at least the payload and the trip id.")
            sys.exit(1)
        width = len(frame.columns)
        frame.columns = (names + [f"column{i}" for i in range(len(names) + 1, width + 1)])[:width]
        print(f"note   {path.name} has no header row. Reading the columns by "
              f"position as: {', '.join(str(c) for c in frame.columns[:4])}")
        print("       If that is the wrong order, add a header row to the export.")

    frame = frame.fillna("")

    missing = [c for c in (payload_col, trip_col) if c not in frame.columns]
    if missing:
        print(f"FAIL   column(s) not in {path.name}: {', '.join(missing)}")
        print(f"       {len(frame.columns)} column(s) found:")
        for name in list(frame.columns)[:20]:
            print(f"         {_safe_name(name)}")
        if len(frame.columns) > 20:
            print(f"         ... and {len(frame.columns) - 20} more")
        print("       Pass --payload-column / --trip-column to match your export.")
        sys.exit(1)

    # A trip can appear more than once: O_RequestEventLogs holds an EventId = 3
    # row per submission, so an order edited and resubmitted has two. With a
    # timestamp we keep the last, which is the order as it finally stood.
    #
    # Josh found these by hand in Excel and flagged them in a column. Counting
    # them here means the reviewer does not have to: the workbook carries both
    # how many submissions the trip had and whether they actually differed, so a
    # verdict read off one of two different payloads is visible as such.
    counts = frame.groupby(trip_col)[payload_col].agg(["size", "nunique"])
    frame = frame.assign(
        __payload_count=frame[trip_col].map(counts["size"]).fillna(1).astype(int),
        __payload_variants=frame[trip_col].map(counts["nunique"]).fillna(1).astype(int))
    repeats = counts[counts["size"] > 1]
    if len(repeats):
        differing = int((repeats["nunique"] > 1).sum())
        print(f"note   {len(repeats)} trip(s) were submitted more than once; "
              f"{differing} of those have payloads that differ. Flagged in the "
              "workbook as 'Duplicate payloads'.")

    before = len(frame)
    if ts_col and ts_col in frame.columns:
        frame = frame.assign(__ts=pd.to_datetime(frame[ts_col], errors="coerce"))
        unparsed = int(frame["__ts"].isna().sum())
        if unparsed:
            print(f"note   {unparsed} row(s) have an unreadable {ts_col}; "
                  "those sort to the end")
        frame = (frame.sort_values("__ts", ascending=False, na_position="last")
                      .drop_duplicates(subset=[trip_col], keep="first")
                      .sort_values("__ts", ascending=True, na_position="last"))
        if before - len(frame):
            print(f"note   {before - len(frame)} resubmitted order(s) collapsed, "
                  f"keeping the latest {ts_col} per trip")
    else:
        frame = frame.drop_duplicates(subset=[trip_col], keep="first")
        if before - len(frame):
            print(f"CHECK  {before - len(frame)} duplicate trip id(s) collapsed, and "
                  "without a timestamp the one kept is arbitrary.")
            print("       Add the event timestamp to the export to keep the latest.")

    return frame.head(limit) if limit else frame


def load_records(source: Optional[str]) -> Dict[str, str]:
    """Trip id -> one-row csv text, keyed by TNET_TripRequestId.

    Takes the wide ePCR extract (csv or xlsx) from actual_pcr\\, or the
    folder-per-trip tree the builder notebook writes. Free text is scrubbed for
    identifier patterns before it goes anywhere: EPCR_Narrative is written at
    the bedside by a crew with the chart open.
    """
    paths = []
    if source:
        given = Path(source)
        if not given.exists():
            print(f"FAIL   no such path: {given.resolve()}")
            sys.exit(1)
        paths = [given]
    elif RECORD_DIR.is_dir():
        paths = [p for p in RECORD_DIR.glob("*")
                 if p.suffix.lower() in (".csv", ".xlsx", ".xlsm", ".xls")
                 and not p.name.startswith("~$")]
        if len(paths) > 1:
            paths = [max(paths, key=lambda p: p.stat().st_mtime)]
            print(f"note   several files in actual_pcr\\, using the newest: {paths[0].name}")

    if not paths:
        print("records   : none. Put the ePCR extract in actual_pcr\\ to score it too.")
        return {}

    path = paths[0]
    found: Dict[str, str] = {}

    if path.is_dir():
        for folder in sorted(path.iterdir()):
            csv = folder / "epcr.csv"
            if folder.is_dir() and csv.is_file():
                text = csv.read_text()
                if len(text.strip().splitlines()) > 1:
                    found[folder.name] = text
        print(f"records   : {len(found)} trip(s) with a populated ePCR")
        return found

    read = pd.read_excel if path.suffix.lower() in (".xlsx", ".xlsm", ".xls") else pd.read_csv
    frame = read(path, dtype=str).fillna("")

    key = "TNET_TripRequestId"
    if key not in frame.columns:
        print(f"FAIL   {key} not in {path.name}; records cannot be matched to trips.")
        print(f"       {len(frame.columns)} column(s) found, first few:")
        for name in list(frame.columns)[:8]:
            print(f"         {_safe_name(name)}")
        sys.exit(1)

    # Scrub the crew's free text. The columns that carry prose, per the
    # service's own field spec.
    FREE_TEXT = ["EPCR_Narrative", "EPCR_Chief_Complaint", "EPCR_Primary_Impression",
                 "EPCR_Secondary_Impressions", "EPCR_Patient_Evaluation_Care",
                 "EPCR_Medical_Surgical_History", "EPCR_Current_Medications",
                 "EPCR_Reason_For_Destination", "EPCR_Working_Diagnosis",
                 "TNET_LevelOfServiceDescription"]
    masked = 0
    for column in FREE_TEXT:
        if column not in frame.columns:
            continue
        for i, value in frame[column].items():
            if not str(value).strip():
                continue
            scrubbed, hits = deidentify._scrub_text(str(value), [])
            if hits:
                frame.at[i, column] = scrubbed
                masked += 1

    for trip_id, group in frame.groupby(key):
        found[str(trip_id).strip()] = group.to_csv(index=False)

    print(f"records   : {len(found)} trip(s) in {path.name}, {len(frame.columns)} columns")
    if masked:
        print(f"            identifier patterns masked in {masked} free text value(s)")
    return found


def _pairs(leg: Dict[str, Any]) -> list:
    """Question and answer pairs, the same way the service finds them."""
    structured = [q for q in (leg.get("losQuestions") or [])
                  if isinstance(q, dict) and str(q.get("answer") or "").strip()]
    if structured:
        return [{"question": q.get("questionText"), "answer": q.get("answer")}
                for q in structured]
    return parse_clinical_data(leg.get("clinicalData"))


def prepare(row) -> Dict[str, Any]:
    """De-identify one row. Nothing leaves this function that still identifies."""
    trip_id = str(row["__trip_id"]).strip()
    out: Dict[str, Any] = {
        "tripRequestId": trip_id,
        "orderedAt": row.get("__ordered_at"),
        "payloadCount": int(row.get("__payload_count") or 1),
        "payloadVariants": int(row.get("__payload_variants") or 1),
    }

    try:
        payload = json.loads(row["__payload"])
    except Exception as exc:
        out["error"] = f"payload is not valid JSON: {exc}"[:200]
        return out

    cleaned = deidentify.deidentify(payload)
    scrubbed, out["deid"] = cleaned["payload"], cleaned["report"]

    leak = deidentify.residual_scan(scrubbed)
    if leak:
        # Held back, not sent. An identifier surviving the scrub is a defect in
        # the de-identifier, and this trip waits until that is fixed.
        out["error"] = "HELD BACK, identifier survived scrubbing: " + "; ".join(leak[:3])
        out["leak"] = leak
        return out

    leg = (scrubbed.get("tripLegs") or [{}])[0]
    out.update({
        "levelOfService": leg.get("levelOfService") or leg.get("losCategory"),
        "pickupCode": leg.get("pickupLocTypeCode"),
        "dropoffCode": leg.get("dropoffLocTypeCode"),
        "tripType": f"{leg.get('pickupLocTypeCode') or '?'} to {leg.get('dropoffLocTypeCode') or '?'}",
        "tripReason": scrubbed.get("tripReason"),
        "facilityPayReason": leg.get("facilityPayReason"),
        "pairs": _pairs(leg),
        "scrubbed": scrubbed,
    })
    return out


def post(client: httpx.Client, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
    started = time.perf_counter()
    try:
        response = client.post(path, json=body)
        ms = int((time.perf_counter() - started) * 1000)
        if response.status_code != 200:
            detail = response.json()
            return {"ok": False, "ms": ms,
                    "error": str(detail.get("detail") or detail.get("message"))[:200]}
        return {"ok": True, "ms": ms, "body": response.json()}
    except Exception as exc:
        return {"ok": False, "ms": int((time.perf_counter() - started) * 1000),
                "error": f"{type(exc).__name__}: {exc}"[:200]}


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--input", default=None, help="defaults to the newest file in actual_payloads\\")
    p.add_argument("--payload-column", default="RequestPayload")
    p.add_argument("--trip-column", default="TripRequestId")
    p.add_argument("--timestamp-column", default="EventTimeStamp")
    p.add_argument("--records", default=None,
                   help="defaults to the newest file in actual_pcr\\")
    p.add_argument("--base", default="http://127.0.0.1:8000")
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--timeout", type=float, default=300.0)
    p.add_argument("--dry-run", action="store_true",
                   help="de-identify and report only; send nothing to the model")
    p.add_argument("--allow-unknown-fields", action="store_true",
                   help="proceed when the export carries fields the de-identifier "
                        "has never seen. Off by default, on purpose.")
    args = p.parse_args()

    path = find_input(args.input)
    frame = load_rows(path, args.payload_column, args.trip_column,
                      args.timestamp_column, args.limit)
    frame = frame.rename(columns={args.payload_column: "__payload",
                                  args.trip_column: "__trip_id",
                                  args.timestamp_column: "__ordered_at"})
    print(f"input     : {path.name}")
    print(f"trips     : {len(frame)}")
    records = load_records(args.records)

    # Say plainly whether the two extracts are about the same trips. A silent
    # zero here is how the ePCR columns go empty with no explanation.
    if records:
        trip_ids = {str(v).strip() for v in frame["__trip_id"]}
        matched = trip_ids & set(records)
        print(f"            {len(matched)} of {len(trip_ids)} trip(s) in this run "
              f"have a record")
        if not matched:
            print()
            print("CHECK  No record matches any trip in this run. The two extracts")
            print("       appear to cover different trips, so there is nothing to")
            print("       compare and the ePCR columns will be empty.")
            print(f"       trip ids in the payload export : "
                  f"{', '.join(sorted(trip_ids)[:3])} ...")
            print(f"       TNET_TripRequestId in the ePCR : "
                  f"{', '.join(sorted(records)[:3])} ...")
            print("       Re-pull one of them so the id ranges overlap.")
            print()

    # Everything is de-identified before anything is sent. An unknown field in
    # row 400 is worth knowing about before row 1 goes to the model.
    print("\nde-identifying...")
    prepared = [prepare(frame.iloc[i]) for i in range(len(frame))]

    unknown: Dict[str, int] = {}
    for r in prepared:
        for field in (r.get("deid", {}).get("unknownTop", [])
                      + r.get("deid", {}).get("unknownLeg", [])):
            unknown[field] = unknown.get(field, 0) + 1

    held = [r for r in prepared if r.get("leak")]
    broken = [r for r in prepared if r.get("error") and not r.get("leak")]
    print(f"  ready           : {len(prepared) - len(held) - len(broken)}")
    print(f"  held back       : {len(held)} (an identifier survived scrubbing)")
    print(f"  unreadable      : {len(broken)}")

    if unknown:
        print(f"\n  {len(unknown)} field name(s) the de-identifier does not recognise:")
        for field, count in sorted(unknown.items(), key=lambda kv: -kv[1])[:25]:
            print(f"     {field:<42} in {count} payload(s)")
        print("\n  These were DROPPED, not sent. Classify each in deidentify.py:")
        print("  KEEP_* if the model should read it, KNOWN_IDENTIFYING_* if not.")
        if not args.allow_unknown_fields and not args.dry_run:
            print("\n  Stopping. Re-run with --dry-run to inspect, or")
            print("  --allow-unknown-fields once you have read the list above.")
            return 2

    results = prepared
    if not args.dry_run:
        sendable = [r for r in prepared if not r.get("error")]
        print(f"\nsending {len(sendable)} trip(s) to {args.base}")
        try:
            health = httpx.get(f"{args.base}/healthz", timeout=10).json()
            print(f"service   : {health.get('status')}  engine {health.get('engineVersion')}")
        except Exception as exc:
            print(f"\nFAIL   the service is not running at {args.base}")
            print(f"       {type(exc).__name__}: {exc}")
            print("       Start it first, in its own window, from med_nec_api:")
            print("           python -m uvicorn app:app --port 8000")
            return 1

        client = httpx.Client(base_url=args.base, timeout=args.timeout)
        index = {r["tripRequestId"]: r for r in prepared}
        started = time.perf_counter()

        def work(prep):
            prep = dict(prep)
            prep["order"] = post(client, "/v1/medical-necessity/evaluate", prep["scrubbed"])
            csv_text = records.get(prep["tripRequestId"])
            if csv_text:
                prep["record"] = post(client, "/v1/medical-necessity/evaluate-epcr",
                                      {"csv": csv_text,
                                       "tripRequestId": prep["tripRequestId"]})
                # Keep the fields a reviewer will want beside the verdict, so the
                # ePCR columns read without opening the source extract.
                try:
                    row = pd.read_csv(io.StringIO(csv_text), dtype=str).fillna("").iloc[0]
                    prep["recordFields"] = row.to_dict()
                except Exception:
                    prep["recordFields"] = {}
            return prep

        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            for i, full in enumerate(pool.map(work, sendable), 1):
                index[full["tripRequestId"]] = full
                order = (full.get("order") or {}).get("body") or {}
                state = ((order.get("detail") or {}).get("determination")
                         or (full.get("order") or {}).get("error") or "")
                print(f"  [{i}/{len(sendable)}] {full['tripRequestId']:<12} "
                      f"{str(state)[:28]:<28} {(full.get('order') or {}).get('ms', 0)} ms")
        results = list(index.values())
        print(f"\nelapsed   : {time.perf_counter() - started:.1f}s")

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = workbook.build(results, RESULTS_DIR / f"med_nec_review_{stamp}.xlsx",
                         scored=not args.dry_run)
    print(f"\nwritten   : {out.resolve()}")
    if args.dry_run:
        print("Dry run, no determinations. Read the de-identification columns, then re-run.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
